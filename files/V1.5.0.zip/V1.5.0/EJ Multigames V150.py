#press F5 TO START:

#GAME MADE BY: ETHAN HORTMAN

#GAME VERSION: V2.5.0

#THANK YOU FOR PLAYING, ENJOY...

#To allow the program to check for updates please make sure your connected to the internet!

































#Know your versions!

#v1.2.3.4
# ^ ^ ^ ^
# ^ ^ ^ 4.Patchess, very small fix's.
# ^ ^ 3.Very small updates, bug fixes etc...
# ^ 2.Medium updates, bug fixes small add ons etc...
# 1.A big update, interface changes, new games etc...





#changing any code can damage the games. do not save any changes that you might of accidently made. If you have
#any ideas, Or improvments to the code you can contact me Ethan @ [ ehors26@gmail.com ] or for updates please contact me.

#you are free to change code and or add content but recognition would be greatly apricited. and some sort of contact of the change
#would be even more apriciated.




#=====================================================================================
#scroll up now if you dont want to accidently make a mistake! or continue if deliberit.
#=====================================================================================



#KEY:
#----------------- \START OF SOMETHING NEW OR TO POINT OUT SOMETHING.

#_________________ \TO SHOW THE END OF SOMETHING.

#================= \TO SHOW IMPORTANTS, GAME MUST HAVE ABILITYS TO FUNCTION.

#///////////////// \TO SHOW IN GAME SPLIT FROM MAIN CODE.

#||||||||||||||||| \END OF ALL CODE.

#this is a compile \NORMAL COMMENT.






#get the song partless, because im partless.



















#IMPORTS===============
import sys
import json
import random
import time
import pickle
import re
import os
import urllib
import socket
import fileinput
import urllib.request
import webbrowser
import tkinter.ttk
#IMPORTS END__________


#CHECK INTERNET============================================================CHECK INTERNET===============================================================CHECK INTERNET#
def check_connection():
    try:
        socket.create_connection(("www.google.com", 80)) #checks to see if it can connect to a website. if it can we have internet!
        print('=====================================================================')
        print('internet connected checking for update please wait')
        print('=====================================================================')
        checkUpdate()
        
    except OSError:
        print('=====================================================================')
        print('ERROR 4: No internet, Check for update unsuccessful.')
        print('=====================================================================')
        name()
#END CHECK INTERNET_____________________________________________________END CHECK INTERNET__________________________________________________________END CHECK INTERNET#
    
#CHECK UPDATE==============================================================CHECK UPDATE===================================================================CHECK UPDATE#
def checkUpdate():
    try:
        webbrowser.open('http://ejmultigames.github.io/downloads/Download250.html') #if theirs an update send to update now
        print('''Please install the update.
This update includes bug fixes and better performance.''')
        time.sleep(5)
        name
        
    except OSError: #if theirs no update check for a patch.
        print('You are all up to date.')
        print('=====================================================================')
        patchCheck()
#END CHECK UPDATE________________________________________________________END CHECK UPDATE_____________________________________________________________END CHECK UPDATE#

#NAME========================================================================NAME=================================================================================NAME#
def name():
    global name

    print('''/DISCLAIMER: THE 4 OFFERD GAMES ARE SUBJECT TO BREAKING OR MAILFUNCIONING,
PLEASE RESTART THE GAME IF SUCH THINGS HAPPEN AND TELL ME.
EMAIL: (ehors26@gmail.com)''')
    time.sleep(1)
    print('=====================================================================')
    name = input("Please tell me your name or press enter: ")
    main_menu()
#END OF NAME______________________________________________________________END OF NAME______________________________________________________________________END OF NAME#

#MAIN MENU=================================================================MAIN MENU=========================================================================MAIN MENU#
def main_menu():

#time--------------------------------time#
 from datetime import date
 now = date.today()
 date_now = now.strftime("%d/%m/%y")
#END OF TIME_________________________END OF TIME#
 
#date--------------------------------date#
 from datetime import datetime
 now1 = datetime.now()
 time_now = now1.strftime("%H:%M")
#END OF DATE_________________________END OF DATE#
 
 while True:

        import random
        import time
        import os
        import json

        print('=====================================================================')
        try:
         os.startfile('--')
        except IOError:
         print('ERROR 1: failed to open optional music file!')
         print('=====================================================================')
        print('NAME:',name,'- DATE',date_now,'- TIME:',time_now,'')
        print('=====================================================================')
        print('welcome to EJ multigames this game was made by ETHAN HORSTMAN')
        game =input('''please make a selection out of...
(1, number game) (2, medieval events) (3, trivia game) (4, number knowledge)
[change your (n)ame!] or exit by typing (q)uit]
: ''')   #future user agreement
        if game == "1": 
            game_one()

        elif game =="2":    #directing 1, 2, 3, name and quit to their locations.
            game_two()

        elif game == "3":
            game_three()

        elif game =="4":
            game_four()

        elif game.lower() =="n" or game.lower() =="name":
            new_name()

        elif game.lower() == "q" or game.lower() == "quit": #closes game from home menu.
                exit()  #exits program.

        else:                                                                            #if non of the above are selected then do this
           print('---------------------------------------------------------------------')#anything exept the given inputs will resolt in this error
           print('ERROR 2: oops please choose between the given options')                  #prints the error message
           time.sleep(1)                                                                 #waites for 1 second
           continue                                                                      #continues to main menu

#END OF MAIN MENU______________________________________________________END OF MAIN MENU_______________________________________________________________END OF MAIN MENU#

#GAME 1 RANDOM NUMBER GAME-----------------------------------------GAME 1 RANDOM NUMBER GAME-------------------------------------------------GAME 1 RANDOM NUMBER GAME#
def game_one():
 import random
 import time
 import os
 while True:
    print('---------------------------------------------------------------------')
    print('Hello',name,'and welcome to my number game.')
    answer =input('''To learn more type (i)nfo, or to start type (p)lay.
If not then type (q)uit: ''')
    if answer.lower() == "p" or answer.lower() =="play":

        print('---------------------------------------------------------------------')
        print('what would you like the game difficulty to be',name,'?')
        answer =input('type (E)asy/(H)ard: ')
        if answer.lower() == "e" or answer.lower() == "easy":

            k = int()                                                                                       #creates k as an empty integer

            while k == int():
                k = random.randrange(1, 100)                                                                #creating k as a random number. so it will produce.
                i =int()                                                                                    #creating i as a blank interager.
                j =int(0)
                print('---------------------------------------------------------------------')              #making j an empty integer
                print('Im thinking of a number between 1 and 100')
                print(k)

                if j in range(0, 20):                                                                       #(make j an if. (self note))  #making j just go up to 20
                    
                 while i ==int():  #checking if i is clear!
                     try:
                        i=int(input('guess my number: '))
                             
                        if i==k:
                                print('')
                                print('You got my number!', k, ' You received', 20-j, 'points, In',j,'turns! well done')     #then print a congrates message
                                while True:
                                    answer = input("Do you want to play again? y/n: ")
                                
                                    if answer.lower() == "yes" or answer.lower() =="y":
                                      del k
                                      k = int()
                                      j = int(0)
                                      break

                                    elif answer.lower() == "no" or answer.lower() == "n":
                                        print('---------------------------------------------------------------------')
                                        print('you will be taken to game menu')
                                        time.sleep(2)
                                        game_one()


                        elif j > int(19):
                            print('---------------------------------------------------------------------')
                            print('sorry you exeeded your max amount of turns.')
                            print('you will be taken to game menu')
                            time.sleep(2)
                            continue

                         
                        else:
                                if i > k:
                                  j+=1
                                  print('')
                                  print('Go lower, you have used', j, 'turns')
                                  i=int()
                                  

                                else:
                                   j+=1
                                   print('')
                                   print('Go higher, you have used', j, 'turns')
                                   i=int()

                     except ValueError:
                            print('---------------------------------------------------------------------')
                            print('OOPS... make shore its a number from 1 to 100!')
                            print('---------------------------------------------------------------------')

                                                                                                                                                                                
#------------------#below code is hard mode.----------------                           


        elif answer.lower() =="h" or answer.lower() =="hard":
            
                k = int()                           #creates k as an empty integer

                while k == int():
                    k =random.randrange(1, 1000)    #creating k as a random number. so it will produce.
                    i =int()                        #creating i as a blank interager.
                    j =int(0)                       #making j an empty integer
                    print('')
                    print('Im thinking of a number between 1 and 1000')
                    print(k)

                    if j in range(0, 11):                                                           #(make j an if. (self note))  #making j just go up to 5

                        
                        while i ==int():                                                            #checking if i is clear!
                         try:
                            i=int(input('guess my number: '))                                       #then asking for user input.
                                 
                            if i==k:                                                                #checking if i is equal to k if correct...
                                    print('')
                                    print('You got my number!', k, ' you received', 11-j, 'points, In',j,'turns! well done')     #then print a congrates message! then..
                                    while True:
                                        answer = input("Do you want to play again? y/n: ")
                                        
                                        if answer.lower() == "yes" or answer.lower() =="y":
                                            del k
                                            k = int()
                                            j = int(0)
                                            break

                                        elif answer.lower() == "no" or answer.lower() == "n":
                                            print('---------------------------------------------------------------------')
                                            print('you will be taken to the random number game menu')
                                            time.sleep(2)
                                            game_one()
                                            

                                        

                            elif j > int(9):
                                print('---------------------------------------------------------------------')
                                print('sorry you exeeded your max amount of turns.')
                                print('you will be taken to game menu')
                                time.sleep(2)
                                continue

                             
                            else:
                                    if i > k:
                                        j+=1
                                        print('Go lower, you have used', j, 'turns')
                                        i=int()
                                      

                                    else:
                                        j+=1
                                        print('Go higher, you have used', j, 'turns')
                                        i=int()

                         except ValueError:
                            print('---------------------------------------------------------------------')
                            print('OOPS... make shore its a number from 1 to 1000!')
                            print('---------------------------------------------------------------------')

    elif answer.lower() =="i" or answer.lower() =="info":
        print('---------------------------------------------------------------------')
        print('Searching...')
        try:
            os.startfile('E:/coding work/python work/doc instructions/Game 1 user manul.docx')
            print('------------------------------------')
            print('Opening...')
            print('---------------------------------------------------------------------')
            print('you will be taken to game menu')
            time.sleep(2)#hopefully get the program to open a web or something containing all instructions and pics.
            continue
        
        except (FileNotFoundError, IOError):
            print('------------------------------------')
            print('ERROR 3: file destination not found.')
            print('---------------------------------------------------------------------')
            print('you will be returned to the random number game menu.')
            import time
            time.sleep(3)
            continue

    elif answer.lower() == "q" or answer.lower() =="quit": #i want this to send me to the main game menu;
         main_menu()

                 

#END OF RANDOM NUMBER GAME_______________________________________________END OF RANDOM NUMBER GAME___________________________________________END OF RANDOM NUMBER GAME#

#GAME 2 MEDIEVIL EVENTS-----------------------------------------------------------GAME 2--------------------------------------------------------GAME 2 MEDIEVIL EVENTS#       

def game_two():                                                                                #add-armour to game to reduce attack taken
 import os
 import time
 import random
 while True:

        print('---------------------------------------------------------------------')
        answer =input('''welcome to game 2, medieval events.
please know that this game is still in early release.
(Enter (p)lay to continue) or (i)nfo for info) or (q)uit to quit): ''')

        
        if answer.lower() =="p" or answer.lower() =="play":

            health = int(100)        
            attack = int(25)
            gold = int(0)
            event = int()
            level = int(0)
            green_spear = int(0)
            INPUT_TWO = ('')
            INPUT = ('')

            while event == int():

                if health < int(1):
                    print('you died')
                    time.sleep(2)
                    print('game over')
                    time.sleep(1)
                    while True:
                        INPUT = input('would you like to play again? y/n: ')
                        if INPUT =="y" or INPUT =="yes":
                            game_two()

                        elif INPUT =="n" or INPUT =="no":
                            main_menu()

                        else:
                            return

                elif health >= int(1):
                    print('HEALTH:',health)
                    print('GOLD:',gold)
                    print('ATTACK:',attack)
                    print('level:',level)
                    print('green spear/s:',green_spear)
                    print('press (q)uit at anytime')
                    event = random.randrange(1, 8) #ACCTUALLY (1, 7)
                    INPUT = ("")                   #EMPTY STRING

#event 1-------------------------------------------------------------------------------------------------------------------------------event 1
                while event == int(1):
                     print('you have been brought into a fight against a low level goblin')
                     print('you will recieve 5 gold for defeting it.')
                     INPUT =input("do you want to attack it? y/n:")

                     if INPUT.lower() == "y":
                        print('')
                        print('You easly punched the globlan in the face and cut him open. You recived 5 gold.')
                        gold += 5
                        level += 1
                        print('') #gap in text
                        print('HEALTH:',health)
                        print('GOLD:',gold)
                        print('ATTACK:',attack)
                        print('')
                        event =int()
                        
                     elif INPUT.lower() =="n":
                        print('')
                        print('You ran away from the enemy safly')
                        print('')
                        event =int()

                     elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break
#event 2-------------------------------------------------------------------------------------------------------------------------------------event 2
                while event == int(2):
                    print('You have stumbled accross a very wonderful blacksmith, He has offered you plus 5 attack for 20 gold.')
                    INPUT = input("Do you want to exept this offer? y/n: ")

                    if INPUT.lower() =="y":
                      if gold > int(19): #20 HIGHER
                          print('')
                          print('You are stoked as the blacksmith hands over your improved sword.')
                          attack += 5
                          gold -= 20
                          print('HEALTH:',health)
                          print('GOLD:',gold)
                          print('ATTACK:',attack)
                          print('')
                          event = int()

                      elif gold < int(20): #20 LOWER
                          print('')
                          print('You where shocked when you noticed you dont have enough money.')
                          print('')
                          event = int()

                    elif INPUT.lower() =="n":
                      print('')
                      print('You thank the blacksmith for the offer but dont exept.')
                      print('')
                      event =int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break
#event 3-------------------------------------------------------------------------------------------------------------------------------------event 3
                while event == int(3):
                    print('You found yourself staring into the eyes of a hungry deamon.')
                    INPUT = input("Would you like to attack it? y/n: ")

                    if INPUT.lower() =="y":
                        
                        if attack >= int(30): #30 was 29
                            print('')
                            print('you managed to stabe the deamon in the face and kill him with 1 blow.')
                            print('you recieved 30 gold and found a health potion of plus 10 HP!')
                            gold += 30
                            health += 10
                            level += 2
                            print('HEALTH:',health)
                            print('GOLD:',gold)
                            print('ATTACK:',attack)
                            print('level:',level)
                            print('')
                            event = int()

                        elif attack <= int(29):
                            print('')
                            print('the deamon bent your swored and kicked you.')
                            health -= 10
                            attack -= 5
                            
                            if health <= int(0):
                                print('---------------------------------------------------------------------')
                                print('you died')
                                time.sleep(1)
                                while True:
                                    print('---------------------------------------------------------------------')
                                    INPUT = input('would you like to play again? y/n: ')
                                    if INPUT =="y" or INPUT =="yes":
                                        game_two()

                                    elif INPUT =="n" or INPUT =="no":
                                        main_menu()

                                    else:
                                        continue

                            elif health >= int(1):
                                print('HEALTH:',health)
                                print('GOLD:',gold)
                                print('ATTACK:',attack)
                                print('level:',level)
                                print('')
                                print('you managed to get away with some minor scratches and broosing.')
                                print('as you walked back into town, a blacksmith saw that your sword was damaged and asked if you would like it repaired for 5 gold.')
                                INPUT_TWO = input("do you exept this offer? y/n: ")

                                if INPUT_TWO.lower() =="y":
                                   if gold > int(4):
                                       print('')
                                       print('the blacksmith repaired your sword')
                                       attack += 5
                                       event = int()

                                   elif gold < int(4):
                                        print('')
                                        print('sorry, said the blacksmith. you dont have enough gold.')
                                        event = int()

                                elif INPUT_TWO.lower() =="n":
                                    print('')
                                    print('you kindly rejected the blacksmiths offer')
                                    event = int()

                                    
                    elif INPUT.lower() =="n":
                        print('')
                        print('you ran away from the deamon, and got home in one piece.')
                        print('')
                        event = int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break
#event 4--------------------------------------------------------------------------------------------------------------------------event 4
                while event == int(4):
                    print('an advanced blacksmith has offered you a upgrade, for 50 gold you will get 30 more attack damage.')
                    INPUT = input("do you exept this offer? y/n: ")

                    if INPUT.lower() =="y":
                        if gold > int(49):
                           print('')
                           print('the blacksmith came back with a havely upgreaded sword')
                           attack += 30
                           gold -= 50
                           print('HEALTH:',health)
                           print('GOLD:',gold)
                           print('ATTACK:',attack)
                           print('')
                           
                           

                        elif gold < int(49):
                            print('')
                            print('sorry said the blacksmith you seem to be short on gold')
                            print('')
                            event = int()

                    elif INPUT.lower() =="n":
                        print('')
                        print('you kindly rejected the blacksmiths offer.')
                        event = int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break

#event 5--------------------------------------------------------------event 5/ lvl 5---------------------------------------------event 5#

                while event ==int(5):
                    if level > int(4):
                      print('')
                      print('you met a lovely girl, she has offered you 50 HP for 100 gold.')
                      INPUT = input("do you exept her offer? y/n")

                    if INPUT.lower() =="y":
                           if gold < int(99):
                               print('')
                               print('sorry you dont have enough money.')
                               print('HEALTH:',health)
                               print('GOLD:',gold)
                               print('ATTACK:',attack)
                               event = int()

                           elif gold > int(99):
                                print('')
                                print('you where given a potion of plus 50 HP!')
                                health += 50
                                gold -= 100
                                print('HEALTH:',health)
                                print('GOLD:',gold)
                                print('ATTACK:',attack)
                                event = int()

                    elif INPUT.lower() =="n":
                            print('')
                            print('you kindly rejected the girl.')
                            event = int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break

                    elif level < int(5):
                        print('level 5 event locked.')
                        event =int()

#event 6--------------------------------------------------event 6 / lvl 5---------------------------------------------------------event 6#
                while event == int(6):                                                          #possible new item, dragon spear.
                    if level > int(4):                                                          #color coded dragons/ dragon spear.
                        print('')
                        print('You are attacked by a Green Dragon from the sky.')
                        print('you will recieve 150 gold for defeating it.')
                        INPUT = input('do you wish to attack the dragon. y/n: ')

                        if INPUT.lower() =="y":
                            if green_spear >= int(1):  #spear 1 or higher
                                print('')
                                print('you defeated the dragon using 1x green spear and recived 150 gold.')
                                gold += 150
                                level += 3
                                green_spear -= 1
                                event = int()
                                
                            elif green_spear <= int(0): #0
                                if attack > int(49):
                                    print('')
                                    print('you defeated the dragon and recived 150 gold.')
                                    gold += 150
                                    level += 3
                                    event = int()

                                elif attack < int(50):
                                    print('')
                                    print('you where knocked off your feet and scorched by the dragon.')
                                    health -= 25
                                    if health >= int(1):
                                        print('')
                                        print('but managed to run away before being beheaded.')
                                        event = int()

                                    elif health <= int(0):
                                        print('---------------------------------------------------------------------')
                                        print('you died')
                                        time.sleep(1)
                                        while True:
                                            print('---------------------------------------------------------------------')
                                            INPUT = input('would you like to play again? y/n: ')
                                            if INPUT =="y" or INPUT =="yes":
                                                game_two()

                                            elif INPUT =="n" or INPUT =="no":
                                                 main_menu()

                                            else:
                                                continue
                                        
                        elif INPUT.lower() =="n":
                            print('')
                            print('you managed to take cover in a small shack.')
                            event = int()

                        elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                            break
                            
                    elif level < int(5):
                        print('level 5 event locked.')
                        event = int()

#event 7------------------------------------------event 7 / any level--------------------------------------------------------------event 7#
                while event == int(7):
                    print('')
                    print('you have met an old laddy, she says she has a spear that will come in handy for later.')
                    print('though it will come at a hefty price. you can buy the spear for 65 gold.')
                    INPUT = input('do you exept the old laddys offer? y/n: ')

                    if INPUT.lower() =="y":
                        if gold > int(64):
                            print('')
                            print('the old laddy handed you the spear and walked away.')
                            green_spear += 1
                            event = int()

                        elif gold < int(65):
                            print('')
                            print('sorry said the old laddy, you seem to be low on gold, defeat a few more low lvl enemys and come back')
                            event = int()

                    elif INPUT.lower() =="n":
                        print('')
                        print('you kindly rejected the old laddy.')
                        print('')
                        event = int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break

#END OF MAIN CODE//////////////////////////////////////////////////////////////////////

        elif answer.lower() =="q" or answer.lower() =="quit":
             main_menu()
                        
        elif answer.lower() =="i" or answer.lower() =="info":
            print('---------------------------------------------------------------------')
            print('Searching...')
            try:
                
                os.startfile('E:/python work/doc instructions/GAME 2 user manul.docx')
                print('------------------------------------')
                print('Opening...')
            except (FileNotFoundError, IOError):
                print('------------------------------------')
                print('ERROR 3: file destination not found.')
                print('---------------------------------------------------------------------')
                print('you will be returned to medieval events menu.')
                time.sleep(2)
                continue

#END OF MEDIEVAL EVENTS_________________________________________________END OF MEDIEVAL EVENTS__________________________________________________END OF MEDIEVAL EVENTS#

#game 3 trivia game-------------------------------------------------------game 3 trivia game--------------------------------------------------------game 3 trivia game#
def game_three():
    import time
    import random
    import os

    while True:
        print('---------------------------------------------------------------------')
        print('Hello ',name,' and welcome my trivia game!')
        ans =input('to learn more type (i)nfo, to start the quiz type (p)lay  or (q)uit: ')
        score = int(0)
        total_q = 5 #total questions

                 
        if ans.lower() == "p" or ans.lower() == "play":

            print('---------------------------------------------------------------------')
            ans = input('''whats the version thats this game was coded on? E.g v0.0.0
:''')
            if ans.lower() =="v3.7.4":
               score += 1
               print('correct')
            else:
                print('incorrect')

            ans = input('''whats is 1 + 2
:''')
            if ans =="3":
               score += 1
               print('correct')
            else:
                print('incorrect')

            ans = input('''whats bigger 999 or 9199
:''')
            if ans =="9199":
               score += 1
               print('correct')
            else:
                print('incorrect')

            ans = input('''whats the devalopers name?
:''')
            if ans.lower() =='ethan' or ans.lower()=='ejay':
               score += 1
               print('correct')
            else:
                print('incorrect')

            ans = input('''whats my fav coding language?
:''')

            if ans.lower() =="python":
                score += 1
                print('correct')
            else:
                print('incorrect')

            print('---------------------------------------------------------------------')
            time.sleep(1)
            print(name,'you got', score,'answers right out of 5 questions')
            mark = (score/total_q) * 100
            print("mark:",str(mark) + '%')
#score 5/5---------------------------------------
            if score == int(5):
              ans=input('''well done, you got all the questions right!
press (q)uit to go to game menu: ''')

              if ans.lower()=="q" or ans.lower() =="quit":
                 continue

#score 4/5----------------------------------------
            elif score == int(4):
                ans=input('''you got 1 question wrong dont worry, have a look around and come back again!
press (q)uit to go to game menu: ''')

                if ans.lower() =="q" or ans.lower() =="quit":
                    continue
#score 3/5------------------------------------------
            elif score == int(3):
                ans=input('''you where half way, two questions wrong dont wory, have a look around and come back again!
press (q)uit to go to game menu: ''')

                if ans.lower() =="q" or ans.lower() =="quit":
                    continue
#score 2/5-----------------------------------------
            elif score == int(2):
                ans=input('''you got two answers right, have a look around and come back again!
press (q)uit to go to game menu: ''')

                if ans.lower() =="q" or ans.lower() =="quit":
                    continue
#score 1/5----------------------------------------
            elif score == int(1):
                ans=input('''you only got one answer right!, have a look around and come back again!
press (q)uit to go to game menu: ''')

                if ans.lower() =="q" or ans.lower() =="quit":
                    continue
#score 0/5-----------------------------------------
            else:
                ans=input('''you got no questions right, have a look around and come back again!
press (q)uit to go to game menu: ''')

                if ans.lower() =="q" or ans.lower() =="quit":
                    continue

#END OF MAIN CODE//////////////////////////////////////////////////////////////////////

        elif ans.lower() =="q" or ans.lower() =="quit":
            main_menu()

        elif ans.lower() =="i" or ans.lower() =="info":
            print('---------------------------------------------------------------------')
            print('Searching...')
            try:
                os.startfile('E:/python work/doc instructions/GAME 2 user manul.docx') #change this to the quiz game dox when ready.
                print('------------------------------------')
                print('Opening...')
            except (FileNotFoundError, IOError):
                print('------------------------------------')
                print('ERROR 3: file destination not found.')
                print('---------------------------------------------------------------------')
                print('you will be returned to trivia game menu.')
                time.sleep(2)
                continue

#END OF TRIVIA GAME____________________________________________________END OF TRIVIA GAME___________________________________________________________END OF TRIVIA GAME#

#GAME 4 number knowlege game-------------------------------------GAME 4 number knowledge game---------------------------------------------GAME 4 number knowledge game#
def game_four():
 import random
 import time
 import os
 while True:
    
    print('---------------------------------------------------------------------')
    print('Hello',name,'welcome to my number knowledge game!.')
    ans = input('To learn more type (i)nfo, or to start type (p)lay. If not then type (q)uit: ')

    if ans.lower() =="p" or ans.lower() =="play":

        ans = input('what would you like the mode to be? (ti)mes, (d)evide, (p)lus or (s)ubstract: ')
            
#plusing MODE-----------------------------------------------------------------------------------

        if ans.lower() =="p" or ans.lower() =="plus" or ans =="+":
            
            o = int() #second number
            p = int() #first number                           #add possible scoring system. proper quiz mode...

            while o == int():
                o =random.randrange(1, 500)
                p =random.randrange(1, 500)
                i=int()

                while i == int():
                    print('---------------------------------------------------------------------')
                    print('whats ',o,'+', p,'?')

                    try:
                        i =int(input(': '))
                        print(o + p)

                        if i == o + p:
                             print('')
                             print('you got the number right!')
                             answer = input('would you like to play again? y/n: ')

                             if answer.lower() == "y" or answer.lower() == "yes":
                                  del o
                                  o = int()
                                  del p
                                  p = int()

                             elif answer.lower() == "n" or answer.lower() == "no":
                                 print('---------------------------------------------------------------------')
                                 print('you will be returned to number knowledge menu.')
                                 time.sleep(1)
                                 game_four()
                            
                        elif i != o + p:
                            print('Good guess but thats not correct.')
                            i = int()
                            
                    except (IOError, ValueError, FileNotFoundError):
                        print('---------------------------------------------------------------------')
                        print('OOPS... make shore its a number!')

#subtract AWAY MODE-------------------------------------------------------------------------------------

        elif ans.lower() =="s" or ans.lower()=="subtract" or ans =="-":
                        
            o = int() #second number
            p = int() #first number                           #add possible scoring system. proper quiz mode...

            while o == int():
                o =random.randrange(1, 500)
                p =random.randrange(1, 500)
                i=int()

                while i == int():
                    print('---------------------------------------------------------------------')
                    print('whats ',o,' - ', p,'?') 
                    i =int(input(': '))
                    print(o - p)

                    if i == o - p:
                         print('')
                         print('you got the number right!')
                         answer = input('Would you like to play again? y/n: ')

                         if answer.lower() == "y" or answer.lower() == "yes":
                              del o
                              o = int()
                              del p
                              p = int()

                         elif answer.lower() == "n" or answer.lower() == "no":
                             print('---------------------------------------------------------------------')
                             print('you will be returned to number knowledge menu.')
                             time.sleep(1)
                             game_four()
                        
                    elif i != o - p:
                        print('Good guess but thats not correct.')
                        i = int()

#DEVIDE MODE----------------------------------------------------------------------------------
                        
        elif ans.lower() =="d" or ans.lower()=="divide" or ans =="/":

            o = float() #second number
            p = float() #first number #add possible scoring system. proper quiz mode...
            i = float()
            
            while o == int():
                o =random.randrange(1, 500)
                p =random.randrange(1, 500)
                i=float()

                while i == int():
                    print('---------------------------------------------------------------------')
                    print('whats ',o,' / ', p,'?') 
                    i = float(input(': '))
                    print(round(o / p, 2))

                    if i == round(o / p, 2):
                         print('')
                         print('you got the number right!')
                         answer = input('Would you like to play again? y/n: ')

                         if answer.lower() == "y" or answer.lower() == "yes":
                              del o
                              o = float()
                              del p
                              p = float()

                         elif answer.lower() == "n" or answer.lower() == "no":
                             print('---------------------------------------------------------------------')
                             print('you will be returned to number knowledge menu.')
                             time.sleep(1)
                             game_four()
                        
                    elif i != o / p:
                        print('Good guess but thats not correct.')
                        i = float()

#TIME'S MODE-----------------------------------------------------------------------------
        elif ans.lower() =="ti" or ans.lower()=="time" or ans =="times" or ans.lower()=="*":
                        
            o = int() #second number                          #add ability to choose what time tables you would like to do.
            p = int() #first number                           #add possible scoring system. proper quiz mode...

            while o == int():
                o =random.randrange(1, 500)
                p =random.randrange(1, 500)
                i=int()

                while i == int():
                    print('---------------------------------------------------------------------')
                    print('whats ',o,' x ', p,'?') 
                    i =int(input(': '))
                    print(o * p)

                    if i == o * p:
                         print('')
                         print('you got the number right!')
                         answer = input('Would you like to play again? y/n: ')

                         if answer.lower() == "y" or answer.lower() == "yes":
                              del o
                              o = int()
                              del p
                              p = int()

                         elif answer.lower() == "n" or answer.lower() == "no":
                             print('---------------------------------------------------------------------')
                             print('you will be returned to number knowledge menu.')
                             time.sleep(1)
                             game_four()
                        
                    elif i != o * p:
                        print('Good guess but thats not correct.')
                        i = int()

#END OF MAIN CODE///////////////////////////////////////////////////////////////////////////
                    
    elif ans.lower() =="i" or ans.lower() =="info":
        print('---------------------------------------------------------------------')
        print('Searching...')
        try:
            os.startfile('E:/python work/doc instructions/GAME 2 user manul.docx') #change this to the quiz game dox when ready.
            print('------------------------------------')
            print('Opening...')
        except (FileNotFoundError, IOError):
            print('------------------------------------')
            print('ERROR 3: file destination not found.')
            print('---------------------------------------------------------------------')
            print('you will be returned to number knowledge menu.')
            time.sleep(2)
            continue

    elif ans.lower() =="q":
        main_menu()

#END OF NUMBER KNOWLEDGE_______________________________________________END OF NUMBER KNOWLEDGE_________________________________________________END OF NUMBER KNOWLEDGE#

#name rechoose==============================================================NAME RECHOOSE================================================================NAME RECHOOSE#
        
def new_name():
    global name
    print('---------------------------------------------------------------------')
    name = input('Enter a new name: ')
    main_menu()

#END OF NAME RECHOOSE____________________________________________________END OF NAME RECHOOSE_____________________________________________________END OF NAME RECHOOSE#

#MAIN GAME LOOP============================================================MAIN GAME LOOP===============================================================MAIN GAME LOOP#

check_connection()

#MAIN GAME LOOP END______________________________________________________MAIN GAME LOOP END_________________________________________________________MAIN GAME LOOP END#

#GAME IMPROVMENT NOTES:

#1.

#2.

#3.

#4.

#5.

#6.

#7.

#8.

#9.

#10.

#11.

#12.

#13.

#14.

#15.

#16.

#17.

#18.

#19.

#20.

#END OF CODE||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||END OF CODE||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||END OF CODE#
