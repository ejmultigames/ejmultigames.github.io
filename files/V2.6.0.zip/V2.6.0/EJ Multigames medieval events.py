#PRESS F5 TO START.

#EJ Multigames: V2.6.0.0
#Medieval events: BETA V2.1.0.0



#You are permited to change game code. though
#revers engenering passwords and other game data
#will be taken as an offence. Unless you are
#willing to share ideas and improvments for it.
#Thank you, EJ. H

#More information in read me...












































































#NOTES:
#add a time limite to buying spears, 5 purchasses daily.
#e.g. when user starts up the game python instantly loads the timeSave and save, if your a new user the program sends you down to get a save
#     python saves the current date as today, and yesterday as 0, in the game if user goes into shop and purchases 5 spears yesterday gets
#     saved as todays date aswell, if the yesterday and today dates are the samethen user cant buy. untill tomorow in which they will be different!

#let food heal 5 damage

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#IMPROVEMENTS:
#add an error exception with the shop. = complete

#fix the line that seperates menu from inventory = complete

#add a press enter to continue in profile view = complete

#fix all dates = complete

#add exception to help menu = complete

#fix timesave errors = complete

#make a book, every monster the user attackes makes them able to read about it! = uncomplete


print('Loading packages...')
try:
   #main system imports...
   import random
   import time
   import os
   import importlib
   
   #date/ time handling imports...
   from datetime import date
   from datetime import datetime

   #custom module handling...
   import imports
   from imports import ERROR_ALERT, UPDATE_CHECK, IN_GAME_HELP, PASS_CHECK
   from imports.user_save_handling import USER_RESTART, NEW_USER_START

   #save load...
   from saves.save import *

   #time load...
   from saves.timesave import *

   #NO TOUCHING!!!
   from saves import ADMIN_LOGIN

except (ImportError, ModuleNotFoundError, AttributeError, NameError):
   NEW_USER_START.Configure_User()

else:
 print('')
 print('welcome to EJ Multigames',name,'!')
 while True:
   print('')
   print('---------------------------------------------------------------------')
   importlib.reload(ADMIN_LOGIN)
   print('''<<START MENU>>
1--> Start!
2--> Check for update/ Requires internet.
3--> Help.
4--> restart progress.
5--> Quit game.''')
   Input = input(': ')

   if Input == "5":
      exit()

   elif Input.lower() == "admin202":
      print('''1--> Sign in.
2--> Sign out.''')
      Input = input(': ')

      if Input == "1":
         importlib.reload(ADMIN_LOGIN)
         try:
            if ADMIN_LOGIN.PASS == False:
               print('''<ERROR>
You are not qualified to use admin permissons.

If this is a mistake please try restarting the
program.
''')
               PASS_CHECK.Admin_Sign_In()

            elif ADMIN_LOGIN.PASS == True:
               print('You are signed in already!')
            
         except AttributeError:
            print('You need to sign in...')
            PASS_CHECK.Admin_Sign_In()
            
      elif Input == "2":
         PASS_CHECK.Admin_Sign_Out()
         print('You where successfuly signed out!')
      

   elif Input == "4":
      USER_RESTART.Restart_Account() #delets and restarts user acc

   elif Input == "3":
      IN_GAME_HELP.Game_Help()

   elif Input == "2":
      UPDATE_CHECK.Check_Connection()
      
   elif Input == "1":
    global save
    save = False
    while True:
       print('---------------------------------------------------------------------')
       if save == True:
         print('======================') 
         print('Saving your game!')
         print('======================')

         path = os.getcwd() + r'\saves' #path this game is being played on + saves folder.
         
         today = date.today() #today = the date of today.
         today1 = today.strftime("%#d/%#m/%Y") #saves the date so the game knows what day it is, might move elif save == false.

         savetime = os.path.join(path, 'timesave.py') #finds a file (timesave) and 
         f = open(savetime,"w")
         f.write("today = " + str(today1) + "\n")
         f.write("yesterday = " + str(yesterday) + "\n")
         f.close()
         
         savesave = os.path.join(path, 'save.py')
         f = open(savesave, "w")
         f.write("name = '" + str(name) + "' \n")
         f.write("level = " + str(level) + "\n")
         f.write("health = " + str(health) + "\n")
         f.write("gold = " + str(gold) + "\n")
         f.write("attack = " + str(attack) + "\n")
         f.write("healthPotion = " + str(healthPotion) + "\n")
         f.write("swordSharpen = " + str(swordSharpen) + "\n")
         f.write("spear = " + str(spear) + "\n")
         f.write("food = " + str(food) + "\n")
         f.close()
         save = False
         continue
            

       elif save == False:
              print('''======MENU======
|==Game saved==|
What do you wish to do?
0--> inventory.
1--> play.
2--> shop.
3--> view profile.
4--> save progress.
q--> To start menu''')

              Input = input(': ')

              if Input.lower() == "q": #quits to start menu
                 break
              
#INVENTORY MENU------------------------------------------------------------------------------------------------------------------------------------------------------------#
              if Input == "0": #Health potion code: Done \ sword sharpen code: Done \ spear code: Done \ food code: uncoplete \
                 while True:
                    print('---------------------------------------------------------------------')
                    print('======INVENTORY======')
                    print('1--> Health potions: ',healthPotion)
                    print('2--> Sword sharpens: ',swordSharpen)
                    print('3--> Spears: ',spear)
                    print('4--> Food: ',food)
                    print('q--> To exit.')
                    Input = input('Press a number to use an item: ')

#INVENTORY= Health potion----------------------------------------------------------------------------------------------------------------------------------------------
                    if Input == "1":
                       print('---------------------------------------------------------------------')
                       print('''Name: Health potion.
Gives: full health.
Costs: 20 gold.''')
                       print('Do you want to use Health potion? y/n')
                       Input = input(': ')

                       if Input == "y" or Input == "yes":

                          if healthPotion < 1:#check if user dosnt have health potion.
                             print('---------------------------------------------------------------------')
                             print('you dont have any Health potions.')
                             continue
                           
                          elif healthPotion >= 1:                    #check if user has a health potion.
                             
                             if health < 100:                        #checks if health is lower then 100, to avoid rip off.
                                healthPotion -= 1
                                health = 100                         #sets health back too 100
                                with open("userLog","a") as f:
                                    now = date.today()
                                    date_now = now.strftime("%#d\%#m\%y")
                                    now1 = datetime.now()
                                    time_now = now1.strftime("%H:%M")
                                    f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                    f.write(str("Health potion - 1" + "\n"))
                                    f.write(str("Health potion = " + str(healthPotion) + "\n"))
                                    f.write(str("\n"))
                                    f.write(str("\n"))
                                    f.close()
                                print('---------------------------------------------------------------------')
                                print('You used Health potion successfuly.')
                                save = True                          #makes the game save when back in home menu.
                                continue

                             elif health >= 100:                     #checks if health is already full
                                print('Your health is already full.')
                                continue

                       elif Input == "n" or Input == "no":
                          continue

#INVENTORY= sword sharpen---------------------------------------------------------------------------------------------------------------------------------------------------------
                    if Input == "2":
                       print('---------------------------------------------------------------------')
                       print('''Name: Sword sharpen.
Gives: plus 5 attack.
Costs: 35 gold.''')
                       print('Do you want to use Sword sharpen? y/n')
                       Input = input(': ')

                       if Input == "y" or Input == "yes":

                          if swordSharpen < 1:                 #checks if user dosnt have one
                             print('---------------------------------------------------------------------')
                             print('you dont have any Sword sharpen.')
                             continue

                          elif swordSharpen >= 1:              #checks if user has one
                             swordSharpen -= 1
                             attack += 5
                             with open("userLog","a") as f:
                                 now = date.today()
                                 date_now = now.strftime("%#d\%#m\%y")
                                 now1 = datetime.now()
                                 time_now = now1.strftime("%H:%M")
                                 f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                 f.write(str("Sword sharpen - 1" + "\n"))
                                 f.write(str("Sword sharpen = " + str(swordSharpen) + "\n"))
                                 f.write(str("\n"))
                                 f.write(str("\n"))
                                 f.close()
                             print('---------------------------------------------------------------------')
                             print('You used Sword sharpen successfuly.')
                             save = True
                             continue

                       elif Input == "n" or Input == "no":
                          continue

#INVENTORY= spear------------------------------------------------------------------------------------------------------------------------------------------------------------------
                    if Input == "3":#spear
                       print('---------------------------------------------------------------------')
                       print('''Name: Spear.
Gives: insta kill.
Limit: 5 max.
Costs: 150 gold.''')
                       print('You can use Spear in battle')
                       Input = input('press q to go back: ')

                       if Input.lower() == "q":
                          continue

#INVENTORY= food-------------------------------------------------------------------------------------------------------------------------------------------------------
                    if Input == "4":
                       print('---------------------------------------------------------------------')
                       print('''Name: Food.
Gives: 10 health.
Costs: 10 gold.''')
                       print('Do you want to use Food? y/n')
                       Input = input(': ')

                       if Input == "y" or Input == "yes":

                          if food < 1:#checks if user dosnt have food
                             print('---------------------------------------------------------------------')
                             print('you dont have any Food.')
                             continue

                          elif food >= 1:#checks if user has food

                             if health < 100:#checks if health is lower then 100
                                food -= 1
                                health += 10
                                with open("userLog","a") as f:
                                    now = date.today()
                                    date_now = now.strftime("%#d\%#m\%y")
                                    now1 = datetime.now()
                                    time_now = now1.strftime("%H:%M")
                                    f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                    f.write(str("Food - 1" + "\n"))
                                    f.write(str("Food = " + str(food) + "\n"))
                                    f.write(str("\n"))
                                    f.write(str("\n"))
                                    f.close()
                                print('---------------------------------------------------------------------')
                                print('You used Food successfuly.')
                                save = True
                                continue

                             elif health >= 100:#checks if health is full
                                print('Your health is already full!')
                                continue

                       elif Input == "n" or Input == "no":
                          continue

                    if Input.lower() == "q":
                      break


#PLAY-----------------------------------------------------------------------------------------------------------------------------------------------------------------#
              if Input == "1":
                 while True:
                    previous = int(0)
                    print('---------------------------------------------------------------------')
                    print('You are in the game menu, Enter game? y/n?')
                    Input = input(': ')

                    if Input == "y":

                       event = int()

                       while event == int():
                          if health < 1:
                             print('---------------------------------------------------------------------')
                             print('You died, you will be given a new life')

                             level = 0
                             health = 100
                             gold = 50
                             attack = 15
                             healthPotion = 0
                             swordSharpen = 0
                             spear = 0
                             food = 0

                             today = date.today()
                             today1 = today.strftime("%#d/%#m/%Y")#////////////////////////////////!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                             yesterday = int(0)

                             f = open("timeSave.py","w")
                             f.write("today = " + str(today1) + "\n")
                             f.write("yesterday = " + str(yesterday) + "\n")
                             f.close()

                             f = open("save.py","w")
                             f.write("level = " + str(level) + "\n")
                             f.write("health = " + str(health) + "\n")
                             f.write("gold = " + str(gold) + "\n")
                             f.write("attack = " + str(attack) + "\n")
                             f.write("healthPotion = " + str(healthPotion) + "\n")
                             f.write("swordSharpen = " + str(swordSharpen) + "\n")
                             f.write("spear = " + str(spear) + "\n")
                             f.write("food = " + str(food) + "\n")
                             f.close()
                             continue

                          elif health > 1:
                              event = random.randrange(1, 4) #4 == 3

#small goblem====================================================================================================
                              while event == int(1):
                                 if previous == int(1): #if this event was just up
                                    event = int()
                                 else:
                                    print('---------------------------------------------------------------------')
                                    print('======Small goblem======')
                                    print('you have been brought into a fight against a small goblem')
                                    print('Defeat reward = +5 Gold.')
                                    INPUT =input("do you want to attack it? y/n: ")

                                    if INPUT.lower() == "y":
                                       print('')
                                       print('You easly punched the goblem in the face and cut him open.')
                                       print('You recieved +5 Gold.')
                                       gold += 5
                                       level += 1
                                       print('') #gap in text
                                       print('Level:',level)
                                       print('Health:',health)
                                       print('Gold:',gold)
                                       print('ATTACK:',attack)
                                       with open("userLog","a") as f:
                                          now = date.today()
                                          date_now = now.strftime("%#d\%#m\%y")
                                          now1 = datetime.now()
                                          time_now = now1.strftime("%H:%M")
                                          f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                          f.write(str("======Small goblem======" + "\n"))
                                          f.write(str("User defeated Small goblem " + "\n"))
                                          f.write(str("Gold + 5 " + "\n"))
                                          f.write(str("Level + 1 " + "\n"))
                                          f.write(str("Gold = " + str(gold) + "\n"))
                                          f.write(str("Level = " + str(level) + "\n"))
                                          f.write(str("\n"))
                                          f.write(str("\n"))
                                          f.close()
                                       print('')
                                       previous = int(1)
                                       save = True
                                       event =int()

                                    elif INPUT.lower() =="n":
                                       print('')
                                       print('You ran away from the enemy safly')
                                       print('')
                                       previous = int(1)
                                       event =int()

                                    elif INPUT.lower() =="q":
                                       break

#medium goblem===================================================================================================
                              while event == int(2):
                                 if previous == int(2):
                                    event = int()
                                 else:
                                    enemyHealth = random.randrange(15, 30)
                                    if attack <= 15:
                                       print('---------------------------------------------------------------------')
                                       print('WARNING: This enemy may have a higher damage resistance')
                                       print('         It is recommended to have atlest 20 damage.')
                                       
                                    print('---------------------------------------------------------------------')
                                    print('======Medium goblem======')
                                    print('You stumbled apon a medium goblem')
                                    print('Do you wish to attack it?')
                                    print('Defeat reward: +10 Gold.')
                                    Input = input(': ')

                                    if Input.lower() == "y":
                                       
                                       if attack >= (enemyHealth):
                                          print('You tore the goblems head off and did a victory dance!')
                                          gold += 10
                                          level += 1
                                          print('')
                                          print('Level:',level)
                                          print('Health:',health)
                                          print('Gold:',gold)
                                          print('ATTACK:',attack)
                                          with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                                
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("======Medium goblem======" + "\n"))
                                             f.write(str("User defeated medium goblem " + "\n"))
                                             f.write(str("Gold + 10 " + "\n"))
                                             f.write(str("Level + 1 " + "\n"))
                                             f.write(str("Gold = " + str(gold) + "\n"))
                                             f.write(str("Level = " + str(level) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                          print('')
                                          previous = int(2)
                                          event = int()

                                       elif attack <= (enemyHealth):
                                              print('')
                                              print('The goblem grabed your head and tryed to twist it off but failed.')
                                              print('You managed to get away with minor scratches.')
                                              print('')
                                              health -= 5
                                              print('Level:',level)
                                              print('Health:',health)
                                              print('Gold:',gold)
                                              print('ATTACK:',attack)
                                              with open("userLog","a") as f:
                                                now = date.today()
                                                date_now = now.strftime("%#d\%#m\%y")
                                                now1 = datetime.now()
                                                time_now = now1.strftime("%H:%M")
                                                
                                                f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                f.write(str("======Medium goblem======" + "\n"))
                                                f.write(str("User was defeated by medium goblem " + "\n"))
                                                f.write(str("Health - 5 " + "\n"))
                                                f.write(str("Health = " + str(health) + "\n"))
                                                f.write(str("\n"))
                                                f.write(str("\n"))
                                                f.close()
                                              print('')
                                              previous = int(2)
                                              save = True
                                              event = int()

                                    elif Input.lower() == "n":
                                       print('')
                                       print('You ran away from the medium goblem, and got home in one piece.')
                                       print('')
                                       previous = int(2)
                                       event = int()

                                    elif Input.lower() == "q":
                                       break
                                       


#deamon==========================================================================================================

                              while event == int(3):
                                if previous == int(3):
                                   event = int()
                                else:
                                   enemyHealth = random.randrange(30, 45)
                                   if attack <= 30:
                                      print('---------------------------------------------------------------------')
                                      print('WARNING: This enemy may have a higher damage resistance')
                                      print('         It is recommended to have atlest 35 damage.')

                                   print('---------------------------------------------------------------------')
                                   print('======Deamon======')
                                   print('You found yourself staring into the eyes of a deamon.')
                                   INPUT = input("Would you like to attack it? y/n: ")

                                   if INPUT.lower() =="y":
                                       
                                       if attack >= (enemyHealth):
                                           give_health = random.randrange(1, 3)#1-2
                                           print('')
                                           print('You managed to stabe the deamon in the face and kill him with 1 mighty blow.')
                                           print('You recieved 15 gold')
                                           if give_health == 1:
                                              print('And found a health potion!')
                                              healthPotion += 1
                                           gold += 15
                                           level += 2
                                           print('')
                                           print('Level:',level)
                                           print('Health:',health)
                                           print('Gold:',gold)
                                           print('ATTACK:',attack)
                                           with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                             
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("======deamon======" + "\n"))
                                             f.write(str("User defeated deamon " + "\n"))
                                             f.write(str("Gold + 15 " + "\n"))
                                             f.write(str("Level + 2 " + "\n"))
                                             f.write(str("Gold = " + str(gold) + "\n"))
                                             f.write(str("Level = " + str(level) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             if give_health == 1:
                                                f.write(str("Health potion + 1" + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                           print('')
                                           previous = int(3)
                                           event = int()

                                       elif attack <= (enemyHealth):
                                           print('')
                                           print('the deamon kicked you and scard you.')
                                           print('')
                                           health -= 10
                                           print('Level:',level)
                                           print('Health:',health)
                                           print('Gold:',gold)
                                           print('ATTACK:',attack)
                                           with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                             
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("======deamon======" + "\n"))
                                             f.write(str("User was defeated by deamon " + "\n"))
                                             f.write(str("Health - 10 " + "\n"))
                                             f.write(str("Health = " + str(health) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                           print('')
                                           previous = int(3)
                                           save = True
                                           event = int()
                                                   
                                   elif INPUT.lower() =="n":
                                       print('')
                                       print('You ran away from the deamon, and got home in one piece.')
                                       print('')
                                       previous = int(3)
                                       event = int()

                                   elif INPUT.lower() =="q":
                                          break

                    elif Input == "n":
                       break

#SHOP-----------------------------------------------------------------------------------------------------------------------------------------------------------------#
              if Input == "2":
                  
                  while True:

                      item = str('')
                      amount = int(0)
                      price = int(0)
                      
                      items = ['1 health potion','3 spear', '2 sword sharpen','4 food']
                      items2 = ['2 sword sharpen','4 food', '1 health potion','3 spear']

                      items = (random.choice(items))
                      items2 = (random.choice(items2))
                      
                      if items == items2:                                                                           #if item is the same in item2 then try again.
                          continue
                      else:                                                                                         #if items was different from items2
                          print('---------------------------------------------------------------------')
                          print('======SHOP======')
                          print('Gold',gold)
                          print('this is what i have to offer.')
                          print('q or quit to exit.')
                          print(items)                                                                              #prints the selected items
                          print(items2)                                                                             #prints the selected items2
                          Input = input('Press a number to buy: ')                                                  #gives user choice of what they want

#health potion code, price of one health potion 20$====================================================================================================================
                          if Input == "1":                                                                          #if user enters 1...
                              if items == "1 health potion" or items2 == "1 health potion":                         #if it is one of the items listed...
                                 while True:
                                  item = str('health potion\s')                                                     #set item to health potion...
                                  try:
                                     print('How many',item,'do you want?')                                          #asks how many of the item you want...
                                     amount = int(input(': '))                                                      #amount is what ever the user enters...
                                  except ValueError:
                                     print('---------------------------------------------------------------------')
                                     print('Please dont use letters.')
                                     print('---------------------------------------------------------------------')
                                     continue
                                  price = 20 * amount                                                               #price = 20 x the amount of items you want...
                                  print('would you like to purchas',item,' x',amount,' for',price,'gold? y/n')      #confirms purchas of item, amount, price...
                                  Input = input(': ')                                                               #gets yes or no answer for purchase...

                                  if Input.lower() == "y" or Input.lower() == "yes":                                #if user enters y, yes...
                                      
                                      if gold < price:                                                              #check if user dose not have enough gold...
                                          print('---------------------------------------------------------------------')
                                          print('Sorry you dont have enough gold for',amount, item,'.')             #if user dose not have enough gold tell them...
                                          break                                                                     #then continue back to start...
                                      
                                      elif gold >= price:                                                           #else if user has enough gold...
                                          print('---------------------------------------------------------------------')
                                          print('Your purchas was successful!')                                     #tell them it was successfully bought...
                                          healthPotion += amount                                                    #give user the amount purchased of item...
                                          gold -= price                                                             #take price away from gold...
                                          with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("Health potion + " + str(amount) + "\n"))
                                             f.write(str("Health potion = " + str(healthPotion) + "\n"))
                                             f.write(str("Gold - " + str(price) + "\n"))
                                             f.write(str("Gold = " + str(gold) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                             save = True
                                          print('Anything else?')                                                   #prints anything else...
                                          break                                                                     #continues to start...
                                      
                                  elif Input.lower() == "n" or Input.lower() == "no":                               #else if user enters n, no...
                                      print('Anything else?')                                                       #print anything else...
                                      break                                                                         #continues to start...

                              else:                                                                                 #else if item isnt listed...
                                  continue                                                                          #send user back to start.
                              
#sword sharpen code, price of 1 sword sharpen 35$======================================================================================================================
                          elif Input == "2":
                              if items == "2 sword sharpen" or items2 == "2 sword sharpen":
                                 while True:
                                  item = str('sword sharpen\s')
                                  try:
                                     print('How many',item,'do you want?')
                                     amount = int(input(': '))
                                  except ValueError:
                                     print('---------------------------------------------------------------------')
                                     print('Please dont use letters.')
                                     print('---------------------------------------------------------------------')
                                     continue
                                  price = 35 * amount
                                  print('would you like to purchas',item,' x',amount,' for',price,'gold? y/n')
                                  Input = input(': ')

                                  if Input == "y":
                                      
                                      if gold < price:
                                          print('---------------------------------------------------------------------')
                                          print('Sorry you dont have enough gold for',amount, item,'.')
                                          break
                                      elif gold >= price:
                                          print('---------------------------------------------------------------------')
                                          print('Your purchas was successful!')
                                          swordSharpen += amount
                                          gold -= price
                                          with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("Sword sharpen + " + str(amount) + "\n"))
                                             f.write(str("Sword sharpen = " + str(swordSharpen) + "\n"))
                                             f.write(str("Gold - " + str(price) + "\n"))
                                             f.write(str("Gold = " + str(gold) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                             save = True
                                          print('Anything else?')
                                          break

                                  elif Input == "n":
                                      print('Anything else?')
                                      break

                              else:
                                  continue

#spear code, price of 1 spear 150$ can only get 5 per day==============================================================================================================
                          elif Input == "3":
                              if items == "3 spear" or items2 == "3 spear":
                                 if yesterday != today:
                                    if spear < 5:
                                       while True:
                                        item = str('spear\s')
                                        try:
                                           print('How many',item,'do you want? (max buy:',5 - spear,')')
                                           amount = int(input(': '))
                                        except ValueError:
                                           print('---------------------------------------------------------------------')
                                           print('Please dont use letters.')
                                           print('---------------------------------------------------------------------')
                                           continue
                                        if (spear + amount) > 5: #if how many spears plus how many you want goes over 5...
                                           print('---------------------------------------------------------------------')
                                           print('Sorry you cant have that many',item,'')
                                           break
                                        else:
                                           price = 150 * amount
                                           print('would you like to purchas',item,' x',amount,' for',price,'gold? y/n')
                                           Input = input(': ')

                                           if Input == "y":
                                               
                                               if gold < price:
                                                   print('---------------------------------------------------------------------')
                                                   print('Sorry you dont have enough gold for',amount, item,'.')
                                                   break
                                               elif gold >= price:
                                                   print('---------------------------------------------------------------------')
                                                   print('Your purchas was successful!')
                                                   spear += amount
                                                   gold -= price
                                                   with open("userLog","a") as f:
                                                      now = date.today()
                                                      date_now = now.strftime("%#d\%#m\%y")
                                                      now1 = datetime.now()
                                                      time_now = now1.strftime("%H:%M")
                                                      f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                      f.write(str("Spear + " + str(amount) + "\n"))
                                                      f.write(str("Spear = " + str(spear) + "\n"))
                                                      f.write(str("Gold - " + str(price) + "\n"))
                                                      f.write(str("Gold = " + str(gold) + "\n"))
                                                      f.write(str("\n"))
                                                      f.write(str("\n"))
                                                      f.close()

                                                      if spear == 5:
                                                         yesterday = date.today()
                                                         yesterday = yesterday.strftime("%#d/%#m/%Y")

                                                   save = True
                                                   print('Anything else?')#\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\!!!!!!!!!!!!!!!!!!!!!!!!!!!
                                                   break

                                           elif Input == "n":
                                               print('Anything else?')
                                               break
                                          
                                    elif spear >= 5:
                                       print('---------------------------------------------------------------------')
                                       print('''You have reached this items max limit!
Check back tommorrow to buy more.''')
                                       yesterday = date.today()
                                       yesterday = yesterday.strftime("%#d/%#m/%Y")
                                       save = True
                                       break
                                    
                                 elif yesterday == today:
                                    print('---------------------------------------------------------------------')
                                    print('''You have reached this items max limit!
Check back tommorrow to buy more.''')
                                    yesterday = date.today()
                                    yesterday = yesterday.strftime("%#d/%#m/%Y")
                                    save = True
                                    break

                              else:
                                  continue

#Food code, price of one health potion 10$=============================================================================================================================
                          if Input == "4":                                                                          #if user enters 1...
                              if items == "4 food" or items2 == "4 food":                                           #if it is one of the items listed...
                                 while True:
                                  item = str('Food')                                                                #set item to health potion...
                                  try:
                                     print('How many',item,'do you want?')                                          #asks how many of the item you want...
                                     amount = int(input(': '))                                                      #amount is what ever the user enters...
                                  except ValueError:
                                     print('---------------------------------------------------------------------')
                                     print('Please dont use letters.')
                                     print('---------------------------------------------------------------------')
                                     continue
                                  price = 10 * amount                                                               #price = 20 x the amount of items you want...
                                  print('would you like to purchas',item,' x',amount,' for',price,'gold? y/n')      #confirms purchas of item, amount, price...
                                  Input = input(': ')                                                               #gets yes or no answer for purchase...

                                  if Input.lower() == "y" or Input.lower() == "yes":                                #if user enters y, yes...
                                      
                                      if gold < price:                                                              #check if user dose not have enough gold...
                                          print('Sorry you dont have enough gold for',amount, item,'.')             #if user dose not have enough gold tell them...
                                          break                                                                     #then continue back to start...
                                      
                                      elif gold >= price:
                                          print('---------------------------------------------------------------------')#else if user has enough gold...
                                          print('Your purchas was successful!')                                     #tell them it was successfully bought...
                                          food += amount                                                            #give user the amount purchased of item...
                                          gold -= price                                                             #take price away from gold...
                                          with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("Food + " + str(amount) + "\n"))
                                             f.write(str("Food = " + str(food) + "\n"))
                                             f.write(str("Gold - " + str(price) + "\n"))
                                             f.write(str("Gold = " + str(gold) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                             save = True
                                          print('Anything else?')                                                   #prints anything else...
                                          break                                                                     #continues to start...
                                      
                                  elif Input.lower() == "n" or Input.lower() == "no":                               #else if user enters n, no...
                                      print('Anything else?')                                                       #print anything else...
                                      break                                                                         #continues to start...

                              else:                                                                                 #else if item isnt listed...
                                  continue                                                                          #send user back to start.

                          elif Input == "q" or Input == "quit":
                             break
                           
#VIEW PROFILE---------------------------------------------------------------------------------------------------------------------------------------------------------#
              elif Input == "3": #View profile.
                  print('---------------------------------------------------------------------')
                  print('======' + (name) +'\'s profile======') 
                  print('Level-',(level))
                  print('Health-',(health))
                  print('Gold-',(gold))
                  print('Attack-',(attack))
                  print('')
                  print('======' + (name) +'\'s inventory======')
                  print('Health potion = ',healthPotion)
                  print('Sword sharpen = ',swordSharpen)
                  print('Spear = ',spear)
                  print('Food = ',food)
                  
                  print('\npress ENTER to continue.')
                  Input = input('')
                  pass

#SAVE PROGRESS--------------------------------------------------------------------------------------------------------------------------------------------------------#
              elif Input == "4": #Save progress.
                 print('---------------------------------------------------------------------')

                 path = os.getcwd() + r'\saves'

                 print('Saving new data...')
                 today = date.today()
                 today1 = today.strftime("%#d/%#m/%Y")

                 savetime = os.path.join(path, 'timesave.py')
                 f = open(savetime,"w")
                 f.write("today = " + str(today1) + "\n")
                 f.write("yesterday = " + str(yesterday) + "\n")
                 f.close()

                 savesave = os.path.join(path, 'save.py')
                 f = open(savesave, "w")
                 f.write("name = '" + str(name) + "' \n")
                 f.write("level = " + str(level) + "\n")
                 f.write("health = " + str(health) + "\n")
                 f.write("gold = " + str(gold) + "\n")
                 f.write("attack = " + str(attack) + "\n")
                 f.write("healthPotion = " + str(healthPotion) + "\n")
                 f.write("swordSharpen = " + str(swordSharpen) + "\n")
                 f.write("spear = " + str(spear) + "\n")
                 f.write("food = " + str(food) + "\n")
                 f.close()
                 
                 print('Save successful!')
                 save = False

#SAVE RESTART---------------------------------------------------------------------------------------------------------------------------------------------------------#
##                 print('---------------------------------------------------------------------')
##                 print('''Are you shore you want to complete this action?
##This will delete all saved data!!! y/n''')
##                 Input = input(': ')
##
##                 if Input.lower() == "y" or Input.lower() =="yes":
##                     print('---------------------------------------------------------------------')
##                     print('deleting save')
##                     level = 0
##                     health = 100
##                     gold = 50
##                     attack = 15
##                     healthPotion = 0
##                     swordSharpen = 0
##                     spear = 0
##                     food = 0
##
##                     today = date.today()
##                     today1 = today.strftime("%d/%m/%Y")
##                     yesterday = int(0)
##
##                     f = open("timeSave.py","w")
##                     f.write("today = " + str(today1) + "\n")
##                     f.write("yesterday = " + str(yesterday) + "\n")
##                     f.close()
##                     
##                     f = open("save.py","w")
##                     print('What should we call you?')
##                     name = input(': ')
##                     f.write("name = '" + str(name) + "' \n")
##                     f.write("level = " + str(level) + "\n")
##                     f.write("health = " + str(health) + "\n")
##                     f.write("gold = " + str(gold) + "\n")
##                     f.write("attack = " + str(attack) + "\n")
##                     f.write("healthPotion = " + str(healthPotion) + "\n")
##                     f.write("swordSharpen = " + str(swordSharpen) + "\n")
##                     f.write("spear = " + str(spear) + "\n")
##                     f.write("food = " + str(food) + "\n")
##                     f.close()
##
##                     with open("userLog","a") as f:
##                        now = date.today()
##                        date_now = now.strftime("%d\%m\%y")
##                        now1 = datetime.now()
##                        time_now = now1.strftime("%H:%M")
##                        f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
##                        f.write(str("Game was restarted " + "\n"))
##                        f.write(str("\n"))
##                        f.write(str("\n"))
##                        f.close()
##                     print('New save succesfull')
##                     
##                 elif Input == "n" or Input =="no":
##                    break
##
###HELP-----------------------------------------------------------------------------------------------------------------------------------------------------------------#
##              elif Input == "6": #Help option.
##                 while True:
##                    print('---------------------------------------------------------------------')
##                    print('''Welcome to the help menu. Please tell me your issue using key words.
##For some help with what to search type info.
##To return to menu type quit.''')
##                    txt = input(': ')
##
##                    if 'purchases' in txt.lower():
##                       print('')
##                       print('''======Purchases======
##-If you are having trouble buying in game content please
##check that you do have enough gold to do so.
##
##-After purchasing something from the shop it goes to your
##inventory, please check for it their.
##
##-If you do have enough gold and you cant find the item in
##your inventory please check that their is'nt a limit by
##heading to your inventory and look at the info
##of the item you are trying to purchase, if their is'nt a time
##limite you may be facing a bug, please report this to
##ejmultigames@gmail.com''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##
##                    elif 'support' in txt.lower():
##                       print('')
##                       print('''======support======
##For support, for anything with this game you may contact
##ejmultigames@gmail.com
##
##In order to sort out the emails effectivly please lable
##your email with the problem and the game it was in.
##E.G. subject: Bug Medieval events.''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##
##                    elif 'info' in txt.lower():
##                       print('')
##                       print('''======Info======
##try searching...
##
##==technical help==
##purchases
##support
##
##==ingame knowledge==
##Gold
##Health
##Attack
##Spear
##Food
##deamon
##small goblem
##''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##
##                    elif 'gold' in txt.lower():
##                       print('')
##                       print('''======Gold======
##-This may be the most important thing you will need
##in this game!
##
##-Gold allowes you to purchase tons of goods including
##health potion and sword sharpenings''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##
##                    elif 'health' in txt.lower():
##                       print('')
##                       print('''======Health======
##-Health is your players health, run out of this and you die.
##
##-In order to get health you need to buy health potions, to buy
##health potions you need gold.''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##
##                    elif 'attack' in txt.lower():
##                       print('')
##                       print('''======Attack======
##-When you are first given a profile you recieve 15 attack points.
##In order to get more you need to buy sword sharpens these are
##bout with gold and give you plus 5 attack points.''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##
##                    elif 'spear' in txt.lower():
##                       print('')
##                       print('''======Spear======
##-The spear is a very high tech wepon it kills its enemys instantly!.
##
##-This wepon dose not come cheap, you can only ever own 5, you can only
##ever buy 5 a day. the spear costs gold.''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##
##                    elif 'food' in txt.lower():
##                       print('')
##                       print('''======Food======
##-Food is used to heal yourself by 10.
##it costs a small bit of gold''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##
##                    elif 'deamon' in txt.lower():
##                       print('')
##                       print('''======Deamon======
##-The deamon is considerd a higher lvl enemy, you will need to buy
##sword sharpenings to defeat it unless your incredeply lucky their
##is a 1 in 30 chance that you will defeat it without buying sword
##sharpenings. Atlest 2 sword sharpening are recommended.''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##
##                    elif 'quit' in txt.lower():
##                       break
##
##                    else:
##                       options = ['info','support','purchases','gold','health','attack','spear','food','deamon','small goblem']
##                       check = txt[:3]
##                       res = [idx for idx in options if idx[:3].lower() == check.lower()]
##                       if res == []:
##                          check = txt[:2]
##                          res = [idx for idx in options if idx[:2].lower() == check.lower()]
##                          if res == []:
##                             check = txt[0]
##                             res = [idx for idx in options if idx[0].lower() == check.lower()]
##                             if res == []:
##                                res = "[No Resolts Found]"
##                       print('')
##                       print('======UNKNOWN ERROR======')
##                       print('Sorry their was no resaults for \'',txt,'\'...')
##                       print('Did you mean: ' + str(res))
##                       print('')
##                       print('''If not try searching info!
##If you belive theirs a problem, please place a report to
##ejmultigames@gmail.com''')
##                       print('\npress ENTER to continue.')
##                       Input = input('')
##                       pass
##                 
##             
#END------------------------------------------------------------------------------------------------------------------------------------------------------------------#
