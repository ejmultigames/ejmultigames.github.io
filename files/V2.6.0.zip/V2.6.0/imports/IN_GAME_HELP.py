#Command for use:
#UPDATE_CHECK.Check_Connection()

#Current errors:
#0

#Status:
#Working...

def Game_Help():
    #import imports
    #from imports import IN_GAME_HELP
    while True:
        print('---------------------------------------------------------------------')
        print('''Welcome to the help menu. Please tell me your issue using key words.
For some help with what to search type info.
To return to menu type quit.''')
        try:
            txt = input(': ')

            if 'purchases' in txt.lower():
               print('')
               print('''======Purchases======
-If you are having trouble buying in game content please
check that you do have enough gold to do so.

-After purchasing something from the shop it goes to your
inventory, please check for it their.

-If you do have enough gold and you cant find the item in
your inventory please check that their is'nt a limit by
heading to your inventory and look at the info
of the item you are trying to purchase, if their is'nt a time
limite you may be facing a bug, please report this to
ejmultigames@gmail.com''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'support' in txt.lower():
               print('')
               print('''======support======
For support, for anything with this game you may contact
ejmultigames@gmail.com

In order to sort out the emails effectivly please lable
your email with the problem and the game it was in.
E.G. subject: Bug Medieval events.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'info' in txt.lower():
               print('')
               print('''======Info======
try searching...

==Technical help==
purchases
support

==Ingame knowledge==
Gold
Health
Attack
Spear
Food
deamon
small goblem
medium goblem
''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'gold' in txt.lower():
               print('')
               print('''======Gold======
-This may be the most important thing you will need
in this game!

-Gold allowes you to purchase tons of goods including
health potion and sword sharpenings''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'health' in txt.lower():
               print('')
               print('''======Health======
-Health is your players health, run out of this and you die.

-In order to get health you need to buy health potions, to buy
health potions you need gold.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'attack' in txt.lower():
               print('')
               print('''======Attack======
-When you are first given a profile you recieve 15 attack points.
In order to get more you need to buy sword sharpens these are
bout with gold and give you plus 5 attack points.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'spear' in txt.lower():
               print('')
               print('''======Spear======
-The spear is a very high tech wepon it kills its enemys instantly!.

-This wepon dose not come cheap, you can only ever own 5, you can only
ever buy 5 a day. the spear costs gold.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'food' in txt.lower():
               print('')
               print('''======Food======
-Food is used to heal yourself by 10.
it costs a small bit of gold.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass
            
            elif 'small goblem' in txt.lower():
                print('')
                print('''======Small goblem======
-The small goblem is one of the lowest enemys in the game, it is
 an instant kill enemy or you can run away if you wish...
 
-You will be rewarded 5 gold and 1 lvl by defeating it.''')
                print('\npress ENTER to continue.')
                Input = input('')
                pass

            elif 'medium goblem' in txt.lower():
                print('')
                print('''======medium goblem======
-The medium goblem is the first hardest enemys in the game.

-The medium goblem has a health of 15 - 30 so be carful.
 
-You will be rewarded 10 gold and 1 lvl by defeating it.''')
                print('\npress ENTER to continue.')
                Input = input('')
                pass

            elif 'quit' in txt.lower():
                break

            elif 'deamon' in txt.lower():
               print('')
               print('''======Deamon======
-The deamon is the forth hardest enemy in the game.

-The deamon has a health of 30 - 45 so be carful.

-You will be rewarded 15 gold and 2 lvl by defeating it.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'quit' in txt.lower():
                break
                

            else:
               options = ['info','support','purchases','gold','health','attack','spear','food','deamon','small goblem','medium goblem']
               check = txt[:3]
               res = [idx for idx in options if idx[:3].lower() == check.lower()]
               if res == []:
                  check = txt[:2]
                  res = [idx for idx in options if idx[:2].lower() == check.lower()]
                  if res == []:
                     check = txt[0]
                     res = [idx for idx in options if idx[0].lower() == check.lower()]
                     if res == []:
                        res = "[No Resolts Found]"

            
               print('')
               print('======UNKNOWN ERROR======')
               print('Sorry their was no resaults for \'',txt,'\'...')
               print('Did you mean: ' + str(res))
               print('')
               print('''If not try searching info!
If you belive theirs a problem, please contact support.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

        except IndexError:
            pass
