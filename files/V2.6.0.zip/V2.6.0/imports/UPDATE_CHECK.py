#Command for use:
#UPDATE_CHECK.Check_Connection()

#Current errors:
#0...

#status:
#Working...

import time
import webbrowser
import socket

def Check_Connection(): #working
    try:
        socket.create_connection(("www.google.com", 80)) #checks to see if it can connect to a website. if it can we have internet!
        print('=====================================================================')
        print('internet connected checking for update please wait')
        print('=====================================================================')
        Update_Check()
        
    except OSError:
        print('=====================================================================')
        print('ERROR 4: No internet, Check for update unsuccessful.')
        print('=====================================================================')
        pass



def Update_Check():
    try:
        webbrowser.open('http://ejmultigames.github.io/downloads/Download270.html', new=0, autoraise=True)
        print('''Please install the update.
This update includes bug fixes and better performance.''')
        time.sleep(5)
        pass

    except OSError:
        print('You are all up to date!')
        print('=====================================================================')
        
