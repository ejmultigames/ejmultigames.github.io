#Command for use:
#NEW_USER_START.Configure_User()

#Current errors:
#0...

#Status:
#Working...


#main system imports...
import time
import os
import random

#date/ time handling imports...
from datetime import date
from datetime import datetime

def Configure_User(): #working
    print('Getting file destination info...\n')
    path = os.getcwd() + r'\saves'

    print('Setting defult settings...\n')
    level = 0
    health = 100
    gold = 50
    attack = 15
    healthPotion = 0
    swordSharpen = 0
    spear = 0
    food = 0

    time.sleep(0.5)

    print('Getting the time...\n')
    today = date.today()
    today1 = today.strftime("%#d/%#m/%Y")
    yesterday = int(0)
    
    print('saving the time...\n')
    savetime = os.path.join(path, 'timesave.py')
    f = open(savetime, "w")
    f.write("today = " + str(today1) + "\n")
    f.write("yesterday = " + str(yesterday) + "\n")
    f.close()

    time.sleep(0.5)

    print('saveing player variables...\n')
    savesave = os.path.join(path, 'save.py')
    f = open(savesave, "w")
    print('What should we call you?')
    name = input(': ')
    f.write("name = '" + str(name) + "' \n")
    f.write("level = " + str(level) + "\n")
    f.write("health = " + str(health) + "\n")
    f.write("gold = " + str(gold) + "\n")
    f.write("attack = " + str(attack) + "\n")
    f.write("healthPotion = " + str(healthPotion) + "\n")
    f.write("swordSharpen = " + str(swordSharpen) + "\n")
    f.write("spear = " + str(spear) + "\n")
    f.write("food = " + str(food) + "\n")
    f.close()

    time.sleep(0.5)

    print('\nCreating user log...\n')
    with open("userLog","a") as f:      
      now = date.today()
      date_now = now.strftime("%#d\%#m\%y")
      now1 = datetime.now()
      time_now = now1.strftime("%H:%M")

      ID = random.randrange(1000, 9999)
      
      f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
      f.write(str("======New user======" + "\n"))
      f.write(str("Name = " + str(name) + "\n"))
      f.write(str("ID = " + str(ID) + "\n"))
      f.write(str("====================" + "\n"))
      f.write(str("\n"))
      f.write(str("\n"))
      f.close()


    print('finished')  
    print('Please restart')
    exit()
