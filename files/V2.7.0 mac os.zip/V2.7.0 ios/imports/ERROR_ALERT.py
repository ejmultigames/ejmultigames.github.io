#How to use these modules...

#ERROR_ALERT.Test()             prints error content contained in def test():

#print("something", ERROR_ALERT.value)  prints a value or a def  



def No_Connection():
    print('INTERNET ERROR:')
    print('You are not connected to the internet.')

def Invalid_Input():
    print('INPUT ERROR:')
    print('The input you have given is not recognised please read')
    print('what to press properly and retry.')

def Test():
    from saves.save import health
    if health >= 100:
        print('health is 100%')

    else:
        print('health is below 100%')
