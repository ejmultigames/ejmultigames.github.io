import os

def Admin_Sign_In():
    try:
        filepath = 'C:/Users/sales/Documents/ADMIN_PASS'

        with open(filepath, 'r') as f:
            file_contents = f.read()

            file_contents = file_contents.strip()

            print('Enter admin password.')
            user_input = input(': ')

            if user_input == file_contents:
                print('access granted')
                PASS = True
                
                path = os.getcwd() + r'\saves'
                adminpass = os.path.join(path, 'ADMIN_LOGIN.py')
                f = open(adminpass, "w")
                f.write("PASS = " + str(PASS) + "\n")
                f.close()

            else:
                PASS = False
                
                path = os.getcwd() + r'\saves'
                adminpass = os.path.join(path, 'ADMIN_LOGIN.py')
                f = open(adminpass, "w")
                f.write("PASS = " + str(PASS) + "\n")
                f.close()

                
    except FileNotFoundError:
        print('You do not have permisson to use this feature.')
        pass

def Admin_Sign_Out():
    try:      
        path = os.getcwd() + r'\saves'
        
        adminSignOut = os.path.join(path, 'ADMIN_LOGIN.py')
        f = open(adminSignOut, "w")
        f.write("")
        f.close()
                
    except FileNotFoundError:
        print('You do not have permisson to use this feature.')
        pass
