#Command for use:
#USER_RESTART.Restart_Account()

#Current errors:
#0...

#Status:
#Working...

#main system imports...
import time
import os
import random

#date/ time handling imports...
from datetime import date
from datetime import datetime

def Restart_Account():#unknown
     print('''Are you shore you want to complete this action?
This will delete all saved data!!! y/n''')
     Input = input(': ')

     if Input.lower() == "y" or Input.lower() =="yes":
         print('---------------------------------------------------------------------')
         print('deleting save')

         path = os.getcwd() + r'/saves'
         
         level = 0
         health = 100
         gold = 50
         healthPotion = 0
         swordSharpen = 0
         spear = 0
         food = 0
         wood = 0
         stone = 0
         iron = 0

         wood_owned = True
         wood_durability = 100
         wood_attack = 10
         
         stone_owned = False
         stone_durability = 100
         stone_attack = 50
         
         iron_owned = False
         iron_durability = 100
         iron_attack = 100

         today = date.today()
         today1 = today.strftime("%-d/%-m/%Y")
         yesterday = int(0)

         savetime = os.path.join(path, 'timesave.py')
         f = open(savetime, "w")
         f.write("today = " + str(today1) + "\n")
         f.write("yesterday = " + str(yesterday) + "\n")
         f.close()
         
         savesave = os.path.join(path, 'save.py')
         f = open(savesave, "w")
         print('What should we call you?')
         name = input(': ')
         f.write("name = '" + str(name) + "' \n")
         f.write("level = " + str(level) + "\n")
         f.write("health = " + str(health) + "\n")
         f.write("gold = " + str(gold) + "\n")
         f.write("healthPotion = " + str(healthPotion) + "\n")
         f.write("swordSharpen = " + str(swordSharpen) + "\n")
         f.write("spear = " + str(spear) + "\n")
         f.write("food = " + str(food) + "\n")
         f.write("wood = " + str(wood) + "\n")
         f.write("stone = " + str(stone) + "\n")
         f.write("iron = " + str(iron) + "\n")
         f.close()

         path2 = os.getcwd() + r'/saves/WEPONDS'

         wepond = os.path.join(path, 'ACTIVE_WEPOND.py')
         f = open(wepond, "w")
         f.write("activeWepond = 'WOODEN_SWORD'\n")
         f.close()


         saveWoodenSword = os.path.join(path2, 'WOODEN_SWORD.py')
         f = open(saveWoodenSword, "w")
         f.write("wood_owned = " + str(wood_owned) + "\n")
         f.write("wood_durability = " + str(wood_durability) + "\n")
         f.write("wood_attack = " + str(wood_attack) + "\n")
         f.close()

         saveStoneSword = os.path.join(path2, 'STONE_SWORD.py')
         f = open(saveStoneSword, "w")
         f.write("stone_owned = " + str(stone_owned) + "\n")
         f.write("stone_durability = " + str(stone_durability) + "\n")
         f.write("stone_attack = " + str(stone_attack) + "\n")
         f.close()

         saveIronSword = os.path.join(path2, 'IRON_SWORD.py')
         f = open(saveIronSword, "w")
         f.write("iron_owned = " + str(iron_owned) + "\n")
         f.write("iron_durability = " + str(iron_durability) + "\n")
         f.write("iron_attack = " + str(iron_attack) + "\n")
         f.close()

         with open("userLog","a") as f:
            now = date.today()
            date_now = now.strftime("%#d\%#m\%y")
            now1 = datetime.now()
            time_now = now1.strftime("%H:%M")
            f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
            f.write(str("Game was restarted " + "\n"))
            f.write(str("\n"))
            f.write(str("\n"))
            f.close()
            
         print('New save succesfull')
         
     elif Input == "n" or Input =="no":
        pass

