iron_owned = False
iron_durability = 100
iron_attack = 100
