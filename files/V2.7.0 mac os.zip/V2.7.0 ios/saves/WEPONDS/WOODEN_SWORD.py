wood_owned = True
wood_durability = 96
wood_attack = 10
