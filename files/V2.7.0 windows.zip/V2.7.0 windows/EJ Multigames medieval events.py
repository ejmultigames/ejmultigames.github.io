#PRESS F5 TO START.

#EJ Multigames: V2.7.0.0
#Medieval events: BETA V2.2.0.0



#You are permited to change game code. though
#revers engenering passwords and other game data
#will be taken as an offence. Unless you are
#willing to share ideas and improvments for it.
#Thank you, EJ. H

#More information in read me...












































































#NOTES:
#Add a time limit to buying spears, 5 purchasses daily.
#e.g. when user starts up the game python instantly loads the timeSave and save, if your a new user the program sends you down to get a save
#     python saves the current date as today, and yesterday as 0, in the game if user goes into shop and purchases 5 spears yesterday gets
#     saved as todays date aswell, if the yesterday and today dates are the same then user cant buy. until tomorow in which yesterday will
#     be different again.

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#IMPROVEMENTS:
#add an error exception with the shop. = complete

#fix the line that seperates menu from inventory = complete

#add a press enter to continue in profile view = complete

#fix all dates = complete

#add exception to help menu = complete

#fix timesave errors = complete

#make a book, every monster the user attackes makes them able to read about it! = uncomplete


print('Loading packages...')
try:
   #main system imports...
   import random
   import time
   import os
   import linecache
   import re
   from importlib import reload
   
   #date/ time handling imports...
   from datetime import date
   from datetime import datetime

   #custom module handling...
   import imports
   from imports import ERROR_ALERT, UPDATE_CHECK, IN_GAME_HELP, PASS_CHECK
   from imports.user_save_handling import USER_RESTART, NEW_USER_START

   #all wepond data
   import saves
   from saves.WEPONDS.WOODEN_SWORD import *
   from saves.WEPONDS.STONE_SWORD import *
   from saves.WEPONDS.IRON_SWORD import *
   from saves import ACTIVE_WEPOND

   #save load...
   from saves.save import *

   #time load...
   from saves.timesave import *

   #NO TOUCHING!!!
   from saves import ADMIN_LOGIN

except ImportError:#, ModuleNotFoundError, AttributeError, NameError):
   NEW_USER_START.Configure_User()

else:
 global save
 save = False
 global ErrorInfo
 ErrorInfo = ''
 print('')
 print('welcome to EJ Multigames',name,'!')
 while True:
   print('')
   print('---------------------------------------------------------------------')
   print('''<<START MENU>>
1--> Start!
2--> Check for update/ Requires internet.
3--> Help.
4--> restart progress.
5--> Quit game.''')
   Input = input(': ')

   if Input == "5":
      exit()

##   elif Input.lower() == "admin202":
##      reload(ADMIN_LOGIN)
##      print('''1--> Sign in.
##2--> Sign out.''')
##      Input = input(': ')
##
##      if Input == "1":
##         try:
##            if ADMIN_LOGIN.PASS == False:
##               print('''<ERROR>
##You are not qualified to use admin permissons.
##
##If this is a mistake please try restarting the
##program.
##''')
##               PASS_CHECK.Admin_Sign_In()
##
##            elif ADMIN_LOGIN.PASS == True:
##               print('You are signed in already!')
##
##            
##         except AttributeError:
##            print('You need to sign in...')
##            PASS_CHECK.Admin_Sign_In()
##            
##      elif Input == "2":
##         PASS_CHECK.Admin_Sign_Out()
##         print('''You where successfuly signed out!
##Restart to take affect.''')
      

   elif Input == "4":
      try:
         USER_RESTART.Restart_Account() #delets and restarts user acc
         print('______________________________________________________')
         print('Please open the game again for changes to take effect.')
         time.sleep(1)
         exit()
         
      except Exception as Error:
         Error = (Error,'MAIN GAME SAVE')
         print('==================================================')
         print('CRITICAL PROCESS ERROR:\nPLEASE CONTACT ejmultigames@gmail.com for support!\nError:',Error,'')
         print('==================================================')
         save = False

   elif Input == "3":
      try:
         IN_GAME_HELP.Game_Help()

      except Exception as Error:
         Error = (Error,'In game help')
         ErrorInfo = Error
         save = True
         print('===============')
         print('AN ERROR ACURED')
         print('===============')

#CHECK FOR SOFTWEAR UPDATE---------------------------------------------------------------------------------------------------------------------------------------------

   elif Input == "2":
      try:
         UPDATE_CHECK.Check_Connection()
      except Exception as Error:
         Error = (Error,'view profile')
         ErrorInfo = Error
         save = True
         print('===============')
         print('AN ERROR ACURED')
         print('===============')

#CHECK FOR SOFTWEAR UPDATE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#MAIN MENU-------------------------------------------------------------------------------------------------------------------------------------------------------------

   elif Input == "1":
#MAIN GAME SAVE--------------------------------------------------------------------

    while True:
       print('---------------------------------------------------------------------')
       if save == True:
          try:
             print('======================') 
             print('Saving your game!')
             print('======================')

             with open("Error Log.txt","a") as f:                          #opens (Error Log) as a apend file and...
                now = date.today()                                         #gets todays date.
                date_now = now.strftime("%#d\%#m\%y")                      #makes todays date show as 28/1/20 instead of 28/01/2020, which can couse errors.
                now1 = datetime.now()                                      #gets the time.
                time_now = now1.strftime("%H:%M")                          #makes the time show only hours and minutes.
                f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n")) #saves the date and time.
                f.write(str("======ERROR======" + "\n"))                   #saves a string.
                if ErrorInfo == '':                                        #if ErrorInfo is an empty string.
                   f.write('NO ERROR\'S')                                  #saves a string.
                else:                                                      #else if ErrorInfo is not empty.
                   f.write(str(ErrorInfo))                                 #saves the contents of ErrorInfo.
                f.write('\n\n')                                            #saves two spaces.
                f.close()                                                  #close the file to prevent unexpected errors.
                ErrorInfo = ''                                             #sets ErrorInfo back to defult.

             path = os.getcwd() + r'\saves'                                #The current working filepath plus saves add on, where saves should go.
            
             today = date.today()                                          #today = todays date.
             today1 = today.strftime("%#d/%#m/%Y")                         #makes today show as 28/1/20 instead of 28/01/2020, which can couse errors.

             savetime = os.path.join(path, 'timesave.py')                  #In the given path, finds a file (timesave) and...
             f = open(savetime,"w")                                        #opens it as a write file.
             f.write("today = " + str(today1) + "\n")                      #todays date save.
             f.write("yesterday = " + str(yesterday) + "\n")               #yesterdays date save.
             f.close()                                                     #close the save file to prevent unexpected errors.
            
             savesave = os.path.join(path, 'save.py')                      #finds a file (save.py) and...
             f = open(savesave, "w")
             f.write("name = '" + str(name) + "' \n")                      #player name save.
             f.write("level = " + str(level) + "\n")                       #player level save.
             f.write("health = " + str(health) + "\n")                     #player health save.
             f.write("gold = " + str(gold) + "\n")                         #player gold save.
             f.write("healthPotion = " + str(healthPotion) + "\n")         #item, healthpotion save.
             f.write("food = " + str(food) + "\n")                         #item, food save.
             f.write("wood = " + str(wood) + "\n")                         #item, wood save.
             f.write("stone = " + str(stone) + "\n")                       #item, stone save.
             f.write("iron = " + str(iron) + "\n")                         #item, iron save.
             f.close()                                                     #close the save file to prevent unexpected errors.

             path2 = os.getcwd() + r'\saves\WEPONDS'                       #The current working filepath plus saves\WEPONDS add on, where all wepond data should be stored.
            
             savewoodsword = os.path.join(path2, 'WOODEN_SWORD.py')        #In the given path finds (WOODEN_SWORD.py) and...
             f = open(savewoodsword, "w")                                  #opend it as a write file.
             f.write("wood_owned = " + str(wood_owned) + "\n")             #wooden sword owned save.
             f.write("wood_durability = " + str(wood_durability) + "\n")   #wooden sword durability save.
             f.write("wood_attack = " + str(wood_attack) + "\n")           #wooden sword attack save.
             f.close()                                                     #close the file to prevent unexpected errors.

             savestonesword = os.path.join(path2, 'STONE_SWORD.py')        #In the given path finds (STONE_SWORD.py) and...
             f = open(savestonesword, "w")                                 #opend it as a write file.
             f.write("stone_owned = " + str(stone_owned) + "\n")           #stone sword owned save.
             f.write("stone_durability = " + str(stone_durability) + "\n") #stone sword durability save.
             f.write("stone_attack = " + str(stone_attack) + "\n")         #stone sword attack save.
             f.close()                                                     #close the file to prevent unexpected errors.

             saveironsword = os.path.join(path2, 'IRON_SWORD.py')          #In the given path finds (IRON_SWORD.py) and...
             f = open(saveironsword, "w")                                  #opend it as a write file.
             f.write("iron_owned = " + str(iron_owned) + "\n")             #iron sword owned save.
             f.write("iron_durability = " + str(iron_durability) + "\n")   #iron sword durability save.
             f.write("iron_attack = " + str(iron_attack) + "\n")           #iron sword attack save.
             f.close()                                                     #close the file to prevent unexpected errors.
            
             save = False
             continue

          except Exception as Error:
            Error = (Error,'MAIN GAME SAVE')
            print('==================================================')
            print('CRITICAL PROCESS ERROR:\nPLEASE CONTACT ejmultigames@gmail.com for support!\nError:',Error,'')
            print('==================================================')
            save = False

#MAIN GAME SAVE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

       elif save == False:
              print('''======MENU======
What do you wish to do?
0--> inventory.
1--> play.
2--> shop.
3--> view profile.
4--> save progress.
q--> To start menu''')

              Input = input(': ')

              if Input.lower() == "q": #quits to start menu
                 break

#MAIN MENU^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
              
#INVENTORY MENU------------------------------------------------------------------------------------------------------------------------------------------------------------#

              if Input == "0": #Health potion code: Done \ sword sharpen code: Done \ spear code: Done \ food code: uncoplete \
                 try:
                    while True:
                       print('---------------------------------------------------------------------')
                       print('======INVENTORY======')
                       print('1--> Health potions: ',healthPotion)
                       print('2--> Food: ',food)
                       print('3--> Wood: ',wood)
                       print('4--> Stone: ',stone)
                       print('5--> Iron: ',iron)
                       print('q--> To exit.')
                       Input = input('Press a number to use an item: ')

#INVENTORY= HEALTH POTION----------------------------------------------------------------------------------------------------------------------------------------------

                       if Input == "1":
                          print('---------------------------------------------------------------------')
                          print('''Name: Health potion.
Gives: full health.
Costs: 20 gold.''')
                          print('Do you want to use Health potion? y/n')
                          Input = input(': ')

                          if Input == "y" or Input == "yes":

                             if healthPotion < 1:#check if user dosnt have health potion.
                                print('---------------------------------------------------------------------')
                                print('you dont have any Health potions.')
                                continue
                              
                             elif healthPotion >= 1:                    #check if user has a health potion.
                                
                                if health < 100:                        #checks if health is lower then 100, to avoid rip off.
                                   healthPotion -= 1
                                   health = 100                         #sets health back too 100
                                   with open("userLog","a") as f:
                                       now = date.today()
                                       date_now = now.strftime("%#d\%#m\%y")
                                       now1 = datetime.now()
                                       time_now = now1.strftime("%H:%M")
                                       f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                       f.write(str("Health potion - 1" + "\n"))
                                       f.write(str("Health potion = " + str(healthPotion) + "\n"))
                                       f.write(str("\n"))
                                       f.write(str("\n"))
                                       f.close()
                                   print('---------------------------------------------------------------------')
                                   print('You used Health potion successfuly.')
                                   save = True                          #makes the game save when back in home menu.
                                   continue

                                elif health >= 100:                     #checks if health is already full
                                   print('Your health is already full.')
                                   continue

                          elif Input == "n" or Input == "no":
                             continue

#INVENTORY= HEALTH POTION^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#INVENTORY= FOOD-------------------------------------------------------------------------------------------------------------------------------------------------------

                       if Input == "2":
                          print('---------------------------------------------------------------------')
                          print('''Name: Food.
Gives: 10 health.
Costs: 10 gold.''')
                          print('Do you want to use Food? y/n')
                          Input = input(': ')

                          if Input == "y" or Input == "yes":

                             if food < 1:#checks if user dose'nt have food.
                                print('---------------------------------------------------------------------')
                                print('you dont have any Food.')
                                continue

                             elif food >= 1:#checks if user has food.

                                if health < 100:#checks if health is lower then 100.
                                   food -= 1
                                   health += 5
                                   with open("userLog","a") as f:
                                       now = date.today()
                                       date_now = now.strftime("%#d\%#m\%y")
                                       now1 = datetime.now()
                                       time_now = now1.strftime("%H:%M")
                                       f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                       f.write(str("Food - 1\n"))
                                       f.write(str("Health + 5\n"))
                                       f.write(str("Food = " + str(food) + "\n"))
                                       f.write(str("Health = " + str(health) + "\n"))
                                       f.write(str("\n"))
                                       f.write(str("\n"))
                                       f.close()
                                   print('---------------------------------------------------------------------')
                                   print('You used Food successfuly.')
                                   save = True
                                   continue

                                elif health >= 100:#checks if health is full.
                                   print('Your health is already full!')
                                   continue

                          elif Input == "n" or Input == "no":
                             continue

#INVENTORY= FOOD^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#INVENTORY= WOOD-------------------------------------------------------------------------------------------------------------------------------------------------------

                       if Input == "3":
                          print('---------------------------------------------------------------------')
                          print('''Name: Wood.
Info: Repairs 5% of damage done to a wooden sword.
Gives: 5% Repair.
Shop cost: 25 gold.''')
                          if wood_owned == False:
                             print('You cant use this item until you buy a wooden sword.')
                             print('\npress ENTER to continue.')
                             Input = input('')
                             pass
                          elif wood_owned == True:
                             print('Do you want to use wood to repair wooden sword? y/n')
                             Input = input(': ')

                             if Input == "y" or Input == "yes":
                                print('How much wood do you wish to use?')
                                amount = int(input(': '))

                                if amount > wood:
                                   print('Sorry you dont have that much wood.')
                                   continue
                                 
                                elif amount <= wood:
                                   fixed = 5 * amount
                                   print('Do you want to use',amount,'wood to repair',fixed,'% damage? y/n')
                                   Input = input(': ')

                                   if Input.lower() == "y":
                                      if wood_durability >= 96:
                                         print('Wooden sword must have 95% damage to repair.')
                                         continue
                                      elif wood_durability <= 95:
                                         print('Used',amount,'wood to fix',fixed,'% damage')
                                         wood_durability += fixed
                                         save = True
                                         continue
                                   elif Input.lower() == "n":
                                      continue

#INVENTORY= WOOD^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#INVENTORY= STONE-------------------------------------------------------------------------------------------------------------------------------------------------------

                       if Input == "4":
                          print('---------------------------------------------------------------------')
                          print('''Name: Stone.
Info: Repairs 5% of damage done to a Stone sword.
Gives: 5% Repair.
Shop cost: 65 gold.''')
                          if stone_owned == False:
                             print('You cant use this item until you buy a stone sword.')
                             print('\npress ENTER to continue.')
                             Input = input('')
                             pass
                          elif stone_owned == True:
                             print('Do you want to use stone to repair stone sword? y/n')
                             Input = input(': ')

                             if Input == "y" or Input == "yes":
                                print('How much stone do you wish to use?')
                                amount = int(input(': '))

                                if amount > stone:
                                   print('Sorry you dont have that much stone.')
                                   continue
                                 
                                elif amount <= stone:
                                   fixed = 5 * amount
                                   print('Do you want to use',amount,'stone to repair',fixed,'% damage? y/n')
                                   Input = input(': ')

                                   if Input.lower() == "y":
                                      if stone_durability >= 96:
                                         print('Stone sword must have 95% damage to repair.')
                                         continue
                                      elif stone_durability <= 95:
                                         print('Used',amount,'stone to fix',fixed,'% damage')
                                         stone_durability += fixed
                                         save = True
                                         continue
                                   elif Input.lower() == "n":
                                      continue

#INVENTORY= STONE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                
#INVENTORY= IRON-------------------------------------------------------------------------------------------------------------------------------------------------------

                       if Input == "5":
                          print('---------------------------------------------------------------------')
                          print('''Name: Iron.
Info: Repairs 5% of damage done to a iron sword.
Gives: 5% Repair.
Shop cost: 65 gold.''')
                          if iron_owned == False:
                             print('You cant use this item until you buy a iron sword.')
                             print('\npress ENTER to continue.')
                             Input = input('')
                             pass
                          elif iron_owned == True:
                             print('Do you want to use iron to repair iron sword? y/n')
                             Input = input(': ')

                             if Input == "y" or Input == "yes":
                                print('How much iron do you wish to use?')
                                amount = int(input(': '))

                                if amount > iron:
                                   print('Sorry you dont have that much iron.')
                                   continue
                                 
                                elif amount <= iron:
                                   fixed = 5 * amount
                                   print('Do you want to use',amount,'iron to repair',fixed,'% damage? y/n')
                                   Input = input(': ')

                                   if Input.lower() == "y":
                                      if iron_durability >= 96:
                                         print('iron sword must have 95% damage to repair.')
                                         continue
                                      elif iron_durability <= 95:
                                         print('Used',amount,'iron to fix',fixed,'% damage')
                                         iron_durability += fixed
                                         save = True
                                         continue
                                   elif Input.lower() == "n":
                                      continue



                       if Input.lower() == "q":#inventory quit, dont touch.
                         break

                 except Exception as Error:
                    Error = (Error,'Inventory')
                    ErrorInfo = Error
                    save = True
                    print('===============')
                    print('AN ERROR ACURED')
                    print('===============')

#INVENTORY - IRON^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#PLAY-----------------------------------------------------------------------------------------------------------------------------------------------------------------#
#PRE-BATTLE CODE=====================================================================

              if Input == "1":
                 try:
                    while True:
                       previous = int(0)
                       print('---------------------------------------------------------------------')
                       print('''
1--> Battle!
2--> Change wepond.
q--> Return menu.
''')
                       Input = input(': ')

                       if Input == "1":

                          event = int()

                          while event == int():
                             if health < 1:
                                print('---------------------------------------------------------------------')
                                print('You died, you will be given a new life')
                                USER_RESTART.Restart_Account()
                                continue

                             elif health >= 1:#---------------------------------below code deals with durability of weponds.
                                reload(ACTIVE_WEPOND)
                                if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                   
                                   if wood_durability <= 0:
                                      print('Your wooden sword has broken!')
                                      wood_owned = False #set these 2 variables back to default.
                                      wood_durability = 100
                                      path = os.getcwd() + r'\saves'

                                      saveactivewepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                      f = open(saveactivewepond, "w")
                                      f.write("activeWepond = '' ")
                                      f.close()
                                      
                                      save = True
                                      continue
                                    
                                   elif wood_durability <= 20:
                                      print('Your durability is running low on wooden sword!')
                                      
                                      

                                elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':

                                   if stone_durability <= 0:
                                      print('Your stone sword has broken!')
                                      stone_owned = False
                                      stone_durability = 100
                                      save = True
                                      continue

                                   elif stone_durability <= 20:
                                      print('Your durability is running low on stone sword!')


                                elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':

                                   if iron_durability <= 0:
                                      print('Your iron sword has broken!')
                                      iron_owned = False
                                      iron_durability = 100
                                      continue

                                   elif iron_durability <= 20:
                                      print('Your durability is running low on iron sword!')
     

                                else:
                                   print('Please equip a wepond and return.')
                                   break
                                    
                                event = random.randrange(1, 4) #1 == 3
                                
#PRE-BATTLE CODE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#SMALL GOBLEM==========================================================================================================================================================

                                while event == int(1):
                                 if previous == int(1): #if this event was just up.
                                    event = int()
                                 else:
                                    print('---------------------------------------------------------------------')
                                    print('======Small goblem======')
                                    print('you have been brought into a fight against a small goblem')
                                    print('Defeat reward: +1 lvl +5 Gold.')
                                    Input = input("do you want to attack it? y/n: ")

                                    if Input.lower() == "y":
                                       enemyHealth = random.randrange(1, 15)
                                       totalDurabilityLose = int()
                                       totalHealthLose = int()
                                       while True:
                                          if health >= 1:
                                             print('-')
                                             print('You hit the small goblem!')
                                             durabilityLose = random.randrange(1, 3) #1-2
                                             if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                enemyHealth -= wood_attack
                                                wood_durability -= durabilityLose
                                             elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                enemyHealth -= stone_attack
                                                stone_durability -= durabilityLose
                                             elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                enemyHealth -= iron_attack
                                                iron_durability -= durabilityLose
                                             totalDurabilityLose += durabilityLose
                                          
                                             if enemyHealth <= 0:
                                                print('==========================')
                                                print('And easly punched the goblem in the face and cut him open.')
                                                print('===+BATTLE RESOULTS+===')
                                                print('You lost',totalDurabilityLose,'durability')
                                                print('and',totalHealthLose,'health.')
                                                if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                   print('Current durability on',ACTIVE_WEPOND.activeWepond,':',wood_durability,'')
                                                elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                   print('Current durability on',ACTIVE_WEPOND.activeWepond,':',stone_durability,'')
                                                elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                   print('Current durability on',ACTIVE_WEPOND.activeWepond,':',iron_durability,'')
                                                print('Current health:',health)
                                                gold += 5
                                                level += 1
                                                
                                                with open("userLog","a") as f:
                                                   now = date.today()
                                                   date_now = now.strftime("%#d\%#m\%y")
                                                   now1 = datetime.now()
                                                   time_now = now1.strftime("%H:%M")
                                                   
                                                   f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                   f.write(str("======Small goblem======" + "\n"))
                                                   f.write(str("User defeated small goblem " + "\n"))
                                                   f.write(str("Gold + 5\n"))
                                                   f.write(str("Level + 1\n"))
                                                   f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                   f.write(str("Gold = " + str(gold) + "\n"))
                                                   f.write(str("Level = " + str(level) + "\n"))
                                                   f.write(str("Health = " + str(health) + "\n"))
                                                   f.write(str("\n"))
                                                   f.write(str("\n"))
                                                   f.close()
                                                
                                                previous = int(1)
                                                save = True
                                                break

                                             elif enemyHealth >=1:
                                                print('-')
                                                print('The enemy swung at you!')
                                                damage = random.randrange(1, 3)#1-2
                                                health -= damage
                                                totalHealthLose += damage
                                                continue
                                          else:
                                             with open("userLog","a") as f:
                                                now = date.today()
                                                date_now = now.strftime("%#d\%#m\%y")
                                                now1 = datetime.now()
                                                time_now = now1.strftime("%H:%M")
                                                
                                                f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                f.write(str("======Small goblem======" + "\n"))
                                                f.write(str("User was defeated by small goblem " + "\n"))
                                                f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                f.write(str("Health = " + str(health) + "\n"))
                                                f.write(str("\n"))
                                                f.write(str("\n"))
                                                f.close()
                                             break
                                                
                                    elif Input.lower() == "n":
                                       print('')
                                       print('You ran away from the small goblem, and got home in one piece.')
                                       print('')
                                       previous = int(1)
                                       event = int()
                                    elif Input.lower() == "q":
                                       break

#SMALL GOBLEM^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#MEDIUM GOBLEM=========================================================================================================================================================

                                while event == int(2):
                                 if previous == int(2):
                                    event = int()
                                 else:
                                    print('---------------------------------------------------------------------')
                                    print('======Medium goblem======')
                                    print('You stumbled apon a medium goblem')
                                    print('Do you wish to attack it? y/n')
                                    print('Defeat reward: +10 Gold.')
                                    Input = input(': ')

                                    if Input.lower() == "y":
                                       enemyHealth = random.randrange(15, 30)
                                       totalDurabilityLose = int()
                                       totalHealthLose = int()
                                       while True:
                                          if health >= 1:
                                             print('-')
                                             print('You hit the medium goblem!')
                                             durabilityLose = random.randrange(1, 3)
                                             if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                enemyHealth -= wood_attack
                                                wood_durability -= durabilityLose
                                             elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                enemyHealth -= stone_attack
                                                stone_durability -= durabilityLose
                                             elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                enemyHealth -= iron_attack
                                                iron_durability -= durabilityLose
                                             totalDurabilityLose += durabilityLose
                                          
                                             if enemyHealth <= 0:
                                                print('==========================')
                                                print('''And then finally tore the medium goblems head off
and did a victory dance!''')
                                                print('===+BATTLE RESOULTS+===')
                                                print('You lost',totalDurabilityLose,'durability')
                                                print('and',totalHealthLose,'health.')
                                                if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                   print('Current durability on',ACTIVE_WEPOND.activeWepond,':',wood_durability,'')
                                                elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                   print('Current durability on',ACTIVE_WEPOND.activeWepond,':',stone_durability,'')
                                                elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                   print('Current durability on',ACTIVE_WEPOND.activeWepond,':',iron_durability,'')
                                                print('Current health:',health)
                                                gold += 10
                                                level += 1
                                                
                                                with open("userLog","a") as f:
                                                   now = date.today()
                                                   date_now = now.strftime("%#d\%#m\%y")
                                                   now1 = datetime.now()
                                                   time_now = now1.strftime("%H:%M")
                                                   
                                                   f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                   f.write(str("======Medium goblem======" + "\n"))
                                                   f.write(str("User defeated medium goblem " + "\n"))
                                                   f.write(str("Gold + 10\n"))
                                                   f.write(str("Level + 1\n"))
                                                   f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                   f.write(str("Gold = " + str(gold) + "\n"))
                                                   f.write(str("Level = " + str(level) + "\n"))
                                                   f.write(str("Health = " + str(health) + "\n"))
                                                   f.write(str("\n"))
                                                   f.write(str("\n"))
                                                   f.close()
                                                
                                                previous = int(2)
                                                save = True
                                                break

                                             elif enemyHealth >=1:
                                                print('-')
                                                print('The enemy swung at you!')
                                                damage = random.randrange(1, 5)
                                                health -= damage
                                                totalHealthLose += damage
                                                continue
                                          else:
                                             with open("userLog","a") as f:
                                                now = date.today()
                                                date_now = now.strftime("%#d\%#m\%y")
                                                now1 = datetime.now()
                                                time_now = now1.strftime("%H:%M")
                                                
                                                f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                f.write(str("======Medium goblem======" + "\n"))
                                                f.write(str("User was defeated by medium goblem " + "\n"))
                                                f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                f.write(str("Health = " + str(health) + "\n"))
                                                f.write(str("\n"))
                                                f.write(str("\n"))
                                                f.close()
                                             break
                                                
                                    elif Input.lower() == "n":
                                       print('')
                                       print('You ran away from the medium goblem, and got home in one piece.')
                                       print('')
                                       previous = int(2)
                                       event = int()
                                    elif Input.lower() == "q":
                                       break
                                    
#MEDIUM GOBLEM^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#HUGE GOBLEM===========================================================================================================================================================

#HUGE GOBLEM^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#DEAMON================================================================================================================================================================

                                while event == int(3):
                                   if previous == int(3):
                                      event = int()
                                   else:
                                       print('---------------------------------------------------------------------')
                                       print('======Deamon======')
                                       print('You found yourself staring into the eye\'s\nof a deamon!')
                                       print('Do you wish to attack it? y/n')
                                       print('Defeat reward: +20 Gold.')
                                       print('Chance of one health potion!')
                                       Input = input(': ')

                                       if Input.lower() == "y":
                                          enemyHealth = random.randrange(30, 45)
                                          totalDurabilityLose = int()
                                          totalHealthLose = int()
                                          while True:
                                             if health >= 1:
                                                print('-')
                                                print('You hit the deamon!')
                                                durabilityLose = random.randrange(1, 3)
                                                if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                   enemyHealth -= wood_attack
                                                   wood_durability -= durabilityLose
                                                elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                   enemyHealth -= stone_attack
                                                   stone_durability -= durabilityLose
                                                elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                   enemyHealth -= iron_attack
                                                   iron_durability -= durabilityLose
                                                totalDurabilityLose += durabilityLose
                                             
                                                if enemyHealth <= 0:
                                                   give_health = random.randrange(1, 101)#1-100
                                                   print('==========================')
                                                   print('And managed to stabe the deamon in the heart!')
                                                   print('===+BATTLE RESOULTS+===')
                                                   if give_health >= 90:
                                                      print('You found a health potion on the deamon!')
                                                      healthPotion += 1
                                                   print('You lost',totalDurabilityLose,'durability')
                                                   print('and',totalHealthLose,'health.')
                                                   if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                      print('Current durability on',ACTIVE_WEPOND.activeWepond,':',wood_durability,'')
                                                   elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                      print('Current durability on',ACTIVE_WEPOND.activeWepond,':',stone_durability,'')
                                                   elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                      print('Current durability on',ACTIVE_WEPOND.activeWepond,':',iron_durability,'')
                                                   print('Current health:',health)
                                                   gold += 20
                                                   level += 2
                                                   
                                                   with open("userLog","a") as f:
                                                      now = date.today()
                                                      date_now = now.strftime("%#d\%#m\%y")
                                                      now1 = datetime.now()
                                                      time_now = now1.strftime("%H:%M")
                                                      
                                                      f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                      f.write(str("======Deamon======" + "\n"))
                                                      f.write(str("User defeated deamon " + "\n"))
                                                      f.write(str("Gold + 20\n"))
                                                      f.write(str("Level + 2\n"))
                                                      f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                      f.write(str("Gold = " + str(gold) + "\n"))
                                                      f.write(str("Level = " + str(level) + "\n"))
                                                      f.write(str("Health = " + str(health) + "\n"))
                                                      f.write(str("\n"))
                                                      f.write(str("\n"))
                                                      f.close()
                                                   
                                                   previous = int(3)
                                                   save = True
                                                   break

                                                elif enemyHealth >=1:
                                                   print('-')
                                                   print('The enemy swung at you!')
                                                   damage = random.randrange(1, 5)
                                                   health -= damage
                                                   totalHealthLose += damage
                                                   continue
                                             else:
                                                with open("userLog","a") as f:
                                                   now = date.today()
                                                   date_now = now.strftime("%#d\%#m\%y")
                                                   now1 = datetime.now()
                                                   time_now = now1.strftime("%H:%M")
                                                   
                                                   f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                   f.write(str("======Deamon======" + "\n"))
                                                   f.write(str("User was defeated by deamon " + "\n"))
                                                   f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                   f.write(str("Health = " + str(health) + "\n"))
                                                   f.write(str("\n"))
                                                   f.write(str("\n"))
                                                   f.close()
                                                break
                                                   
                                       elif Input.lower() == "n":
                                          print('')
                                          print('You ran away from the deamon, and got home in one piece.')
                                          print('')
                                          previous = int(3)
                                          event = int()
                                       elif Input.lower() == "q":
                                          break
                                       


#DEAMON^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#CHANGE WEPOND=========================================================================================================================================================
                                          
                       elif Input == "2":
                           while True:
                             print('Choose a wepon to use!')
                             print('1--> Wooden sword.')
                             print('2--> Stone sword.')
                             print('3--> Iron sword.')
                             print('4--> wooden Crossbow.')
                             print('q--> Exit')
                             Input = input(': ')

                             if Input == "1":
                                if wood_owned == True:
                                   
                                   path = os.getcwd() + r'\saves'
                                   
                                   wepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                   f = open(wepond, "w")
                                   f.write("activeWepond = 'WOODEN_SWORD'\n")
                                   f.close()
                                   print('---------------------')
                                   print('Equiped wooden sword.')
                                   print('---------------------')
                                   save = True
                                   continue
                                 
                                elif wood_owned == False:
                                   print('----------------------------')
                                   print('You dont own a wooden sword.')
                                   print('----------------------------')
                                   continue

                             elif Input == "2":
                                if stone_owned == True:
                                   
                                   path = os.getcwd() + r'\saves'
                                   
                                   wepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                   f = open(wepond, "w")
                                   f.write("activeWepond = 'STONE_SWORD'\n")
                                   f.close()
                                   print('--------------------')
                                   print('Equiped stone sword.')
                                   print('--------------------')
                                   save = True
                                   continue
                                else:
                                   print('---------------------------')
                                   print('You dont own a stone sword.')
                                   print('---------------------------')
                                   continue

                             elif Input == "3":
                                if iron_owned == True:
                                   
                                   path = os.getcwd() + r'\saves'
                                   
                                   wepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                   f = open(wepond, "w")
                                   f.write("activeWepond = 'IRON_SWORD'\n")
                                   f.close()
                                   print('-------------------')
                                   print('Equiped iron sword.')
                                   print('-------------------')
                                   save = True
                                   continue

                                else:
                                   print('--------------------------')
                                   print('You dont own a iron sword.')
                                   print('--------------------------')
                                   continue

                                   
                                 
                             elif Input == "q":
                                break


                       elif Input == "q": #quit to menu.
                              break
                        
                 except Exception as Error:
                    Error = (Error,'play, choose wepond')
                    ErrorInfo = Error
                    save = True
                    print('===============')
                    print('AN ERROR ACURED')
                    print('===============')
#SHOP-----------------------------------------------------------------------------------------------------------------------------------------------------------------#

              if Input == "2":
                 try:
                    while True:
                      item = str('')
                      amount = int(0)
                      price = int(0)
                      
                      items1 = ['1 health potion','2 food','3 wooden sword','4 stone sword','5 iron sword','6 wood','7 stone','8 iron']
                      items2 = ['1 health potion','2 food','3 wooden sword','4 stone sword','5 iron sword','6 wood','7 stone','8 iron']
                      items3 = ['1 health potion','2 food','3 wooden sword','4 stone sword','5 iron sword','6 wood','7 stone','8 iron']
                      items4 = ['1 health potion','2 food','3 wooden sword','4 stone sword','5 iron sword','6 wood','7 stone','8 iron']

                      items1 = (random.choice(items1))
                      items2 = (random.choice(items2))
                      items3 = (random.choice(items3))
                      items4 = (random.choice(items4))
                      
                      if items1 == items2: #items3 items4:# == items3 and items4:                             #if item is the same in item2 then try again.
                         continue
                      elif items3 == items4:
                         continue
                      elif items1 == items3:
                         continue
                      elif items2 == items4:
                         continue
                      elif items1 == items4:
                         continue
                      elif items2 == items3:
                         continue
                      
                      else:                                                                                         #if items was different from items2
                          print('---------------------------------------------------------------------')
                          print('======SHOP======')
                          print('Gold',gold)
                          print('This is what i have to offer.')
                          print('q to exit.')
                          print(items1,'-',items2)                                                                  #prints the selected items
                          print(items3,'-',items4)                                                                  #prints the selected items2
                          Input = input('Press a number to buy: ')                                                  #gives user choice of what they want

#health potion code, price of one health potion 20$====================================================================================================================

                          if Input == "1":                                                                          #if user enters 1...
                              if items1 == "1 health potion" or items2 == "1 health potion" or items3 == "1 health potion" or items4 == "1 health potion":#if it is one of the items listed...
                                 while True:
                                  item = str('health potion\s')                                                     #set item to health potion...
                                  try:
                                     print('How many',item,'do you want?')                                          #asks how many of the item you want...
                                     amount = int(input(': '))                                                      #amount is what ever the user enters...
                                  except ValueError:
                                     print('---------------------------------------------------------------------')
                                     print('Please dont use letters.')
                                     print('---------------------------------------------------------------------')
                                     continue
                                  price = 20 * amount                                                               #price = 20 x the amount of items you want...
                                  print('would you like to purchas',item,' x',amount,' for',price,'gold? y/n')      #confirms purchas of item, amount, price...
                                  Input = input(': ')                                                               #gets yes or no answer for purchase...

                                  if Input.lower() == "y" or Input.lower() == "yes":                                #if user enters y, yes...
                                      
                                      if gold < price:                                                              #check if user dose not have enough gold...
                                          print('---------------------------------------------------------------------')
                                          print('Sorry you dont have enough gold for',amount, item,'.')             #if user dose not have enough gold tell them...
                                          break                                                                     #then continue back to start...
                                      
                                      elif gold >= price:                                                           #else if user has enough gold...
                                          print('---------------------------------------------------------------------')
                                          print('Your purchas was successful!')                                     #tell them it was successfully bought...
                                          healthPotion += amount                                                    #give user the amount purchased of item...
                                          gold -= price                                                             #take price away from gold...
                                          with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("Health potion + " + str(amount) + "\n"))
                                             f.write(str("Health potion = " + str(healthPotion) + "\n"))
                                             f.write(str("Gold - " + str(price) + "\n"))
                                             f.write(str("Gold = " + str(gold) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                             save = True
                                          print('Anything else?')                                                   #prints anything else...
                                          break                                                                     #continues to start...
                                      
                                  elif Input.lower() == "n" or Input.lower() == "no":                               #else if user enters n, no...
                                      print('Anything else?')                                                       #print anything else...
                                      break                                                                         #continues to start...

                              else:                                                                                 #else if item isnt listed...
                                  continue                                                                          #send user back to start.
                              

#Food code, price of one health potion 10$=============================================================================================================================

                          if Input == "2":                                                                          #if user enters 1...
                              if items1 == "2 food" or items2 == "2 food" or items3 == "2 food" or items4 == "2 food":                                           #if it is one of the items listed...
                                 while True:
                                  item = str('Food')                                                                #set item to health potion...
                                  try:
                                     print('How many',item,'do you want?')                                          #asks how many of the item you want...
                                     amount = int(input(': '))                                                      #amount is what ever the user enters...
                                  except ValueError:
                                     print('---------------------------------------------------------------------')
                                     print('Please dont use letters.')
                                     print('---------------------------------------------------------------------')
                                     continue
                                  price = 10 * amount                                                               #price = 20 x the amount of items you want...
                                  print('would you like to purchas',item,' x',amount,' for',price,'gold? y/n')      #confirms purchas of item, amount, price...
                                  Input = input(': ')                                                               #gets yes or no answer for purchase...

                                  if Input.lower() == "y" or Input.lower() == "yes":                                #if user enters y, yes...
                                      
                                      if gold < price:                                                              #check if user dose not have enough gold...
                                          print('Sorry you dont have enough gold for',amount, item,'.')             #if user dose not have enough gold tell them...
                                          break                                                                     #then continue back to start...
                                      
                                      elif gold >= price:
                                          print('---------------------------------------------------------------------')#else if user has enough gold...
                                          print('Your purchas was successful!')                                     #tell them it was successfully bought...
                                          food += amount                                                            #give user the amount purchased of item...
                                          gold -= price                                                             #take price away from gold...
                                          with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("Food + " + str(amount) + "\n"))
                                             f.write(str("Food = " + str(food) + "\n"))
                                             f.write(str("Gold - " + str(price) + "\n"))
                                             f.write(str("Gold = " + str(gold) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                             save = True
                                          print('Anything else?')                                                   #prints anything else...
                                          break                                                                     #continues to start...
                                      
                                  elif Input.lower() == "n" or Input.lower() == "no":                               #else if user enters n, no...
                                      print('Anything else?')                                                       #print anything else...
                                      break                                                                         #continues to start...

                              else:                                                                                 #else if item isnt listed...
                                  continue                                                                          #send user back to start.

#Wooden sword code, price of 1 wooden sword 50$------------------------------------------------------------------------------------------------------------------------

                          if Input == "3":                                                                          #if user enters 1...
                              if items1 == "3 wooden sword" or items2 == "3 wooden sword" or items3 == "3 wooden sword" or items4 == "3 wooden sword":
                                 item = str('Wooden sword')
                                 if wood_owned == False:
                                    while True:
                                     print('Would you like to buy',item,' for 10 gold? y/n')
                                     Input = input(': ')

                                     if Input.lower() == "y":
                                        if gold >= 50:
                                           wood_owned = True
                                           print('Successfully purchased',item,'!')
                                           break
                                          
                                        elif gold < 50:
                                           print('Sorry you dont have enough gold for',item,'.')
                                           save = True
                                           break
                                     elif Input.lower() == "n":
                                        break
                                 else:
                                    print('---------------------------------')
                                    print('You already own',item,'.')
                                    continue

                          elif Input == "q" or Input == "quit":
                             break

#Stone sword code, price of 1 stone sword 100$-------------------------------------------------------------------------------------------------------------------------

                          if Input == "4":                                                                          #if user enters 1...
                              if items1 == "4 stone sword" or items2 == "4 stone sword" or items3 == "4 stone sword" or items4 == "4 stone sword":
                                 item = str('Stone sword')
                                 if stone_owned == False:
                                    while True:
                                     print('Would you like to buy',item,' for 100 gold? y/n')
                                     Input = input(': ')

                                     if Input.lower() == "y":
                                        if gold >= 100:
                                           stone_owned = True
                                           print('Successfully purchased',item,'!')
                                           save = True
                                           break
                                          
                                        elif gold < 100:
                                           print('Sorry you dont have enough gold for',item,'.')
                                           break
                                     elif Input.lower() == "n":
                                        break
                                 else:
                                    print('---------------------------------')
                                    print('You already own',item,'.')
                                    continue

                          elif Input == "q" or Input == "quit":
                             break
                           
#Iron sword code, price of 1 iron sword 200$-------------------------------------------------------------------------------------------------------------------------


                          if Input == "5":                                                                          #if user enters 1...
                              if items1 == "5 iron sword" or items2 == "5 iron sword" or items3 == "5 iron sword" or items4 == "5 iron sword":
                                 item = str('Iron sword')
                                 if iron_owned == False:
                                    while True:
                                     print('Would you like to buy',item,' for 200 gold? y/n')
                                     Input = input(': ')

                                     if Input.lower() == "y":
                                        if gold >= 200:
                                           iron_owned = True
                                           print('Successfully purchased',item,'!')
                                           save = True
                                           break
                                          
                                        elif gold < 200:
                                           print('Sorry you dont have enough gold for',item,'.')
                                           break
                                     elif Input.lower() == "n":
                                        break

                                 else:
                                    print('---------------------------------')
                                    print('You already own',item,'.')
                                    continue

                          elif Input == "q" or Input == "quit":
                             break

#wood code, price of 1 wood 25$-------------------------------------------------------------------------------------------------------------------------


                          if Input == "6":#if user enters 1...
                             if items1 == "6 wood" or items2 == "6 wood" or items3 == "6 wood" or items4 == "6 wood":
                                 item = str('wood')
                                 while True:
                                    print('How much',item,'would you like to purchase?')
                                    amount = int(input(': '))

                                    price = amount * 25

                                    print('Would you like to purchase',amount,item,'for',price,'$ ?')
                                    Input = input(': ')

                                    if Input.lower() == "y":
                                       
                                        if gold >= price:
                                           wood += amount
                                           print('Successfully purchased',item,'!')
                                           save = True
                                           break
                                          
                                        elif gold < price:
                                           print('Sorry you dont have enough gold for',item,'.')
                                           break
                                    elif Input.lower() == "n":
                                        break

#stone code, price of 1 stone 65$-------------------------------------------------------------------------------------------------------------------------

                          if Input == "7":#if user enters 1...
                             if items1 == "7 stone" or items2 == "7 stone" or items3 == "7 stone" or items4 == "7 stone":
                                 item = str('stone')
                                 while True:
                                    print('How much',item,'would you like to purchase?')
                                    amount = int(input(': '))

                                    price = amount * 65

                                    print('Would you like to purchase',amount,item,'for',price,'$ ?')
                                    Input = input(': ')

                                    if Input.lower() == "y":
                                       
                                        if gold >= price:
                                           stone += amount
                                           print('Successfully purchased',item,'!')
                                           save = True
                                           break
                                          
                                        elif gold < price:
                                           print('Sorry you dont have enough gold for',item,'.')
                                           break
                                    elif Input.lower() == "n":
                                        break

#iron code, price of 1 stone 100$-------------------------------------------------------------------------------------------------------------------------

                          if Input == "8":#if user enters 1...
                             if items1 == "8 iron" or items2 == "8 iron" or items3 == "8 iron" or items4 == "8 iron":
                                 item = str('iron')
                                 while True:
                                    print('How much',item,'would you like to purchase?')
                                    amount = int(input(': '))

                                    price = amount * 100

                                    print('Would you like to purchase',amount,item,'for',price,'$ ?')
                                    Input = input(': ')

                                    if Input.lower() == "y":
                                       
                                        if gold >= price:
                                           iron += amount
                                           print('Successfully purchased',item,'!')
                                           save = True
                                           break
                                          
                                        elif gold < price:
                                           print('Sorry you dont have enough gold for',item,'.')
                                           break
                                    elif Input.lower() == "n":
                                        break
                                       

                          elif Input == "q" or Input == "quit": #hole game quit do not touch!!!
                             break



                           

                 except Exception as Error:
                    Error = (Error,'shop')
                    ErrorInfo = Error
                    save = True
                    print('===============')
                    print('AN ERROR ACURED')
                    print('===============')          
                           
#VIEW PROFILE---------------------------------------------------------------------------------------------------------------------------------------------------------#

              elif Input == "3": #View profile.
                  print('---------------------------------------------------------------------')
                  try:
                     print('======' + (name) +'\'s profile======') 
                     print('Level:',(level))
                     print('Health:',(health))
                     print('Gold:',(gold))
                     print('Active wepond:',ACTIVE_WEPOND.activeWepond)
                     if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                           print('Attack:',wood_attack)
                           print('Durability:',wood_durability)
                     elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                        print('Attack:',stone_attack)
                        print('Durability:',stone_durability)
                     elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                        print('Attack:',iron_attack)
                        print('Attack:',iron_durability)
                     else:
                        print('You dont have an equiped wepond.')
                        
                     #print('Attack:',(attack))
                     print('')
                     print('======' + (name) +'\'s inventory======')
                     print('Health potion: ',healthPotion)
                     print('Food: ',food)
                     print('Wood: ',wood)
                     print('Stone: ',stone)
                     print('Iron: ',iron)
                     print('Wooden sword owned: ',wood_owned)
                     print('Stone sword owned: ',stone_owned)
                     print('Iron sword owned: ',iron_owned)
                     
                  except Exception as Error:
                     Error = (Error,'view profile')
                     ErrorInfo = Error
                     save = True
                     print('===============')
                     print('AN ERROR ACURED')
                     print('===============')
                  
                  print('\npress ENTER to continue.')
                  Input = input('')
                  pass

#SAVE PROGRESS--------------------------------------------------------------------------------------------------------------------------------------------------------#

              elif Input == "4": #Save progress.
                 print('---------------------------------------------------------------------')

                 try:
                    path = os.getcwd() + r'\saves'

                    print('Saving new data...')
                    today = date.today()
                    today1 = today.strftime("%#d/%#m/%Y")

                    savetime = os.path.join(path, 'timesave.py')
                    f = open(savetime,"w")
                    f.write("today = " + str(today1) + "\n")
                    f.write("yesterday = " + str(yesterday) + "\n")
                    f.close()

                    savesave = os.path.join(path, 'save.py')
                    f = open(savesave, "w")
                    f.write("name = '" + str(name) + "' \n")
                    f.write("level = " + str(level) + "\n")
                    f.write("health = " + str(health) + "\n")
                    f.write("gold = " + str(gold) + "\n")
                    f.write("healthPotion = " + str(healthPotion) + "\n")
                    f.write("food = " + str(food) + "\n")
                    f.write("wood = " + str(wood) + "\n")
                    f.write("stone = " + str(stone) + "\n")
                    f.write("iron = " + str(iron) + "\n")
                    f.close()

                    path2 = os.getcwd() + r'\saves\WEPONDS'
            
                    savewoodsword = os.path.join(path2, 'WOODEN_SWORD.py')
                    f = open(savewoodsword, "w")
                    f.write("wood_owned = " + str(wood_owned) + "\n")
                    f.write("wood_durability = " + str(wood_durability) + "\n")
                    f.write("wood_attack = " + str(wood_attack) + "\n")
                    f.close()

                    savestonesword = os.path.join(path2, 'STONE_SWORD.py')
                    f = open(savestonesword, "w")
                    f.write("stone_owned = " + str(stone_owned) + "\n")
                    f.write("stone_durability = " + str(stone_durability) + "\n")
                    f.write("stone_attack = " + str(stone_attack) + "\n")
                    f.close()

                    saveironsword = os.path.join(path2, 'STONE_SWORD.py')
                    f = open(saveironsword, "w")
                    f.write("iron_owned = " + str(iron_owned) + "\n")
                    f.write("iron_durability = " + str(iron_durability) + "\n")
                    f.write("iron_attack = " + str(iron_attack) + "\n")
                    f.close()
                    
                    print('Save successful!')
                    save = False
                 except Exception as Error:
                    Error = (Error,'SAVE PROGRESS')
                    print('==================================================')
                    print('CRITICAL PROCESS ERROR:\nPLEASE CONTACT ejmultigames@gmail.com for support!\nError:',Error,'')
                    print('==================================================')
                    save = False
            
#END------------------------------------------------------------------------------------------------------------------------------------------------------------------#
