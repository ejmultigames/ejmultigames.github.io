def log_error():
    print('''Sorry, their seams to be an error!
please allow me to collect some information.
then please send a file called Error log to
ejmultigames@gmail.com thank you!''')
    except Exception as ErrorInfo:
        print(ErrorInfo)
