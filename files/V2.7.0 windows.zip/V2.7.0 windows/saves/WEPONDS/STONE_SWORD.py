stone_owned = False
stone_durability = 100
stone_attack = 50
