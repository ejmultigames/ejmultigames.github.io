wood_owned = True
wood_durability = 100
wood_attack = 10
