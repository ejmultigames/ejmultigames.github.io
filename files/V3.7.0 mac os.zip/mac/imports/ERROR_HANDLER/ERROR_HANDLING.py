error_attempts = 1

def error_detect():
    if error_attempts >= 1:
        print('===================================================')
        print('THIS IS AN AUTOMATED ERROR HANDLER')
        print('Is the error...')
        print('Red--> 1')
        print('Blue-- > 2')
        Input = input(': ')

        if Input.lower() == "red" or Input == "1":
            print('Read the error message completely and asnwer the following...')
            print('Is the message a...')
            print('ModuleNotFoundError--> 1')
            print('AttributeError--> 2')
            print('NameError--> 3')
            print('IndentationError--> 4')
            print('Other--> 5')
            Input = input(': ')

            if Input.lower() == "modulenotfounderror" or Input == "1":
                print('''This means you found something new! congrates?

Course: This error is coursed when their is either
an incorrect module or something was deleted.
                         
Solution: Please take a screen shot of the error
or copy and past it into a txt file and email
it to (ejmultigames@gmail.com)
________________________________________
Sorry for the error.
''')
                print('press enter when you are ready to quit.')
                Input = input('')
                quit()

            elif Input.lower() == "attributeerror" or Input == "2":
                print('''This means you found something new! congrates?

Course: This error is coursed when something was
requested but not existant.

Solution: Please take a screen shot of the error
or copy and past it into a txt file and email
it to (ejmultigames@gmail.com)
________________________________________
Sorry for the error.
''')
                print('press enter when you are ready to quit.')
                Input = input('')
                quit()
                

            elif Input.lower() == "nameerror" or Input == "3":
                print('''This means you found something new! congrates?

Course: This error is coursed when a name is
called but does not exist.

solution: You can try restarting your game.
or you can email (ejmultigames) with a
screen shot or txt file with the error in
it.
________________________________________
Sorry for the error.
''')
                print('press enter when you are ready to quit.')
                Input = input('')
                quit()

            elif Input.lower() == "IndentationError" or Input == "4":
                print('''This means you found something new! congrates?

Course: This error is coursed when their
is an incorrect gap in a command (text).

solution: Please take a screen shot of the error
or copy and past it into a txt file and email
it to (ejmultigames@gmail.com)
________________________________________
Sorry for the error.
''')
                print('press enter when you are ready to quit.')
                Input = input('')
                quit()

            elif Input.lower() == "other" or Input == "5":
                print('Please before you close the program')
                print('1.) Take a screen shot or copy and past the error into a file.')
                print('2.) Send an email with the screen shot or file attached too (ejmultigames@gmail.com)')
                print('____________________________________________________________________________________')
                print('I am terably sorry for the error, thank you for reporting this as soon as i get it i will look strait into it!')
                print('press enter when you are ready to quit.')
                Input = input('')
                quit()
                
        elif Input.lower() == "blue" or Input == "2":          
            print('Please tell me the error thats coming up')
            TXT = input(': ')

            quit()








            
