

#NOTICE!!! THE ONLY THINGS THAT CAN BE AUTOMATED ARE THE THINGS THAT DONT CHANGE!
import os
import sys
sys.path.append('../')
import saves
from saves.WEPONDS import FIST_PUNCH, IRON_SWORD, STONE_SWORD, WOODEN_SWORD

#FIST PUNCH INFO:================================================
FIST_PUNCH_INFO_COST = str('free')#WORKING
FIST_PUNCH_INFO_ATTACK = str(FIST_PUNCH.punch_attack)#WORKING
FIST_PUNCH_INFO_DURABILITY = str(FIST_PUNCH.punch_durability)#WORKING

#WOODEN SWORD INFO:==============================================
WOODEN_SWORD_INFO_COST = str('50 gold')#WORKING
WOODEN_SWORD_INFO_ATTACK = str(WOODEN_SWORD.wood_attack)#WORKING
WOODEN_SWORD_INFO_DURABILITY = str('100%')#WORKING

#STONE SWORD INFO:===============================================
STONE_SWORD_INFO_COST = str('500 gold')#WORKING
STONE_SWORD_INFO_ATTACK = str(STONE_SWORD.stone_attack)#WORKING
STONE_SWORD_INFO_DURABILITY = str('100%')#WORKING

#IRON SWORD INFO:================================================
IRON_SWORD_INFO_COST = str('1200 gold')#WORKING
IRON_SWORD_INFO_ATTACK = str(IRON_SWORD.iron_attack)#WORKING
IRON_SWORD_INFO_DURABILITY = str('100%')#WORKING

#WOOD INFO:======================================================
WOOD_INFO_COST = str('25 gold')
WOOD_INFO_REPAIR = str('5%')

#STONE INFO:=====================================================
STONE_INFO_COST = str('65 gold')
STONE_INFO_REPAIR = str('5%')

#IRON INFO:======================================================
IRON_INFO_COST = str('100 gold')
IRON_INFO_REPAIR = str('5%')

