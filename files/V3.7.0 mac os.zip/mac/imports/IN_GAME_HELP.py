#Command for use:
#IN_GAME_HELP.Game_Help()

#Current errors:
#0

#Status:
#Working...

try:
    from imports import GAME_INFORMATION_INFO #had to import from imports because
except Exception as Error:                    #the current directory was from the game.
    print(''''Sorry, an error has accured. Please copy the following info and
send it to ejmultigames@gmail.com.''')
    print(Error)
    pass

def Game_Help():
    while True:
        print('---------------------------------------------------------------------')
        print('''Welcome to the help menu.
For some help with what to search type info or type help to see the help menu.
To return to menu type quit.''')
        try:
            txt = input(': ')

            if 'info' in txt.lower():
               print('')
               print('''======Info======
try searching...

==Technical help==
Purchases
Support
Help

==Ingame resources==
Gold
Health
Attack
Food
Wood
Stone
Iron

==Ingame enemys==
Small goblem
Medium goblem
Huge goblem
Deamon

==Ingame weponds==
Fists
Wooden sword
Stone sword
Iron sword
''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass
#TECHNICAL-----------------------------------------------------------------------
            elif 'purchases' in txt.lower():
               print('')
               print('''======Purchases======
-If you are having trouble buying in game content please
check that you do have enough gold to do so.

-After purchasing something from the shop it goes to your
inventory, please check for it their.

-If you do have enough gold and you cant find the item in
your inventory please check that their is'nt a limit by
heading to your inventory and look at the info
of the item you are trying to purchase, if their is'nt a time
limite you may be facing a bug, please report this to
ejmultigames@gmail.com''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'support' in txt.lower():
               print('')
               print('''======support======
For support, for anything with this game you may contact
ejmultigames@gmail.com

In order to sort out the emails effectivly please lable
your email with the problem and the game it was in.
E.G. subject: Bug Medieval events.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'help' in txt.lower():
               print('')
               print('''======Help======
Help V1.1.0.

-To start using this help menu, you can search info to see
a list of available options.

-To begin searching, just type one of the options given!

-If you need extra help with anything please contact support.
ejmultigames@gmail.com

-If theirs something we didn't mention dont hesitate to look
at the support page by searching [support] here.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass
#TECHNICAL^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#WEPONDS-------------------------------------------------------------------------
            elif 'fists' in txt.lower():
               print('')
               print('======Fists======')
               print('-Your fists are your first line of defence, but be careful... their weak!')
               print('')
               print('-Shop cost:',GAME_INFORMATION_INFO.FIST_PUNCH_INFO_COST)
               print('')
               print('-Attack:',GAME_INFORMATION_INFO.FIST_PUNCH_INFO_ATTACK)
               print('')
               print('-Durability:',GAME_INFORMATION_INFO.FIST_PUNCH_INFO_DURABILITY)
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'wooden sword' in txt.lower():
               print('')
               print('======Wooden sword======')
               print('-The wooden sword is one of the first swords you will use.')
               print('')
               print('-Shop cost:',GAME_INFORMATION_INFO.WOODEN_SWORD_INFO_COST)
               print('')
               print('-Attack:',GAME_INFORMATION_INFO.WOODEN_SWORD_INFO_ATTACK)
               print('')
               print('-Durability:',GAME_INFORMATION_INFO.WOODEN_SWORD_INFO_DURABILITY)
               print('\npress ENTER to continue.')
               Input = input('')
               pass
            
            elif 'stone sword' in txt.lower():
               print('')
               print('======Stone sword======')
               print('-The stone sword is more then likely the second sword you')
               print('will use.')
               print('')
               print('-Shop cost:',GAME_INFORMATION_INFO.STONE_SWORD_INFO_COST)
               print('')
               print('-Attack:',GAME_INFORMATION_INFO.STONE_SWORD_INFO_ATTACK)
               print('')
               print('-Durability:',GAME_INFORMATION_INFO.STONE_SWORD_INFO_DURABILITY)
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'iron sword' in txt.lower():
               print('')
               print('======Iron sword======')
               print('-The iron sword is the most powerfullest sword you can')
               print('get on the market right now.')
               print('')
               print('-Shop cost:',GAME_INFORMATION_INFO.IRON_SWORD_INFO_COST)
               print('')
               print('-Attack:',GAME_INFORMATION_INFO.IRON_SWORD_INFO_ATTACK)
               print('')
               print('-Durability:',GAME_INFORMATION_INFO.IRON_SWORD_INFO_DURABILITY)
               print('\npress ENTER to continue.')
               Input = input('')
               pass
#WEPONDS^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#RESOURCES-----------------------------------------------------------------------
            elif 'gold' in txt.lower():
               print('')
               print('''======Gold======
-This may be the most important thing you will need
in this game!

-Gold allowes you to purchase tons of goods including
health potion and swords''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'health' in txt.lower():
               print('')
               print('''======Health======
-Health is your players health, run out of this and you die.

-In order to get health you need to buy health potions, to buy
health potions you need gold.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'attack' in txt.lower():
               print('')
               print('''======Attack======
-When you are first given a profile you recieve a wooden sword,''')
               print('keep in mind this sword only has',GAME_INFORMATION_INFO.WOODEN_SWORD_INFO_ATTACK,'attack points.')
               print('')
               print('''-If you want more attack points you will have to upgread your
sword.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'food' in txt.lower():
               print('')
               print('''======Food======
-Food is used to heal yourself by 10.
it costs a small bit of gold.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'wood' in txt.lower():
               print('')
               print('''======Wood======
-Wood is used to repair wooden swords.''')
               print('')
               print('-1 wood costs',GAME_INFORMATION_INFO.WOOD_INFO_COST)
               print('')
               print('-1 wood repairs',GAME_INFORMATION_INFO.WOOD_INFO_REPAIR,'damage')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'stone' in txt.lower():
               print('')
               print('''======Stone======
-Stone is used to repair stone swords.''')
               print('')
               print('-1 stone costs',GAME_INFORMATION_INFO.STONE_INFO_COST)
               print('')
               print('-1 stone repairs',GAME_INFORMATION_INFO.STONE_INFO_REPAIR,'damage.')
               print('\npress ENTER to continue.')
               Input = input('')
               pass

            elif 'iron' in txt.lower():
               print('')
               print('''======Iron======
-Iron is used to repair iron swords.''')
               print('')
               print('-1 iron costs',GAME_INFORMATION_INFO.IRON_INFO_COST)
               print('')
               print('-1 iron repairs',GAME_INFORMATION_INFO.IRON_INFO_REPAIR,'damage.')
               print('\npress ENTER to continue.')
               Input = input('')
               pass
#RESOURCES^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#ENEMYS--------------------------------------------------------------------------
            elif 'small goblem' in txt.lower():
                print('')
                print('''======Small goblem======
-The small goblem is one of the lowest enemys in the game, it is
 an instant kill enemy or you can run away if you wish...

-The small goblem has a health of 1-15 so be careful.
 
-You will be rewarded 5 gold and 20 exp by defeating it.

-You will lose 1-2 durability on your sword and 1-2 health
 per hit.''')
                print('\npress ENTER to continue.')
                Input = input('')
                pass

            elif 'medium goblem' in txt.lower():
                print('')
                print('''======medium goblem======
-The medium goblem is the first hardest enemys in the game.

-The medium goblem has a health of 15-30 so be careful.
 
-You will be rewarded 10 gold and 20 exp by defeating it.

-You will lose 1-2 durability on your sword and 1-2 health
 per hit.''')
                print('\npress ENTER to continue.')
                Input = input('')
                pass

            elif 'huge goblem' in txt.lower():
                print('')
                print('''======huge goblem======
-The huge goblem is the thired hardest enemys in the game.

-The huge goblem has a health of 30 - 45 so be carful.
 
-You will be rewarded 15 gold and 20 exp by defeating it.

-You will lose 1-2 durability on your sword and 1-2 health
 per hit.''')
                print('\npress ENTER to continue.')
                Input = input('')
                pass

            elif 'deamon' in txt.lower():
               print('')
               print('''======Deamon======
-The deamon is the forth hardest enemy in the game.

-The deamon has a health of 45 - 60 so be carful.

-You will be rewarded 20 gold and 40 exp by defeating it.

-You will lose 1-5 durability on your sword and 1-5 health
 per hit.''')
               print('\npress ENTER to continue.')
               Input = input('')
               pass
#ENEMYS^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#SEARCH RESULT CODE--------------------------------------------------------------
            elif 'quit' in txt.lower():
                break
                

            else:
               options = ['info','support','purchases','gold','health','attack','food','wood','stone','iron','deamon','small goblem','medium goblem','fists','wooden sword','stone sword','iron sword']
               check = txt[:3]
               res = [idx for idx in options if idx[:3].lower() == check.lower()]
               if res == []:
                  check = txt[:2]
                  res = [idx for idx in options if idx[:2].lower() == check.lower()]
                  if res == []:
                     check = txt[0]
                     res = [idx for idx in options if idx[0].lower() == check.lower()]
                     if res == []:
                        res = "[No Resolts Found]"

            
               print('')
               print('======UNKNOWN ERROR======')
               #print('Sorry their was no resaults for \'',txt,'\'...')
               if res == "[No Resolts Found]":
                   print(str(res) + ' for',txt,'')
                   print('')
                   print('Try searching info!')
                   print('If you belive theirs a problem, please contact support.')
                   print('\npress ENTER to continue.')
                   Input = input('')
                   pass
               else:
                   print('Did you mean: ' + str(res))
                   print('')
                   print('''If not try searching info!
If you belive theirs a problem, please contact support.''')
                   print('\npress ENTER to continue.')
                   Input = input('')
                   pass

        except IndexError:
            pass
