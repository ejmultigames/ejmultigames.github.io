#Command for use: UPDATE_CHECK.Check_Connection()|

#Current errors: 0|

#3.7.0 standerds|updated_successfully|tested_and_aproved|

import time
import webbrowser
import socket
import urllib.request, urllib.error

def Check_Connection(): #working
    try:
        socket.create_connection(("www.google.com", 80)) #checks to see if it can connect to a website. if it can we have internet!
        print('=====================================================================')
        print('internet connected! checking for update please wait')
        print('This may take several seconds...')
        print('=====================================================================')
        Update_Check()
        
    except Exception:
        print('=====================================================================')
        print('ERROR: No internet, Check for update unsuccessful.')
        print('       ->Please make sure you are connected, and try again.')
        print('=====================================================================')
        pass



def Update_Check():
    url = 'http://ejmultigames.github.io/downloads/Download380.html'
    try:
        conn = urllib.request.urlopen(url)#try open page
        
    except urllib.error.HTTPError as e:#404 505 error
        print('Their are no updates!')
        print('=====================================================================')
        pass
    except urllib.error.URLError as e:#connection refused
        print('Sorry, an error has occured while checking for updates...')
        print('If this keeps on happening please contact support.')
        print('(ejmultigames@gmail.com)')
        pass
    else:
        print('Success! Their is a new better update out! download it now!')
        time.sleep(1)
        webbrowser.open('http://ejmultigames.github.io/downloads/Download380.html', new=0, autoraise=True)
        pass















