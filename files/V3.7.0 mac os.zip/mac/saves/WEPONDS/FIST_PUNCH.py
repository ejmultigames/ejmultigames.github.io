punch_owned = True
punch_durability = str('infinit')
punch_attack = 1
