wood_owned = False
wood_durability = 100
wood_attack = 5
