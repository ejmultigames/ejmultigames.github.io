#patch update v3.7.0.
#tested: working.

#game information.
fist_cost = str('free')
fist_attack = int('1')
fist_durability = str('infinit')

wooden_sword_cost = int('50')
wooden_sword_attack = int('5')
wooden_durability = int('100')

stone_sword_cost = int('500')
stone_sword_attack = int('20')
stone_sword_durabiliity = int('100')

iron_sword_cost = int('1200')
iron_sword_attack = int('50')
iron_sword_durability = int('100')

#game update stats.
















