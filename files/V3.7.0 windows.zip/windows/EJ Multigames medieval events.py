#PRESS F5 TO START.

#EJ Multigames: V3.7.0.0
#Medieval events: BETA V2.3.0.0



#You are permited to change game code. though
#revers engenering passwords and other game data
#will be taken as an offence. Unless you are
#willing to share ideas and improvments for it.
#Thank you, EJ. H

#More information in read me...





















































#Know your versions!

#v1.2.3.4
# ^ ^ ^ ^
# ^ ^ ^ 4.Patchess, very small fix's.
# ^ ^ 3.Very small updates, bug fixes etc...
# ^ 2.Medium updates, bug fixes small add ons etc...
# 1.A big update, interface changes, new games etc...





#changing any code can damage the games. do not save any changes that you might of accidently made. If you have
#any ideas, Or improvments to the code you can contact me Ethan @ [ ejmultigames@gmail.com ] or for updates please contact me.

#you are free to change code and or add content but recognition would be greatly apricited. and some sort of contact of the change
#would be even more apriciated.




#=====================================================================================
#scroll up now if you dont want to accidently make a mistake! or continue if deliberit.
#=====================================================================================
























#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#______________________________
#IMPROVEMENTS : FIXES : CHANGES|________________________________________________

#Add a self repair module, check's error list, if theirs an error with a module
#repair that module!

#make users be able to view the improvment log in game = uncomplete

#even out the economy = uncomplete

#fix the "100 $" visule effect = uncomplete

#get rid of all spelling mistakes. ALL! = uncomplete

#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#___________________________
#COMPLETE : FIXES : CHANGES|____________________________________________________

#Add new enemy, heavy goblem = complete

#fix save issue = complete

#fix in game help only getting first word issue = complete

#Add new level system = complete

#Clear unnecassary data and saves = complete

#add fist's so if player breaks every wepond they can still earn gold. = complete




print('Loading imports!..')
print('0-7')
print('Main system imports...')
import random
import time
import os
print('1-7')

print('Multitasking imports...')
from threading import Thread
from importlib import reload
print('2-7')

print('Date & Time handling imports...')
from datetime import date
from datetime import datetime
print('3-7')

print('Custom module handling imports...')
import imports
#from imports import GAME_INFORMATION_INFO
from imports import UPDATE_CHECK, IN_GAME_HELP, GAME_INFORMATION_INFO
from imports.user_save_handling import USER_RESTART, NEW_USER_START, USER_DIE_RESTART
print('4-7')

print('Weapond data imports...')
import saves
from saves.WEPONDS import WOODEN_SWORD
from saves.WEPONDS import STONE_SWORD
from saves.WEPONDS import IRON_SWORD
from saves.WEPONDS import FIST_PUNCH
from saves import ACTIVE_WEPOND
print('5-7')

print('Player save imports...')
from saves import player_save
print('6-7')

print('Error handling imports...')
from imports.ERROR_HANDLER import ERROR_HANDLING
print('7-7')
print('Loading...')

def auto_reload():#reloads everytime the user presses enter.
   while True:
      reload(ACTIVE_WEPOND)
      reload(player_save)
      reload(FIST_PUNCH)
      reload(WOODEN_SWORD)
      reload(STONE_SWORD)
      reload(IRON_SWORD)
      reload(UPDATE_CHECK)
      reload(IN_GAME_HELP)
      reload(USER_RESTART)
      reload(NEW_USER_START)
      reload(USER_DIE_RESTART)
      reload(ERROR_HANDLING)
      time.sleep(1)


def main_game():
 try:
    global name
    name = player_save.name
    
    global exp
    exp = player_save.exp
    
    global next_level_up
    next_level_up = player_save.next_level_up
    
    global level
    level = player_save.level
    
    global health
    health = player_save.health
    
    global gold
    gold = player_save.gold
    
    global healthPotion
    healthPotion = player_save.healthPotion
    
    global food
    food = player_save.food
    
    global wood
    wood = player_save.wood
    
    global stone
    stone = player_save.stone
    
    global iron
    iron = player_save.iron

    global punch_owned
    punch_owned = FIST_PUNCH.punch_owned

    global punch_durability
    punch_durability = FIST_PUNCH.punch_durability

    global punch_attack
    punch_attack = FIST_PUNCH.punch_attack

    global wood_owned
    wood_owned = WOODEN_SWORD.wood_owned

    global wood_durability
    wood_durability = WOODEN_SWORD.wood_durability

    global wood_attack
    wood_attack = WOODEN_SWORD.wood_attack

    global stone_owned
    stone_owned = STONE_SWORD.stone_owned

    global stone_durability
    stone_durability = STONE_SWORD.stone_durability

    global stone_attack
    stone_attack = STONE_SWORD.stone_attack

    global iron_owned
    iron_owned = IRON_SWORD.iron_owned

    global iron_durability
    iron_durability = IRON_SWORD.iron_durability

    global iron_attack
    iron_attack = IRON_SWORD.iron_attack

 except Exception as Error:
    Error = (Error,'MAIN GAME SAVE')
    print('==================================================')
    print('CRITICAL PROCESS ERROR:\nPLEASE CONTACT ejmultigames@gmail.com for support!\nError:',Error,'\nInclude this message in the email!!!')
    print('==================================================')
 
 global save
 save = False
 global ErrorInfo
 ErrorInfo = ''
 print('')
 try:
    if name == " " or name == "  " or name == "":
       print('Welcome to EJ Multigames!')
    else:
       print('welcome to EJ Multigames',name + '!')
 except NameError:
    NEW_USER_START.Configure_User()
 while True:
   print('')
   print('---------------------------------------------------------------------')
   print('''<<START MENU>>
1--> Start!
2--> Check for update/ Requires internet.
3--> Help.
4--> restart progress.
q--> Quit game.''')
   Input = input(': ')

   if Input.lower() == "q":
      exit()
      

   elif Input == "4":
      try:
         USER_RESTART.Restart_Account() #delets and restarts user account
         print('______________________________________________________')
         print('Please open the game again for changes to take effect.')
         time.sleep(3)
         exit()
         
      except Exception as Error:
         Error = (Error,'MAIN GAME SAVE')
         print('==================================================')
         print('CRITICAL PROCESS ERROR:\nPLEASE CONTACT ejmultigames@gmail.com for support!\nError:',Error,'\nInclude this message in the email!!!')
         print('==================================================')
         save = False

   elif Input == "3":
      try:
         IN_GAME_HELP.Game_Help()

      except Exception as Error:
         Error = (Error,'In game help')
         ErrorInfo = Error
         save = True
         print('===============')
         print('AN ERROR ACURED')
         print('===============')

#CHECK FOR SOFTWEAR UPDATE---------------------------------------------------------------------------------------------------------------------------------------------

   elif Input == "2":
      try:
         UPDATE_CHECK.Check_Connection()
      except Exception as Error:
         Error = (Error,'Update checker')
         ErrorInfo = Error
         save = True
         print('===============')
         print('AN ERROR ACURED')
         print('===============')

#CHECK FOR SOFTWEAR UPDATE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#MAIN MENU-------------------------------------------------------------------------------------------------------------------------------------------------------------

   elif Input == "1":
#MAIN GAME SAVE--------------------------------------------------------------------

    while True:
       print('---------------------------------------------------------------------')
       if save == True:
          try:
             print('======================') 
             print('Saving your game!')
             print('======================')

             if ErrorInfo == '':                                              #if ErrorInfo is an empty string.
                pass                                                          #pass it.
             else:                                                            #else if ErrorInfo is not empty.
                with open("Error Log.txt","a") as f:                          #opens (Error Log) as a apend file and...
                   now = date.today()                                         #gets todays date.
                   date_now = now.strftime("%#d\%#m\%y")                      #makes todays date show as 28/1/20 instead of 28/01/2020, which can couse errors.
                   now1 = datetime.now()                                      #gets the time.
                   time_now = now1.strftime("%H:%M")                          #makes the time show only hours and minutes.
                   f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n")) #saves the date and time.
                   f.write(str("======ERROR======" + "\n"))                   #saves a string.
                   f.write(str(ErrorInfo))                                    #saves the contents of ErrorInfo.
                   f.write('\n\n')                                            #saves two spaces.
             f.close()                                                        #close the file to prevent unexpected errors.
             ErrorInfo = ''                                                   #sets ErrorInfo back to defult.

             path = os.getcwd() + r'\saves'                                   #The current working filepath plus saves add on, where saves should go.
            
             savesave = os.path.join(path, 'player_save.py')                      #finds a file (save.py) and...
             f = open(savesave, "w")                                       #opens the save.py file as a write file.
             f.write("name = '" + str(name) + "' \n")                      #player name save.
             f.write("exp = " + str(exp) + "\n")                           #exp save.
             f.write("next_level_up = " + str(next_level_up) + "\n")       #next level up save.
             f.write("level = " + str(level) + "\n")                       #player level save.
             f.write("health = " + str(health) + "\n")                     #player health save.
             f.write("gold = " + str(gold) + "\n")                         #player gold save.
             f.write("healthPotion = " + str(healthPotion) + "\n")         #item, healthpotion save.
             f.write("food = " + str(food) + "\n")                         #item, food save.
             f.write("wood = " + str(wood) + "\n")                         #item, wood save.
             f.write("stone = " + str(stone) + "\n")                       #item, stone save.
             f.write("iron = " + str(iron) + "\n")                         #item, iron save.
             f.close()                                                     #close the save file to prevent unexpected errors.

             path2 = os.getcwd() + r'\saves\WEPONDS'                       #The current working filepath plus saves\WEPONDS add on, where all wepond data should be stored.
            
             savewoodsword = os.path.join(path2, 'WOODEN_SWORD.py')        #In the given path finds (WOODEN_SWORD.py) and...
             f = open(savewoodsword, "w")                                  #opend it as a write file.
             f.write("wood_owned = " + str(wood_owned) + "\n")             #wooden sword owned save.
             f.write("wood_durability = " + str(wood_durability) + "\n")   #wooden sword durability save.
             f.write("wood_attack = " + str(wood_attack) + "\n")           #wooden sword attack save.
             f.close()                                                     #close the file to prevent unexpected errors.

             savestonesword = os.path.join(path2, 'STONE_SWORD.py')        #In the given path finds (STONE_SWORD.py) and...
             f = open(savestonesword, "w")                                 #opend it as a write file.
             f.write("stone_owned = " + str(stone_owned) + "\n")           #stone sword owned save.
             f.write("stone_durability = " + str(stone_durability) + "\n") #stone sword durability save.
             f.write("stone_attack = " + str(stone_attack) + "\n")         #stone sword attack save.
             f.close()                                                     #close the file to prevent unexpected errors.

             saveironsword = os.path.join(path2, 'IRON_SWORD.py')          #In the given path finds (IRON_SWORD.py) and...
             f = open(saveironsword, "w")                                  #opend it as a write file.
             f.write("iron_owned = " + str(iron_owned) + "\n")             #iron sword owned save.
             f.write("iron_durability = " + str(iron_durability) + "\n")   #iron sword durability save.
             f.write("iron_attack = " + str(iron_attack) + "\n")           #iron sword attack save.
             f.close()                                                     #close the file to prevent unexpected errors.
            
             save = False
             continue

          except Exception as Error:
            Error = (Error,'MAIN GAME SAVE')
            print('==================================================')
            print('CRITICAL PROCESS ERROR:\nPLEASE CONTACT ejmultigames@gmail.com for support!\nError:',Error,'\nInclude this message in the email!!!')
            print('==================================================')
            save = False

#MAIN GAME SAVE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

       elif save == False:
              print('''======MENU======
What do you wish to do?
0--> inventory.
1--> play.
2--> shop.
3--> view profile.
4--> save progress.
q--> To start menu''')

              Input = input(': ')

              if Input.lower() == "q": #quits to start menu
                 break

#MAIN MENU^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
              
#INVENTORY MENU------------------------------------------------------------------------------------------------------------------------------------------------------------#
#3.7.0 STANDERDS|NO_UPDATE_NEEDED|
              if Input == "0": #Health potion code: Done \ sword sharpen code: Done \ spear code: Done \ food code: uncoplete \
                 try:
                    while True:
                       print('---------------------------------------------------------------------')
                       print('======INVENTORY======')
                       print('1--> Health potions:',healthPotion)
                       print('2--> Food:',food)
                       print('3--> Wood:',wood)
                       print('4--> Stone:',stone)
                       print('5--> Iron:',iron)
                       print('q--> To exit.')
                       Input = input('Press a number to use an item: ')

#INVENTORY= HEALTH POTION----------------------------------------------------------------------------------------------------------------------------------------------
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                       if Input == "1":
                          print('---------------------------------------------------------------------')
                          print('''Name: Health potion.
Gives: full health.
''')
                          if health >= 100:
                             print('---------------------------------------------------------------------')
                             print('Your health is already at',health,'and cant be healed further!')
                             print('\npress ENTER to continue.')
                             Input = input('')
                             continue
                           
                          elif health <= 99:
                             if healthPotion < 0:
                                print('---------------------------------------------------------------------')
                                print('You dont have any health potions.')
                                print('\npress ENTER to continue.')
                                Input = input('')
                                continue
                              
                             elif healthPotion >= 1:
                                print('---------------------------------------------------------------------')
                                print('Do you want to use health potion? y/n')
                                Input = input(': ')

                                if Input.lower() == "n" or Input.lower() == "no":
                                   continue

                                elif Input.lower() == "y" or Input.lower() == "yes":
                                   healthPotion -= 1
                                   health = 100                         #sets health back too 100
                                   with open("userLog.txt","a") as f:
                                      now = date.today()
                                      date_now = now.strftime("%#d\%#m\%y")
                                      now1 = datetime.now()
                                      time_now = now1.strftime("%H:%M")
                                      f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                      f.write(str("======User used health potion======") + "\n")
                                      f.write(str("Health potion - 1" + "\n"))
                                      f.write(str("Health potion = " + str(healthPotion) + "\n"))
                                      f.write(str("Health = " + str(health) + "\n"))
                                      f.write(str("\n"))
                                      f.write(str("\n"))
                                      f.close()
                                   print('---------------------------------------------------------------------')
                                   print('You used Health potion successfuly.')
                                   save = True                          #makes the game save when back in home menu.
                                   continue

#INVENTORY= HEALTH POTION^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#INVENTORY= FOOD-------------------------------------------------------------------------------------------------------------------------------------------------------
#3.7.0|STANDERDS|UPDATED_SUCCESSFULLY|
                       if Input == "2":
                          print('---------------------------------------------------------------------')
                          print('''Name: Food.
Gives: 10 health.
Costs: 10 gold.''')
                          if health >= 91:
                             print('---------------------------------------------------------------------')
                             print('Your health is already at',health,'and cant be healed further!')
                             print('\npress ENTER to continue.')
                             Input = input('')
                             continue
                           
                          elif health <= 99:
                             if food <= 0:
                                print('---------------------------------------------------------------------')
                                print('You dont have any food.')
                                print('\npress ENTER to continue.')
                                Input = input('')
                                continue
                              
                             elif food >= 1:
                                print('---------------------------------------------------------------------')
                                print('Do you want to use Food? y/n')
                                Input = input(': ')

                                if Input.lower() == "n" or Input == "no":
                                   continue

                                elif Input.lower() == "y" or Input == "yes":
                                   print('---------------------------------------------------------------------')
                                   print('How much food do you wish to use?')
                                   amount = int(input(': '))
                                
                                   if amount > food:
                                      print('---------------------------------------------------------------------')
                                      print('Sorry you dont have that much food.')
                                      continue
                                    
                                   elif amount <= food:
                                      healed = 10 * amount
                                      print('---------------------------------------------------------------------')
                                      print('Do you want to use',amount,'food to heal',healed,'damage? y/n')
                                      Input = input(': ')

                                      if Input.lower() == "n" or Input.lower() == "no":
                                         continue

                                      elif Input.lower() == "y" or Input.lower() == "yes":
                                         if health + healed >= 101:
                                            print('---------------------------------------------------------------------')
                                            print('Sorry, you cant have more health then 100...')
                                            
                                         elif health + healed <= 100:
                                            food -= amount
                                            health += healed
                                            with open("userLog","a") as f:
                                               now = date.today()
                                               date_now = now.strftime("%#d\%#m\%y")
                                               now1 = datetime.now()
                                               time_now = now1.strftime("%H:%M")
                                               f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                               f.write(str("======User used food======") + "\n")
                                               f.write(str("Food - " + str(amount) + "\n"))
                                               f.write(str("Health + " + str(healed) + "\n"))
                                               f.write(str("Food = " + str(food) + "\n"))
                                               f.write(str("Health = " + str(health) + "\n"))
                                               f.write(str("\n"))
                                               f.write(str("\n"))
                                               f.close()
                                            print('---------------------------------------------------------------------')
                                            print('Successfuly used',amount,'food to heal',healed,'damage!')
                                            save = True
                                            continue

#INVENTORY= FOOD^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#INVENTORY= WOOD-------------------------------------------------------------------------------------------------------------------------------------------------------
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                       if Input == "3":
                          print('---------------------------------------------------------------------')
                          print('''Name: Wood.
Info: Repairs 5% of damage done to a wooden sword.
Gives: 5% Repair.
Shop cost: 25 gold.''')
                          if wood_owned == False:
                             print('---------------------------------------------------------------------')
                             print('You cant use this item until you buy a wooden sword.')
                             print('\npress ENTER to continue.')
                             Input = input('')
                             continue
                           
                          elif wood_owned == True:
                             print('---------------------------------------------------------------------')
                             print('Do you want to use wood to repair wooden sword? y/n')
                             Input = input(': ')

                             if Input.lower() == "y" or Input.lower() == "yes":
                                print('---------------------------------------------------------------------')
                                print('How much wood do you wish to use?')
                                amount = int(input(': '))

                                if amount > wood:
                                   print('---------------------------------------------------------------------')
                                   print('Sorry you dont have that much wood.')
                                   continue
                                 
                                elif amount <= wood:
                                   fixed = 5 * amount
                                   print('---------------------------------------------------------------------')
                                   print('Do you want to use',amount,'wood to repair',str(fixed) + '% damage? y/n')
                                   Input = input(': ')

                                   if Input.lower() == "y":
                                      if wood_durability >= 96:
                                         print('---------------------------------------------------------------------')
                                         print('Wooden sword must have 95% damage to repair.')
                                         continue
                                       
                                      elif wood_durability <= 95:
                                         print('---------------------------------------------------------------------')
                                         print('Used',amount,'wood to fix',str(fixed) + '% damage')
                                         wood_durability += fixed
                                         wood -= amount
                                         with open("userLog","a") as f:
                                            now = date.today()
                                            date_now = now.strftime("%#d\%#m\%y")
                                            now1 = datetime.now()
                                            time_now = now1.strftime("%H:%M")
                                            f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                            f.write(str("======User used wood======") + "\n")
                                            f.write(str("Wood - " + str(amount) + "\n"))
                                            f.write(str("Wood durability + " + str(fixed) + "\n"))
                                            f.write(str("Wood = " + str(wood) + "\n"))
                                            f.write(str("Wood durability = " + str(wood_durability) + "\n"))
                                            f.write(str("\n"))
                                            f.write(str("\n"))
                                            f.close()
                                         save = True
                                         continue
                                       
                                   elif Input.lower() == "n":
                                      continue

#INVENTORY= WOOD^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#INVENTORY= STONE-------------------------------------------------------------------------------------------------------------------------------------------------------
#3.7.0|UPDATED_SUCCESSFULLY|
                       if Input == "4":
                          print('---------------------------------------------------------------------')
                          print('''Name: Stone.
Info: Repairs 5% of damage done to a Stone sword.
Gives: 5% Repair.
Shop cost: 65 gold.''')
                          if stone_owned == False:
                             print('---------------------------------------------------------------------')
                             print('You cant use this item until you buy a stone sword.')
                             print('\npress ENTER to continue.')
                             Input = input('')
                             continue
                           
                          elif stone_owned == True:
                             print('---------------------------------------------------------------------')
                             print('Do you want to use stone to repair stone sword? y/n')
                             Input = input(': ')

                             if Input.lower() == "y" or Input.lower() == "yes":
                                print('---------------------------------------------------------------------')
                                print('How much stone do you wish to use?')
                                amount = int(input(': '))

                                if amount > stone:
                                   print('---------------------------------------------------------------------')
                                   print('Sorry you dont have that much stone.')
                                   continue
                                 
                                elif amount <= stone:
                                   fixed = 5 * amount
                                   print('---------------------------------------------------------------------')
                                   print('Do you want to use',amount,'stone to repair',str(fixed) + '% damage? y/n')
                                   Input = input(': ')

                                   if Input.lower() == "y":
                                      if stone_durability >= 96:
                                         print('---------------------------------------------------------------------')
                                         print('Stone sword must have 95% damage to repair.')
                                         continue
                                       
                                      elif stone_durability <= 95:
                                         print('---------------------------------------------------------------------')
                                         print('Used',amount,'stone to fix',str(fixed) + '% damage')
                                         stone_durability += fixed
                                         stone -= amount
                                         with open("userLog","a") as f:
                                            now = date.today()
                                            date_now = now.strftime("%#d\%#m\%y")
                                            now1 = datetime.now()
                                            time_now = now1.strftime("%H:%M")
                                            f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                            f.write(str("======User used stone======") + "\n")
                                            f.write(str("Stone - " + str(amount) + "\n"))
                                            f.write(str("Stone durability + " + str(fixed) + "\n"))
                                            f.write(str("Stone = " + str(stone) + "\n"))
                                            f.write(str("Stone durability = " + str(stone_durability) + "\n"))
                                            f.write(str("\n"))
                                            f.write(str("\n"))
                                            f.close()
                                         save = True
                                         continue
                                       
                                   elif Input.lower() == "n":
                                      continue

#INVENTORY= STONE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                
#INVENTORY= IRON-------------------------------------------------------------------------------------------------------------------------------------------------------
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                       if Input == "5":
                          print('---------------------------------------------------------------------')
                          print('''Name: Iron.
Info: Repairs 5% of damage done to a iron sword.
Gives: 5% Repair.
Shop cost: 100 gold.''')
                          if iron_owned == False:
                             print('---------------------------------------------------------------------')
                             print('You cant use this item until you buy a iron sword.')
                             print('\npress ENTER to continue.')
                             Input = input('')
                             continue
                           
                          elif iron_owned == True:
                             print('---------------------------------------------------------------------')
                             print('Do you want to use iron to repair iron sword? y/n')
                             Input = input(': ')

                             if Input.lower() == "y" or Input.lower() == "yes":
                                print('---------------------------------------------------------------------')
                                print('How much iron do you wish to use?')
                                amount = int(input(': '))

                                if amount > iron:
                                   print('---------------------------------------------------------------------')
                                   print('Sorry you dont have that much iron.')
                                   continue
                                 
                                elif amount <= iron:
                                   fixed = 5 * amount
                                   print('---------------------------------------------------------------------')
                                   print('Do you want to use',amount,'iron to repair',str(fixed) + '% damage? y/n')
                                   Input = input(': ')

                                   if Input.lower() == "y":
                                      if iron_durability >= 96:
                                         print('---------------------------------------------------------------------')
                                         print('iron sword must have 95% damage to repair.')
                                         continue
                                       
                                      elif iron_durability <= 95:
                                         print('---------------------------------------------------------------------')
                                         print('Used',amount,'iron to fix',str(fixed) + '% damage')
                                         iron_durability += fixed
                                         iron -= amount
                                         with open("userLog","a") as f:
                                            now = date.today()
                                            date_now = now.strftime("%#d\%#m\%y")
                                            now1 = datetime.now()
                                            time_now = now1.strftime("%H:%M")
                                            f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                            f.write(str("======User used iron======") + "\n")
                                            f.write(str("Iron - " + str(amount) + "\n"))
                                            f.write(str("Iron durability + " + str(fixed) + "\n"))
                                            f.write(str("Iron = " + str(iron) + "\n"))
                                            f.write(str("Iron durability = " + str(iron_durability) + "\n"))
                                            f.write(str("\n"))
                                            f.write(str("\n"))
                                            f.close()
                                         save = True
                                         continue
                                       
                                   elif Input.lower() == "n":
                                      continue



                       if Input.lower() == "q":#inventory quit, dont touch.
                         break

                 except Exception as Error:
                    Error = (Error,'Inventory')
                    ErrorInfo = Error
                    save = True
                    print('===============')
                    print('AN ERROR ACURED')
                    print('===============')

#INVENTORY - IRON^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#PLAY-----------------------------------------------------------------------------------------------------------------------------------------------------------------#
#PRE-BATTLE CODE=====================================================================
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
              if Input == "1":
                 try:
                    while True:
                       if (exp) >= (next_level_up):
                          level += 1
                          exp -= next_level_up
                          next_level_up += next_level_up
                          continue
                       elif (exp) != (next_level_up):
                          previous = int(0)
                          print('---------------------------------------------------------------------')
                          print('''
1--> Battle!
2--> Change wepond.
q--> Return menu.
''')
                          Input = input(': ')

                          if Input == "1":
                             event = int()
                             while event == int():
                                if health <= 0:
                                   print('---------------------------------------------------------------------')
                                   print('You where knocked out in battle...')
                                   USER_DIE_RESTART.Die_Restart()
                                   print('________________________')
                                   print('Please restart your game.')
                                   time.sleep()
                                   quit()

                                elif health >= 1:#---------------------------------below code deals with durability of weponds.
                                   reload(ACTIVE_WEPOND)
                                   if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                      if wood_durability <= 0:
                                         print('Your wooden sword has broken!')
                                         print('|SWITCHED TO FISTS|')
                                         wood_owned = False #set these 2 variables back to default.
                                         wood_durability = 100
                                         path = os.getcwd() + r'\saves'

                                         saveactivewepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                         f = open(saveactivewepond, "w")
                                         f.write("activeWepond = 'FIST_PUNCH' ")
                                         f.close()
                                         save = True
                                         continue
                                      

                                   elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                      if stone_durability <= 0:
                                         print('Your stone sword has broken!')
                                         print('|SWITCHED TO FISTS|')
                                         stone_owned = False
                                         stone_durability = 100
                                         path = os.getcwd() + r'\saves'

                                         saveactivewepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                         f = open(saveactivewepond, "w")
                                         f.write("activeWepond = 'FIST_PUNCH' ")
                                         f.close()
                                         save = True
                                         continue


                                   elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                      if iron_durability <= 0:
                                         print('Your iron sword has broken!')
                                         print('|SWITCHED TO FISTS|')
                                         iron_owned = False
                                         iron_durability = 100
                                         path = os.getcwd() + r'\saves'

                                         saveactivewepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                         f = open(saveactivewepond, "w")
                                         f.write("activeWepond = 'FIST_PUNCH' ")
                                         f.close()
                                         save = True
                                         continue

                                   elif ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                                      pass
     

                                   else:
                                      print('Please equip a wepond and return.')
                                      break
                                    
                                   event = random.randrange(1, 5) #1 == 4
                                
#PRE-BATTLE CODE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#SMALL GOBLEM==========================================================================================================================================================
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                                while event == int(1):
                                   if previous == int(1):
                                      event = int()
                                   else:
                                      if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                         if wood_durability <= 20:
                                            print('Your durability is running low on wooden sword!')
                                          
                                      elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                         if stone_durability <= 20:
                                            print('Your durability is running low on stone sword!')
                                          
                                      elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                         if iron_durability <= 20:
                                            print('Your durability is running low on iron sword!')
                                            
                                      print('---------------------------------------------------------------------')
                                      print('======Small goblem======')
                                      print('you have been brought into a fight against a small goblem')
                                      print('Defeat reward: +20 exp +5 Gold.')
                                      Input = input("do you want to attack it? y/n: ")

                                      if Input.lower() == "y":
                                         enemyHealth = random.randrange(1, 16)
                                         totalDurabilityLose = int()
                                         totalHealthLose = int()
                                         while True:
                                            if health >= 1:
                                               print('-')
                                               print('You hit the small goblem!')
                                               durabilityLose = random.randrange(1, 3)
                                               if ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                                                  enemyHealth -= punch_attack
                                               elif ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                  enemyHealth -= wood_attack
                                                  wood_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                               elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                  enemyHealth -= stone_attack
                                                  stone_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                               elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                  enemyHealth -= iron_attack
                                                  iron_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                          
                                               if enemyHealth <= 0:
                                                  print('==========================')
                                                  print('And easly punched the goblem in the face and cut him open.')
                                                  print('===+BATTLE RESOULTS+===')
                                                  if ACTIVE_WEPOND.activeWepond != 'FIST_PUNCH':#if its not a sword it does not need to lose durabilty.
                                                     print('You lost',totalDurabilityLose,'durability')
                                                     print('and',totalHealthLose,'health.')
                                                     if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',wood_durability,'')
                                                        if wood_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                     elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',stone_durability,'')
                                                        if stone_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                     elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',iron_durability,'')
                                                        if iron_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                      
                                                  elif ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                                                     print('You lost',totalHealthLose,'health.')
                                                  print('Current health:',health)
                                                  gold += 5
                                                  exp += 20
                                                
                                                  with open("userLog","a") as f:
                                                     now = date.today()
                                                     date_now = now.strftime("%#d\%#m\%y")
                                                     now1 = datetime.now()
                                                     time_now = now1.strftime("%H:%M")
                                                
                                                     f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                     f.write(str("======Small goblem======" + "\n"))
                                                     f.write(str("User defeated small goblem " + "\n"))
                                                     f.write(str("Gold + 5\n"))
                                                     f.write(str("exp + 20\n"))
                                                     f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                     f.write(str("Gold = " + str(gold) + "\n"))
                                                     f.write(str("Health = " + str(health) + "\n"))
                                                     f.write(str("Level = " + str(level) + "\n"))
                                                     f.write(str("\n"))
                                                     f.write(str("\n"))
                                                     f.close()
                                          
                                                  previous = int(1)
                                                  save = True
                                                  break

                                               elif enemyHealth >=1:
                                                  print('-')
                                                  print('The enemy swung at you!')
                                                  damage = random.randrange(1, 3)#1-2
                                                  health -= damage
                                                  totalHealthLose += damage
                                                  if health <= 0:
                                                     event = int()
                                                  else:
                                                     continue
                                            else:
                                               with open("userLog","a") as f:
                                                  now = date.today()
                                                  date_now = now.strftime("%#d\%#m\%y")
                                                  now1 = datetime.now()
                                                  time_now = now1.strftime("%H:%M")
                                                
                                                  f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                  f.write(str("======Small goblem======" + "\n"))
                                                  f.write(str("User was defeated by small goblem " + "\n"))
                                                  f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                  f.write(str("Health = " + str(health) + "\n"))
                                                  f.write(str("\n"))
                                                  f.write(str("\n"))
                                                  f.close()
                                               break
                                                
                                      elif Input.lower() == "n":
                                         print('')
                                         print('You ran away from the small goblem, and got home in one piece.')
                                         print('')
                                         previous = int(1)
                                         event = int()
                                      elif Input.lower() == "q":
                                         break

#SMALL GOBLEM^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#MEDIUM GOBLEM=========================================================================================================================================================
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                                while event == int(2):
                                   if previous == int(2):
                                      event = int()
                                   else:
                                      if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                         if wood_durability <= 20:
                                            print('Your durability is running low on wooden sword!')
                                      elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                         if stone_durability <= 20:
                                            print('Your durability is running low on stone sword!')
                                      elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                         if iron_durability <= 20:
                                            print('Your durability is running low on iron sword!')
                                            
                                      print('---------------------------------------------------------------------')
                                      print('======Medium goblem======')
                                      print('You stumbled apon a medium goblem')
                                      print('Do you wish to attack it? y/n')
                                      print('Defeat reward: +20 exp +10 Gold.')
                                      Input = input(': ')

                                      if Input.lower() == "y":
                                         enemyHealth = random.randrange(15, 31)
                                         totalDurabilityLose = int()
                                         totalHealthLose = int()
                                         while True:
                                            if health >= 1:
                                               print('-')
                                               print('You hit the medium goblem!')
                                               durabilityLose = random.randrange(1, 3)
                                               if ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                                                  enemyHealth -= punch_attack
                                               elif ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                  enemyHealth -= wood_attack
                                                  wood_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                               elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                  enemyHealth -= stone_attack
                                                  stone_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                               elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                  enemyHealth -= iron_attack
                                                  iron_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                          
                                               if enemyHealth <= 0:
                                                  print('==========================')
                                                  print('''And then finally tore the medium goblems head off
and did a victory dance!''')
                                                  print('===+BATTLE RESOULTS+===')
                                                  if ACTIVE_WEPOND.activeWepond != 'FIST_PUNCH':
                                                     print('You lost',totalDurabilityLose,'durability')
                                                     print('and',totalHealthLose,'health.')
                                                     if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',wood_durability,'')
                                                        if wood_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                     elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',stone_durability,'')
                                                        if stone_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                     elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',iron_durability,'')
                                                        if iron_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                  elif ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                                                     print('You lost',totalHealthLose,'health.')
                                                  print('Current health:',health)
                                                  gold += 10
                                                  exp += 20
                                                
                                                  with open("userLog","a") as f:
                                                     now = date.today()
                                                     date_now = now.strftime("%#d\%#m\%y")
                                                     now1 = datetime.now()
                                                     time_now = now1.strftime("%H:%M")
                                                   
                                                     f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                     f.write(str("======Medium goblem======" + "\n"))
                                                     f.write(str("User defeated medium goblem " + "\n"))
                                                     f.write(str("Gold + 10\n"))
                                                     f.write(str("exp + 20\n"))
                                                     f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                     f.write(str("Gold = " + str(gold) + "\n"))
                                                     f.write(str("Health = " + str(health) + "\n"))
                                                     f.write(str("Level = " + str(level) + "\n"))
                                                     f.write(str("\n"))
                                                     f.write(str("\n"))
                                                     f.close()
                                                
                                                  previous = int(2)
                                                  save = True
                                                  break

                                               elif enemyHealth >=1:
                                                  print('-')
                                                  print('The enemy swung at you!')
                                                  damage = random.randrange(1, 3)
                                                  health -= damage
                                                  totalHealthLose += damage
                                                  if health <= 0:
                                                     event = int()
                                                  else:
                                                     continue
                                                   
                                            else:
                                               with open("userLog","a") as f:
                                                  now = date.today()
                                                  date_now = now.strftime("%#d\%#m\%y")
                                                  now1 = datetime.now()
                                                  time_now = now1.strftime("%H:%M")
                                                  
                                                  f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                  f.write(str("======Medium goblem======" + "\n"))
                                                  f.write(str("User was defeated by medium goblem " + "\n"))
                                                  f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                  f.write(str("Health = " + str(health) + "\n"))
                                                  f.write(str("\n"))
                                                  f.write(str("\n"))
                                                  f.close()
                                               break
                                                
                                      elif Input.lower() == "n":
                                         print('')
                                         print('You ran away from the medium goblem, and got home in one piece.')
                                         print('')
                                         previous = int(2)
                                         event = int()
                                      elif Input.lower() == "q":
                                         break
                                    
#MEDIUM GOBLEM^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#HUGE GOBLEM===========================================================================================================================================================
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                                while event == int(3):
                                   if previous == int(3):
                                      event = int()
                                   else:
                                      if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                         if wood_durability <= 20:
                                            print('Your durability is running low on wooden sword!')
                                      elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                         if stone_durability <= 20:
                                            print('Your durability is running low on stone sword!')
                                      elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                         if iron_durability <= 20:
                                            print('Your durability is running low on iron sword!')
                                      print('---------------------------------------------------------------------')
                                      print('======Huge goblem======')
                                      print('You triped and as you look up you see a huge goblem')
                                      print('Do you wish to attack it? y/n')
                                      print('Defeat reward: +20 exp +15 Gold.')
                                      Input = input(': ')

                                      if Input.lower() == "y":
                                         enemyHealth = random.randrange(30, 46)
                                         totalDurabilityLose = int()
                                         totalHealthLose = int()
                                         while True:
                                            if health >= 1:
                                               print('-')
                                               print('You hit the medium goblem!')
                                               durabilityLose = random.randrange(1, 3)
                                               if ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                                                  enemyHealth -= punch_attack
                                               elif ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                  enemyHealth -= wood_attack
                                                  wood_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                               elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                  enemyHealth -= stone_attack
                                                  stone_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                               elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                  enemyHealth -= iron_attack
                                                  iron_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                             
                                               if enemyHealth <= 0:
                                                  print('==========================')
                                                  print('''And then finally cut his foot off triped the huge goblem over and stabed him in the neck!''')
                                                  print('===+BATTLE RESOULTS+===')
                                                  if ACTIVE_WEPOND.activeWepond != 'FIST_PUNCH':
                                                     print('You lost',totalDurabilityLose,'durability')
                                                     print('and',totalHealthLose,'health.')
                                                     if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',wood_durability,'')
                                                        if wood_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                     elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',stone_durability,'')
                                                        if stone_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                     elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',iron_durability,'')
                                                        if iron_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                  elif ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                                                     print('You lost',totalHealthLose,'health.')
                                                  print('Current health:',health)
                                                  gold += 15
                                                  exp += 20
                                                   
                                                  with open("userLog.txt","a") as f:
                                                     now = date.today()
                                                     date_now = now.strftime("%#d\%#m\%y")
                                                     now1 = datetime.now()
                                                     time_now = now1.strftime("%H:%M")
                                                      
                                                     f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                     f.write(str("======Huge goblem======" + "\n"))
                                                     f.write(str("User defeated Huge goblem " + "\n"))
                                                     f.write(str("Gold + 15\n"))
                                                     f.write(str("exp + 20\n"))
                                                     f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                     f.write(str("Gold = " + str(gold) + "\n"))
                                                     f.write(str("Health = " + str(health) + "\n"))
                                                     f.write(str("Level = " + str(level) + "\n"))
                                                     f.write(str("\n"))
                                                     f.write(str("\n"))
                                                     f.close()
                                                   
                                                  previous = int(3)
                                                  save = True
                                                  break

                                               elif enemyHealth >=1:
                                                  print('-')
                                                  print('The enemy swung at you!')
                                                  damage = random.randrange(1, 3)
                                                  health -= damage
                                                  totalHealthLose += damage
                                                  if health <= 0:
                                                     event = int()
                                                  else:
                                                     continue
                                            else:
                                               with open("userLog","a") as f:
                                                  now = date.today()
                                                  date_now = now.strftime("%#d\%#m\%y")
                                                  now1 = datetime.now()
                                                  time_now = now1.strftime("%H:%M")
                                                   
                                                  f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                  f.write(str("======Huge goblem======" + "\n"))
                                                  f.write(str("User was defeated by huge goblem " + "\n"))
                                                  f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                  f.write(str("Health = " + str(health) + "\n"))
                                                  f.write(str("\n"))
                                                  f.write(str("\n"))
                                                  f.close()
                                               break
                                                   
                                      elif Input.lower() == "n":
                                         print('')
                                         print('You ran away from the huge goblem, and got home in one piece.')
                                         print('')
                                         previous = int(3)
                                         event = int()
                                      elif Input.lower() == "q":
                                         break
                                    
#HUGE GOBLEM^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#DEAMON================================================================================================================================================================
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                                while event == int(4):
                                   if previous == int(4):
                                      event = int()
                                   else:
                                      if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                         if wood_durability <= 20:
                                            print('Your durability is running low on wooden sword!')
                                      elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                         if stone_durability <= 20:
                                            print('Your durability is running low on stone sword!')
                                      elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                         if iron_durability <= 20:
                                            print('Your durability is running low on iron sword!')
                                      print('---------------------------------------------------------------------')
                                      print('======Deamon======')
                                      print('You found yourself staring into the eye\'s\nof a deamon!')
                                      print('Do you wish to attack it? y/n')
                                      print('Defeat reward: +20 exp +20 Gold.')
                                      print('Chance of one health potion!')
                                      Input = input(': ')

                                      if Input.lower() == "y":
                                         enemyHealth = random.randrange(45, 61)
                                         totalDurabilityLose = int()
                                         totalHealthLose = int()
                                         while True:
                                            if health >= 1:
                                               print('-')
                                               print('You hit the deamon!')
                                               durabilityLose = random.randrange(1, 6)
                                               if ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                                                  enemyHealth -= punch_attack
                                               elif ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                  enemyHealth -= wood_attack
                                                  wood_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                               elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                  enemyHealth -= stone_attack
                                                  stone_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                               elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                  enemyHealth -= iron_attack
                                                  iron_durability -= durabilityLose
                                                  totalDurabilityLose += durabilityLose
                                             
                                               if enemyHealth <= 0:
                                                  give_health = random.randrange(1, 101)#1-100
                                                  print('==========================')
                                                  print('And managed to stabe the deamon in the heart!')
                                                  print('===+BATTLE RESOULTS+===')
                                                  if give_health >= 90:
                                                     print('You found a health potion on the deamon!')
                                                     healthPotion += 1
                                                  if ACTIVE_WEPOND.activeWepond != 'FIST_PUNCH':
                                                     print('You lost',totalDurabilityLose,'durability')
                                                     print('and',totalHealthLose,'health.')
                                                     if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',wood_durability,'')
                                                        if wood_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                     elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',stone_durability,'')
                                                        if stone_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                     elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                                                        print('Current durability on',ACTIVE_WEPOND.activeWepond,':',iron_durability,'')
                                                        if iron_durability <= -1:
                                                           print('You lost some coins because you had to fix your weapon!')
                                                           gold -= 5
                                                  elif ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                                                     print('You lost',totalHealthLose,'health.')
                                                  print('Current health:',health)
                                                  gold += 20
                                                  exp += 40
                                                   
                                                  with open("userLog","a") as f:
                                                     now = date.today()
                                                     date_now = now.strftime("%#d\%#m\%y")
                                                     now1 = datetime.now()
                                                     time_now = now1.strftime("%H:%M")
                                                      
                                                     f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                     f.write(str("======Deamon======" + "\n"))
                                                     f.write(str("User defeated deamon " + "\n"))
                                                     f.write(str("Gold + 20\n"))
                                                     f.write(str("exp + 40\n"))
                                                     f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                     f.write(str("Gold = " + str(gold) + "\n"))
                                                     f.write(str("Health = " + str(health) + "\n"))
                                                     f.write(str("Level = " + str(level) + "\n"))
                                                     f.write(str("\n"))
                                                     f.write(str("\n"))
                                                     f.close()
                                                   
                                                  previous = int(4)
                                                  save = True
                                                  break

                                               elif enemyHealth >=1:
                                                  print('-')
                                                  print('The enemy swung at you!')
                                                  damage = random.randrange(1, 6)
                                                  health -= damage
                                                  totalHealthLose += damage
                                                  if health <= 0:
                                                     event = int()
                                                  else:
                                                     continue
                                                   
                                            else:
                                               with open("userLog","a") as f:
                                                  now = date.today()
                                                  date_now = now.strftime("%#d\%#m\%y")
                                                  now1 = datetime.now()
                                                  time_now = now1.strftime("%H:%M")
                                                   
                                                  f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                                  f.write(str("======Deamon======" + "\n"))
                                                  f.write(str("User was defeated by deamon " + "\n"))
                                                  f.write(str("Health - " + str(totalHealthLose) + "\n"))
                                                  f.write(str("Health = " + str(health) + "\n"))
                                                  f.write(str("\n"))
                                                  f.write(str("\n"))
                                                  f.close()
                                               break
                                                   
                                      elif Input.lower() == "n":
                                         print('')
                                         print('You ran away from the deamon, and got home in one piece.')
                                         print('')
                                         previous = int(4)
                                         event = int()
                                      elif Input.lower() == "q":
                                         break
                                       


#DEAMON^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#CHANGE WEPOND=========================================================================================================================================================
#3.7.0 STANDERDS|UPDATE_IN_PROGRESS|                
                          elif Input == "2":
                             while True:
                                print('Choose a wepon to use!')
                                print('0--> punch.')
                                print('1--> Wooden sword.')
                                print('2--> Stone sword.')
                                print('3--> Iron sword.')
                                print('q--> Exit')
                                Input = input(': ')

                                if Input == "0":
                                   if punch_owned == True:

                                      path = os.getcwd() + r'\saves'

                                      wepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                      f = open(wepond, "w")
                                      f.write("activeWepond = 'FIST_PUNCH'\n")
                                      f.close()
                                      print('---------------------')
                                      print('Equiped fists.')
                                      print('---------------------')
                                      save = True
                                      continue
                                 
                                   elif punch_owned == False:
                                      print('----------------------------')
                                      print('You dont own a wooden sword.')
                                      print('----------------------------')
                                      continue

                                elif Input == "1":
                                   if wood_owned == True:

                                      path = os.getcwd() + r'\saves'
                                   
                                      wepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                      f = open(wepond, "w")
                                      f.write("activeWepond = 'WOODEN_SWORD'\n")
                                      f.close()
                                      print('---------------------')
                                      print('Equiped wooden sword.')
                                      print('---------------------')
                                      save = True
                                      continue
                                 
                                   elif wood_owned == False:
                                      print('----------------------------')
                                      print('You dont own a wooden sword.')
                                      print('----------------------------')
                                      continue

                                elif Input == "2":
                                   if stone_owned == True:

                                      path = os.getcwd() + r'\saves'
                                   
                                      wepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                      f = open(wepond, "w")
                                      f.write("activeWepond = 'STONE_SWORD'\n")
                                      f.close()
                                      print('--------------------')
                                      print('Equiped stone sword.')
                                      print('--------------------')
                                      save = True
                                      continue
                                    
                                   elif stone_owned == False:
                                      print('---------------------------')
                                      print('You dont own a stone sword.')
                                      print('---------------------------')
                                      continue

                                elif Input == "3":
                                   if iron_owned == True:

                                      path = os.getcwd() + r'\saves'
                                   
                                      wepond = os.path.join(path, 'ACTIVE_WEPOND.py')
                                      f = open(wepond, "w")
                                      f.write("activeWepond = 'IRON_SWORD'\n")
                                      f.close()
                                      print('-------------------')
                                      print('Equiped iron sword.')
                                      print('-------------------')
                                      save = True
                                      continue

                                   elif stone_owned == False:
                                      print('--------------------------')
                                      print('You dont own a iron sword.')
                                      print('--------------------------')
                                      continue
                                    
                                elif Input.lower() == "q":
                                   break


                          elif Input.lower() == "q": #quit to menu.
                              break
                        
                 except Exception as Error:
                    Error = (Error,'play, choose wepond')
                    ErrorInfo = Error
                    save = True
                    print('===============')
                    print('AN ERROR ACURED')
                    print('===============')

#CHANGE WEAPONED^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                    
#SHOP-----------------------------------------------------------------------------------------------------------------------------------------------------------------#
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
              if Input == "2":
                 try:
                    while True:
                       item = str('')
                       amount = int(0)
                       price = int(0)
                      
                       items1 = ['1 health potion','2 food','3 wooden sword','4 stone sword','5 iron sword','6 wood','7 stone','8 iron']
                       items2 = ['1 health potion','2 food','3 wooden sword','4 stone sword','5 iron sword','6 wood','7 stone','8 iron']
                       items3 = ['1 health potion','2 food','3 wooden sword','4 stone sword','5 iron sword','6 wood','7 stone','8 iron']
                       items4 = ['1 health potion','2 food','3 wooden sword','4 stone sword','5 iron sword','6 wood','7 stone','8 iron']

                       items1 = (random.choice(items1))
                       items2 = (random.choice(items2))
                       items3 = (random.choice(items3))
                       items4 = (random.choice(items4))
                      
                       if items1 == items2: #items3 items4:# == items3 and items4:                                   #if item is the same in item2 then try again.
                          continue
                       elif items3 == items4: #This was hard, dont wreck it lol.
                          continue
                       elif items1 == items3:
                          continue
                       elif items2 == items4:
                          continue
                       elif items1 == items4:
                          continue
                       elif items2 == items3:
                          continue
                      
                       else:                                                                                         #if items was different from items2
                          print('---------------------------------------------------------------------') #!!!!!!!CAN NOT UPDATE BEOND THIS POINT.
                          print('======SHOP======')
                          print('Gold:',gold)
                          print('This is what i have to offer.')
                          print('q to exit.')
                          print(items1,'-',items2)                                                                  #prints the selected items
                          print(items3,'-',items4)                                                                  #prints the selected items2
                          Input = input('Press a number to buy: ')                                                  #gives user choice of what they want

#health potion code, price of one health potion 20$====================================================================================================================
#V3.7.0 STANDERS|UPDATED_SUCCESSFULLY|
                          if Input == "1":#if user enters 1...
                              if items1 == "1 health potion" or items2 == "1 health potion" or items3 == "1 health potion" or items4 == "1 health potion":#if it is one of the items listed...
                                 while True:
                                  item = str('health potion\s')                                                     #set item to health potion...
                                  try:
                                     print('---------------------------------------------------------------------')
                                     print('How many',item,'do you want?')                                          #asks how many of the item you want...
                                     amount = int(input(': '))                                                      #amount is what ever the user enters...
                                  except ValueError:
                                     print('---------------------------------------------------------------------')
                                     print('Please dont use letters.')
                                     continue
                                  price = 20 * amount                                                               #price = 20 x the amount of items you want...
                                  print('---------------------------------------------------------------------')
                                  print('would you like to purchas',item,'x',amount,'for',price,'gold? y/n')      #confirms purchas of item, amount, price...
                                  Input = input(': ')                                                               #gets yes or no answer for purchase...

                                  if Input.lower() == "y" or Input.lower() == "yes":                                #if user enters y, yes...
                                      
                                      if gold < price:                                                              #check if user dose not have enough gold...
                                          print('---------------------------------------------------------------------')
                                          print('Sorry you dont have enough gold for',amount, item + '.')             #if user dose not have enough gold tell them...
                                          break                                                                     #then continue back to start...
                                      
                                      elif gold >= price:                                                           #else if user has enough gold...
                                          print('---------------------------------------------------------------------')
                                          print('Your purchas was successful!')                                     #tell them it was successfully bought...
                                          healthPotion += amount                                                    #give user the amount purchased of item...
                                          gold -= price                                                             #take price away from gold...
                                          with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("Health potion + " + str(amount) + "\n"))
                                             f.write(str("Health potion = " + str(healthPotion) + "\n"))
                                             f.write(str("Gold - " + str(price) + "\n"))
                                             f.write(str("Gold = " + str(gold) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                             save = True
                                          print('Anything else?')                                                   #prints anything else...
                                          break                                                                     #continues to start...
                                      
                                  elif Input.lower() == "n" or Input.lower() == "no":                               #else if user enters n, no...
                                     print('---------------------------------------------------------------------')
                                     print('Anything else?')                                                        #print anything else...
                                     break                                                                          #continues to start...

                              else:                                                                                 #else if item isnt listed...
                                  continue                                                                          #send user back to start.

#Food code, price of one food 10$=============================================================================================================================
#V3.7.0 STANDERS|UPDATED_SUCCESSFULLY|
                          if Input == "2":#if user enters 2...
                              if items1 == "2 food" or items2 == "2 food" or items3 == "2 food" or items4 == "2 food":#if it is one of the items listed...
                                 while True:
                                    item = str('Food')                                                                #set item to health potion...
                                    try:
                                       print('---------------------------------------------------------------------')
                                       print('How many',item,'do you want?')                                          #asks how many of the item you want...
                                       amount = int(input(': '))                                                      #amount is what ever the user enters...
                                    except ValueError:
                                       print('---------------------------------------------------------------------')
                                       print('Please dont use letters.')
                                       continue
                                    price = 10 * amount                                                               #price = 20 x the amount of items you want...
                                    print('---------------------------------------------------------------------')
                                    print('would you like to purchas',item,'x',amount,'for',price,'gold? y/n')      #confirms purchas of item, amount, price...
                                    Input = input(': ')                                                               #gets yes or no answer for purchase...

                                    if Input.lower() == "y" or Input.lower() == "yes":                                #if user enters y, yes...
                                       if gold < price:                                                               #check if user dose not have enough gold...
                                          print('---------------------------------------------------------------------')
                                          print('Sorry you dont have enough gold for',amount, item + '.')             #if user dose not have enough gold tell them...
                                          break                                                                     #then continue back to start...
                                      
                                       elif gold >= price:
                                          print('---------------------------------------------------------------------')#else if user has enough gold...
                                          print('Your purchas was successful!')                                     #tell them it was successfully bought...
                                          food += amount                                                            #give user the amount purchased of item...
                                          gold -= price                                                             #take price away from gold...
                                          with open("userLog","a") as f:
                                             now = date.today()
                                             date_now = now.strftime("%#d\%#m\%y")
                                             now1 = datetime.now()
                                             time_now = now1.strftime("%H:%M")
                                             f.write(str("Date: " + str(date_now) + " Time: " + str(time_now) + "\n"))
                                             f.write(str("Food + " + str(amount) + "\n"))
                                             f.write(str("Food = " + str(food) + "\n"))
                                             f.write(str("Gold - " + str(price) + "\n"))
                                             f.write(str("Gold = " + str(gold) + "\n"))
                                             f.write(str("\n"))
                                             f.write(str("\n"))
                                             f.close()
                                             save = True
                                          print('Anything else?')                                                   #prints anything else...
                                          break                                                                     #continues to start...
                                      
                                    elif Input.lower() == "n" or Input.lower() == "no":                             #else if user enters n, no...
                                       print('---------------------------------------------------------------------')
                                       print('Anything else?')                                                       #print anything else...
                                       break                                                                         #continues to start...

                              else:                                                                                 #else if item isnt listed...
                                  continue                                                                          #send user back to start.

#Wooden sword code, price of 1 wooden sword 50$------------------------------------------------------------------------------------------------------------------------
#V3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                          if Input == "3":#if user enters 3...
                             if items1 == "3 wooden sword" or items2 == "3 wooden sword" or items3 == "3 wooden sword" or items4 == "3 wooden sword":
                                item = str('Wooden sword')
                                if wood_owned == False:
                                   while True:
                                      print('---------------------------------------------------------------------')
                                      print('Would you like to buy',item,'for 50 gold? y/n')
                                      Input = input(': ')

                                      if Input.lower() == "y":
                                         if gold >= 50:
                                            gold -= 50
                                            wood_owned = True
                                            print('---------------------------------------------------------------------')
                                            print('Successfully purchased',item + '!')
                                            break
                                             
                                         elif gold < 50:
                                            print('---------------------------------------------------------------------')
                                            print('Sorry you dont have enough gold for',item + '.')
                                            save = True
                                            break
                                          
                                      elif Input.lower() == "n":
                                         print('---------------------------------------------------------------------')
                                         print('Anything else?')
                                         break
                                       
                                else:
                                   print('---------------------------------------------------------------------')
                                   print('You already own',item + '.')
                                   continue

                          elif Input.lower() == "q" or Input.lower() == "quit":
                             break

#Stone sword code, price of 1 stone sword 100$-------------------------------------------------------------------------------------------------------------------------
#V3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                          if Input == "4":#if user enters 4...
                             if items1 == "4 stone sword" or items2 == "4 stone sword" or items3 == "4 stone sword" or items4 == "4 stone sword":
                                item = str('Stone sword')
                                if stone_owned == False:
                                   while True:
                                      print('---------------------------------------------------------------------')
                                      print('Would you like to buy',item,'for 500 gold? y/n')
                                      Input = input(': ')

                                      if Input.lower() == "y":
                                         if gold >= 500:
                                            gold -= 500
                                            stone_owned = True
                                            print('---------------------------------------------------------------------')
                                            print('Successfully purchased',item,'!')
                                            save = True
                                            break
                                          
                                         elif gold < 500:
                                            print('---------------------------------------------------------------------')
                                            print('Sorry you dont have enough gold for',item,'.')
                                            break
                                          
                                      elif Input.lower() == "n":
                                         print('---------------------------------------------------------------------')
                                         print('Anything else?')
                                         break
                                else:
                                   print('---------------------------------')
                                   print('You already own',item,'.')
                                   continue

                          elif Input == "q" or Input == "quit":
                             break
                           
#Iron sword code, price of 1 iron sword 200$-------------------------------------------------------------------------------------------------------------------------
#V3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                          if Input == "5":#if user enters 5...
                             if items1 == "5 iron sword" or items2 == "5 iron sword" or items3 == "5 iron sword" or items4 == "5 iron sword":
                                item = str('Iron sword')
                                if iron_owned == False:
                                   while True:
                                      print('---------------------------------------------------------------------')
                                      print('Would you like to buy',item,'for 1200 gold? y/n')
                                      Input = input(': ')

                                      if Input.lower() == "y":
                                         if gold >= 1200:
                                            gold -= 1200
                                            iron_owned = True
                                            print('---------------------------------------------------------------------')
                                            print('Successfully purchased',item + '!')
                                            save = True
                                            break
                                          
                                         elif gold < 1200:
                                            print('---------------------------------------------------------------------')
                                            print('Sorry you dont have enough gold for',item + '.')
                                            break
                                          
                                      elif Input.lower() == "n":
                                         print('---------------------------------------------------------------------')
                                         print('Anything else?')
                                         break

                                else:
                                   print('---------------------------------------------------------------------')
                                   print('You already own',item + '.')
                                   continue

                          elif Input == "q" or Input == "quit":
                             break

#wood code, price of 1 wood 25$-------------------------------------------------------------------------------------------------------------------------
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                          if Input == "6":#if user enters 6...
                             if items1 == "6 wood" or items2 == "6 wood" or items3 == "6 wood" or items4 == "6 wood":
                                item = str('wood')
                                while True:
                                   print('---------------------------------------------------------------------')
                                   print('How much',item,'would you like to purchase?')
                                   amount = int(input(': '))
                                   
                                   price = amount * 25
                                   print('---------------------------------------------------------------------')
                                   print('Would you like to purchase',amount,item,'for',price,'gold? y/n')
                                   Input = input(': ')

                                   if Input.lower() == "y":
                                      if gold >= price:
                                         wood += amount
                                         gold -= price
                                         print('---------------------------------------------------------------------')
                                         print('Successfully purchased',item + '!')
                                         save = True
                                         break
                                          
                                      elif gold < price:
                                         print('---------------------------------------------------------------------')
                                         print('Sorry you dont have enough gold for',amount,item + '.')
                                         break
                                       
                                   elif Input.lower() == "n":
                                      print('---------------------------------------------------------------------')
                                      print('Anything else?')
                                      break

#stone code, price of 1 stone 65$-------------------------------------------------------------------------------------------------------------------------
#V3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                          if Input == "7":#if user enters 7...
                             if items1 == "7 stone" or items2 == "7 stone" or items3 == "7 stone" or items4 == "7 stone":
                                item = str('stone')
                                while True:
                                   print('---------------------------------------------------------------------')
                                   print('How much',item,'would you like to purchase?')
                                   amount = int(input(': '))
                                   price = amount * 65
                                   print('---------------------------------------------------------------------')
                                   print('Would you like to purchase',amount,item,'for',price,'gold? y/n')
                                   Input = input(': ')

                                   if Input.lower() == "y":
                                      if gold >= price:
                                         stone += amount
                                         gold -= price
                                         print('---------------------------------------------------------------------')
                                         print('Successfully purchased',item + '!')
                                         save = True
                                         break
                                          
                                      elif gold < price:
                                         print('---------------------------------------------------------------------')
                                         print('Sorry you dont have enough gold for',amount,item + '.')
                                         break
                                       
                                   elif Input.lower() == "n":
                                      print('---------------------------------------------------------------------')
                                      print('Anything else?')
                                      break

#iron code, price of 1 stone 100$-------------------------------------------------------------------------------------------------------------------------
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
                          if Input == "8":#if user enters 8...
                             if items1 == "8 iron" or items2 == "8 iron" or items3 == "8 iron" or items4 == "8 iron":
                                item = str('iron')
                                while True:
                                   print('---------------------------------------------------------------------')
                                   print('How much',item,'would you like to purchase?')
                                   amount = int(input(': '))
                                   price = amount * 100
                                   print('---------------------------------------------------------------------')
                                   print('Would you like to purchase',amount,item,'for',price,'gold? y/n')
                                   Input = input(': ')

                                   if Input.lower() == "y":
                                      if gold >= price:
                                         iron += amount
                                         gold -= price
                                         print('---------------------------------------------------------------------')
                                         print('Successfully purchased',item + '!')
                                         save = True
                                         break
                                          
                                      elif gold < price:
                                         print('---------------------------------------------------------------------')
                                         print('Sorry you dont have enough gold for',amount,item + '.')
                                         break
                                       
                                   elif Input.lower() == "n":
                                      print('---------------------------------------------------------------------')
                                      print('Anything else?')
                                      break
                                       

                          elif Input.lower() == "q" or Input.lower() == "quit": #hole game quit do not touch!!!
                             break



                 except Exception as Error:#whole shop error system.
                    Error = (Error,'shop')
                    ErrorInfo = Error
                    save = True
                    print('===============')
                    print('AN ERROR ACURED')
                    print('===============')          
                           
#VIEW PROFILE---------------------------------------------------------------------------------------------------------------------------------------------------------#
#V3.7.0 STANDERDS|NO_UPDATE_NEEDED|
              elif Input == "3": #View profile.
                  print('---------------------------------------------------------------------')
                  while True:
                     if (exp) >= (next_level_up):
                        level += 1
                        exp -= next_level_up
                        next_level_up += next_level_up
                        continue
                     
                     elif (exp) != (next_level_up):
                        try:
                           reload(ACTIVE_WEPOND)                           #incase user changes their wepond.
                           print('======' + (name) +'\'s profile======') 
                           print('Current level:',(level))
                           print('EXP till next level:',next_level_up)
                           print('EXP:',exp)
                           print('Health:',(health))
                           print('Gold:',(gold))
                           print('Active wepond:',ACTIVE_WEPOND.activeWepond)
                           if ACTIVE_WEPOND.activeWepond == 'WOODEN_SWORD':
                              print('Attack:',wood_attack)
                              print('Durability:',wood_durability)
                           elif ACTIVE_WEPOND.activeWepond == 'STONE_SWORD':
                              print('Attack:',stone_attack)
                              print('Durability:',stone_durability)
                           elif ACTIVE_WEPOND.activeWepond == 'IRON_SWORD':
                              print('Attack:',iron_attack)
                              print('Durability:',iron_durability)
                           elif ACTIVE_WEPOND.activeWepond == 'FIST_PUNCH':
                              print('Attack:',punch_attack)
                              print('Durability:',punch_durability)
                           else:
                              print('You dont have an equiped wepond.')
                              
                           print('')
                           print('======' + (name) +'\'s inventory======')
                           print('Health potion: ',healthPotion)
                           print('Food: ',food)
                           print('Wood: ',wood)
                           print('Stone: ',stone)
                           print('Iron: ',iron)
                           print('Wooden sword owned: ',wood_owned)
                           print('Stone sword owned: ',stone_owned)
                           print('Iron sword owned: ',iron_owned)
                           
                        except Exception as Error:
                           Error = (Error,'view profile')
                           ErrorInfo = Error
                           save = True
                           print('===============')
                           print('AN ERROR ACURED')
                           print('===============')
                        
                        print('\npress ENTER to continue.')
                        Input = input('')
                        break

#SAVE PROGRESS--------------------------------------------------------------------------------------------------------------------------------------------------------#
#3.7.0 STANDERDS|UPDATED_SUCCESSFULLY|
              elif Input == "4": #Save progress.
                 print('---------------------------------------------------------------------')
                 try:
                    path = os.getcwd() + r'\saves'

                    print('Saving new game data...')

                    savesave = os.path.join(path, 'player_save.py')
                    f = open(savesave, "w")
                    f.write("name = '" + str(name) + "' \n")
                    f.write("exp = " + str(exp) + "\n")
                    f.write("next_level_up = " + str(next_level_up) + "\n")
                    f.write("level = " + str(level) + "\n")
                    f.write("health = " + str(health) + "\n")
                    f.write("gold = " + str(gold) + "\n")
                    f.write("healthPotion = " + str(healthPotion) + "\n")
                    f.write("food = " + str(food) + "\n")
                    f.write("wood = " + str(wood) + "\n")
                    f.write("stone = " + str(stone) + "\n")
                    f.write("iron = " + str(iron) + "\n")
                    f.close()

                    path2 = os.getcwd() + r'\saves\WEPONDS'
            
                    savewoodsword = os.path.join(path2, 'WOODEN_SWORD.py')
                    f = open(savewoodsword, "w")
                    f.write("wood_owned = " + str(wood_owned) + "\n")
                    f.write("wood_durability = " + str(wood_durability) + "\n")
                    f.write("wood_attack = " + str(wood_attack) + "\n")
                    f.close()

                    savestonesword = os.path.join(path2, 'STONE_SWORD.py')
                    f = open(savestonesword, "w")
                    f.write("stone_owned = " + str(stone_owned) + "\n")
                    f.write("stone_durability = " + str(stone_durability) + "\n")
                    f.write("stone_attack = " + str(stone_attack) + "\n")
                    f.close()

                    saveironsword = os.path.join(path2, 'iron_SWORD.py')
                    f = open(saveironsword, "w")
                    f.write("iron_owned = " + str(iron_owned) + "\n")
                    f.write("iron_durability = " + str(iron_durability) + "\n")
                    f.write("iron_attack = " + str(iron_attack) + "\n")
                    f.close()
                    
                    print('Saved successfully!')
                    save = False
                    
                 except Exception as Error:
                    Error = (Error,'SAVE PROGRESS')
                    print('==================================================')
                    print('CRITICAL PROCESS ERROR:\nPLEASE CONTACT ejmultigames@gmail.com for support!\nError:',Error,'\nInclude this message in the email!!!')
                    print('==================================================')
                    save = False
            
#END------------------------------------------------------------------------------------------------------------------------------------------------------------------#

if __name__ == '__main__':
    Thread(target = auto_reload).start()
    time.sleep(1)#lets the reload, reload before thread 2 starts.
    Thread(target = main_game).start()
#ERROR_HANDLING.error_detect()


