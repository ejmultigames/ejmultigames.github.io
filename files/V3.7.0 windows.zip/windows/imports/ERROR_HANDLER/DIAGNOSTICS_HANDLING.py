import sys
sys.path.append('../../')
from saves.player_save import *
from saves.WEPONDS.FIST_PUNCH import *
from saves.WEPONDS.IRON_SWORD import *
from saves.WEPONDS.STONE_SWORD import *
from saves.WEPONDS.WOODEN_SWORD import *
from saves.ACTIVE_WEPOND import *
from saves.player_save import *


def diagnostics_check():
    print('_____________________________________________________________')
    print('CHECKING...')

    print('saves/WEAPONDS/')
    print('')
    print('BEGINING CHECK ON "FIST_PUNCH"')

    try:
        if punch_owned == punch_owned:
            print('punch_owned = Working')
            one = 'working'
    except Exception as Error:
        print('punch_owned = ERROR',Error)
        one = 'error'
        
    try:
        if punch_durability == punch_durability:
            print('punch_durability = Working')
            two = 'working'
    except Exception as Error:
        print('punch_durability = ERROR',Error)
        two = 'error'
        
    try:
        if punch_attack == punch_attack:
            print('punch_attack = Working')
            three = 'working'
    except Exception as Error:
        print('punch_attack = ERROR',Error)
        three = 'error'

    print('++++++++++++++++++++++')

    if one == 'working' and two == 'working' and three == 'working':
        print('PUNCH_SWORD = FULLY OPPERATIONAL')

    elif one == 'error' and two == 'error' and three == 'error':
        print('PUNCH_SWORD = DOWN-')

    elif one == 'working' and two == 'error' and three == 'error':
        print('ERROR DETECTED IN "punch_durability" AND "punch_attack"')

    elif one == 'error' and two == 'error' and three == 'working':
        print('ERROR DETECTED IN "punch_owned" AND "punch_durability"')

    elif one == 'error' and two == 'working' and three == 'error':
        print('ERROR DETECTED IN "punch_owned" AND "punch_attack"')
        

    elif one == 'error' and two == 'working' and three == 'working':
        print('ERROR DETECTED IN "punch_owned"')

    elif one == 'working' and two == 'error' and three == 'working':
        print('ERROR DETECTED IN "punch_durability"')

    elif one == 'working' and two == 'working' and three == 'error':
        print('ERROR DETECTED IN "punch_attack"')


    print('_____________________________________________________________')
    print('CHECKING...')

    print('saves/WEAPONDS/')
    print('')
    print('BEGINING CHECK ON "IRON_SWORD"')

    try:
        if iron_owned == iron_owned:
            print('iron_owned = Working')
            one = 'working'
    except Exception as Error:
        print('iron_owned = ERROR',Error)
        one = 'error'
        
    try:
        if iron_durability == iron_durability:
            print('iron_durability = Working')
            two = 'working'
    except Exception as Error:
        print('iron_durability = ERROR',Error)
        two = 'error'
        
    try:
        if iron_attack == iron_attack:
            print('iron_attack = Working')
            three = 'working'
    except Exception as Error:
        print('iron_attack = ERROR',Error)
        three = 'error'

    print('++++++++++++++++++++++')

    if one == 'working' and two == 'working' and three == 'working':
        print('IRON_SWORD = FULLY OPPERATIONAL')

    elif one == 'error' and two == 'error' and three == 'error':
        print('IRON_SWORD = DOWN-')

    elif one == 'working' and two == 'error' and three == 'error':
        print('ERROR DETECTED IN "iron_durability" AND "iron_attack"')

    elif one == 'error' and two == 'error' and three == 'working':
        print('ERROR DETECTED IN "iron_owned" AND "iron_durability"')

    elif one == 'error' and two == 'working' and three == 'error':
        print('ERROR DETECTED IN "iron_owned" AND "iron_attack"')
        

    elif one == 'error' and two == 'working' and three == 'working':
        print('ERROR DETECTED IN "iron_owned"')

    elif one == 'working' and two == 'error' and three == 'working':
        print('ERROR DETECTED IN "iron_durability"')

    elif one == 'working' and two == 'working' and three == 'error':
        print('ERROR DETECTED IN "iron_attack"')


    print('_____________________________________________________________')
    print('CHECKING...')

    print('saves/WEAPONDS/')
    print('')
    print('BEGINING CHECK ON "STONE_SWORD"')

    try:
        if stone_owned == stone_owned:
            print('stone_owned = Working')
            one = 'working'
    except Exception as Error:
        print('stone_owned = ERROR',Error)
        one = 'error'
        
    try:
        if stone_durability == stone_durability:
            print('stone_durability = Working')
            two = 'working'
    except Exception as Error:
        print('stone_durability = ERROR',Error)
        two = 'error'
        
    try:
        if stone_attack == stone_attack:
            print('stone_attack = Working')
            three = 'working'
    except Exception as Error:
        print('stone_attack = ERROR',Error)
        three = 'error'

    print('++++++++++++++++++++++')

    if one == 'working' and two == 'working' and three == 'working':
        print('STONE_SWORD = FULLY OPPERATIONAL')

    elif one == 'error' and two == 'error' and three == 'error':
        print('STONE_SWORD = DOWN-')

    elif one == 'working' and two == 'error' and three == 'error':
        print('ERROR DETECTED IN "stone_durability" AND "stone_attack"')

    elif one == 'error' and two == 'error' and three == 'working':
        print('ERROR DETECTED IN "stone_owned" AND "stone_durability"')

    elif one == 'error' and two == 'working' and three == 'error':
        print('ERROR DETECTED IN "stone_owned" AND "stone_attack"')
        

    elif one == 'error' and two == 'working' and three == 'working':
        print('ERROR DETECTED IN "stone_owned"')

    elif one == 'working' and two == 'error' and three == 'working':
        print('ERROR DETECTED IN "stone_durability"')

    elif one == 'working' and two == 'working' and three == 'error':
        print('ERROR DETECTED IN "stone_attack"')


    print('_____________________________________________________________')
    print('CHECKING...')

    print('saves/WEAPONDS/')
    print('')
    print('BEGINING CHECK ON "WOODEN_SWORD"')

    try:
        if wood_owned == wood_owned:
            print('wood_owned = Working')
            one = 'working'
    except Exception as Error:
        print('wood_owned = ERROR',Error)
        one = 'error'
        
    try:
        if wood_durability == wood_durability:
            print('wood_durability = Working')
            two = 'working'
    except Exception as Error:
        print('wood_durability = ERROR',Error)
        two = 'error'
        
    try:
        if wood_attack == wood_attack:
            print('wood_attack = Working')
            three = 'working'
    except Exception as Error:
        print('wood_attack = ERROR',Error)
        three = 'error'

    print('++++++++++++++++++++++')

    if one == 'working' and two == 'working' and three == 'working':
        print('WOODEN_SWORD = FULLY OPPERATIONAL')

    elif one == 'error' and two == 'error' and three == 'error':
        print('WOODEN_SWORD = DOWN-')

    elif one == 'working' and two == 'error' and three == 'error':
        print('ERROR DETECTED IN "wood_durability" AND "wood_attack"')

    elif one == 'error' and two == 'error' and three == 'working':
        print('ERROR DETECTED IN "wood_owned" AND "wood_durability"')

    elif one == 'error' and two == 'working' and three == 'error':
        print('ERROR DETECTED IN "wood_owned" AND "wood_attack"')
        

    elif one == 'error' and two == 'working' and three == 'working':
        print('ERROR DETECTED IN "wood_owned"')

    elif one == 'working' and two == 'error' and three == 'working':
        print('ERROR DETECTED IN "wood_durability"')

    elif one == 'working' and two == 'working' and three == 'error':
        print('ERROR DETECTED IN "wood_attack"')


    print('_____________________________________________________________')
    print('CHECKING...')

    print('saves/')
    print('')
    print('BEGINING CHECK ON "ACTIVE_WEPOND"')

    try:
        if activeWepond == activeWepond:
            print('activeWepond = Working')
            one = 'working'
    except Exception as Error:
        print('activeWepond = ERROR',Error)
        one = 'error'
        
    print('++++++++++++++++++++++')

    if one == 'working':
        print('ACTIVE_WEPOND = FULLY OPPERATIONAL')

    elif one == 'error':
        print('ACTIVE_WEPOND = DOWN-')


    print('_____________________________________________________________')
    print('CHECKING...')

    print('saves/')
    print('')
    print('BEGINING CHECK ON "player_save"')

    try:
        if name == name:
            print('name = Working')
            one = 'working'
            error1 = ()
    except Exception as Error:
        print('name = ERROR',Error)
        one = 'error'
        error1 = 'name'
        
    try:
        if exp == exp:
            print('exp = Working')
            two = 'working'
            error2 = ()
    except Exception as Error:
        print('exp = ERROR',Error)
        two = 'error'
        error2 = 'exp'
        
    try:
        if next_level_up == next_level_up:
            print('next_level_up = Working')
            three = 'working'
            error3 = ()
    except Exception as Error:
        print('next_level_up = ERROR',Error)
        three = 'error'
        error3 = 'next_level_up'

    try:
        if level == level:
            print('level = working')
            four = 'working'
            error4 = ()
    except Exception as Error:
            print('level = ERROR',Error)
            four = 'error'
            error4 = 'level'

    try:
        if health == health:
            print('health = working')
            five = 'working'
            error5 = ()
    except Exception as Error:
            print('health = ERROR',Error)
            five = 'error'
            error5 = 'health'

    try:
        if gold == gold:
            print('gold = working')
            six = 'working'
            error6 = ()
    except Exception as Error:
            print('gold = ERROR',Error)
            six = 'error'
            error6 = 'gold'

    try:
        if healthPotion == healthPotion:
            print('healthPotion = working')
            seven = 'working'
            error7 = ()
    except Exception as Error:
            print('healthPotion = ERROR',Error)
            seven = 'error'
            error7 = 'healthPotion'

    try:
        if food == food:
            print('food = working')
            eight = 'working'
            error8 = ()
    except Exception as Error:
        print('food = ERROR',Error)
        eight = 'error'
        error8 = 'food'

    try:
        if wood == wood:
            print('wood = working')
            nine = 'working'
            error9 = ()
    except Exception as Error:
        print('wood = ERROR',Error)
        nine = 'error'
        error9 = 'wood'

    try:
        if stone == ston:
            print('stone = working')
            ten = 'working'
            error10 = ()
    except Exception as Error:
        print('stone = ERROR',Error)
        ten = 'error'
        error10 = 'stone'

    try:
        if iron == iron:
            print('iron = working')
            eleven = 'working'
            error11 = ()
    except Exception as Error:
        print('iron = ERROR',Error)
        eleven = 'error'
        error11 = 'iron'
        

    print('++++++++++++++++++++++')

    if one == 'working' and two == 'working' and three == 'working' and four == 'working' and five == 'working' and six == 'working' and seven == 'working' and eight == 'working' and nine == 'working' and ten == 'working' and eleven == 'working':
        print('player_save = FULLY OPPERATIONAL')

    elif one == 'working' and two == 'working' and three == 'working' and four == 'working' and five == 'working' and six == 'working' and seven == 'working' and eight == 'working' and nine == 'working' and ten == 'working' and eleven == 'working':
        print('player_save = DOWN-')

    else:
        print('ERRORS DETECTED IN ONE OR MULTIPLE AREAS\b')

    print('')
    print('PRESS ENTER TO CLOSE')
    Input = input(': ')
    exit()

    


diagnostics_check()

