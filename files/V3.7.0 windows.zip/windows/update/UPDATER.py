import os
print(os.getcwd())
import sys
sys.path.append('../')
import saves
from saves.WEPONDS import FIST_PUNCH, IRON_SWORD, STONE_SWORD, WOODEN_SWORD

import importlib
import update
#'F://programing/EJ MULTIGAMES/V3.7.0/updates/UPDATE_V3_7_0.py'
new_update = importlib.import_module('UPDATE_V3_7_0')

#import update
#from update import new_update

print(new_update.fist_cost)
