#press F5 TO START:

#GAME MADE BY: ETHAN HORTMAN

#GAME VERSION: V1.2.0 LATEST

#THANK YOU FOR PLAYING, ENJOY...














































































#changing any code can damage the games. do not save any changes that you might of accidently made. If you have
#any ideas, Or improvments to the code you can contact me Ethan @ [ ehors26@gmail.com ] or for updates please contact me.
#
#you are free to change code and or add content but recognition would be greatly apricited.




#scroll up now if you dont want to accidently make a mistake! or continue if deliberit.

















































#name-------------------------------------------------------------------name--------------------------------------------------------------------------------------name#
def name():
    global name
    print('---------------------------------------------------------------------')
    name = input("Input a name: ")
    main_menu()

#main menu--------------------------------------------------------------main menu----------------------------------------------------------------------------main menu#
def main_menu():

 #time-------------------------------time#
 from datetime import date
 now = date.today()
 date_now = now.strftime("%d %m %y")
 #date-------------------------------date#
 from datetime import datetime
 now1 = datetime.now()
 time_now = now1.strftime("%H:%M:%S")
 
 while True:

        import random

        import time

        import os

        print('---------------------------------------------------------------------')
        try:
         os.startfile('E:/music/[MP3FY.COM] Tiësto _ KSHMR feat. Vassy - Secrets (Official Music Video).mp3')
        except IOError:
         print('ERROR 1: failed to open music file!')
         print('---------------------------------------------------------------------')
        print('NAME:',name,'- DATE',date_now,'- TIME:',time_now,'')
        print('---------------------------------------------------------------------')
        print('welcome to 3 in 1 games this game was made by ETHAN HORSTMAN')
        game =input('''please make a selection out of...
(1, number game) (2, medieval events) (3, trivia game)
[give youself a (n)ame! or quit the program by pressing (q)uit]
/DISCLAIMER: THE 3 OFFERD GAMES ARE NOT FULLY TESTED AND ARE SUBJECT TO BREAKING
OR MAILFUNCIONING, PLEASE RESTART THE GAME IF SUCH THINGS HAPPEN AND TELL ME.
EMAIL: (ehors26@gmail.com)/: ''')   #future user agreement
        if game == "1": 
            game_one()

        elif game =="2":    #directing 1, 2, 3, name and quit to their locations.
            game_two()

        elif game == "3":
            game_three()

        elif game.lower() =="n" or game.lower() =="name":
            new_name()

        elif game.lower() == "q" or game.lower() == "quit": #closes game from home menu.
                exit()  #exits program.

        else:                                                                            #if non of the above are selected then do this
           print('---------------------------------------------------------------------')#anything exept the given inputs will resolt in this error
           print('ERROR 2: oops please choose between 1, 2, 3 or quit')                  #prints the error message
           time.sleep(1)                                                                 #waites for 1 second
           continue                                                                      #continues to main menu

#GAME 1 RANDOM NUMBER GAME------------------------------------------------------GAME 1-----------------------------------GAME 1 RANDOM NUMBER GAME
def game_one():
 import random
 import time   
 while True:
    print('---------------------------------------------------------------------')
    print('Hello',name,'and welcome to my number game.')
    answer =input('''To learn more type (i)nfo, or to start type (p)lay.
If not then type (q)uit: ''')
    if answer.lower() == "p" or answer.lower() =="play":

        print('---------------------------------------------------------------------')
        print('what would you like the game difficulty to be',name,'?')
        answer =input('type (E)asy/(H)ard: ')
        if answer.lower() == "e" or answer.lower() == "easy":

            k = int()                                                                                          #creates k as an empty integer

            while k == int():
                k = random.randrange(1, 100)                                                                    #creating k as a random number. so it will produce.
                i =int()                                                                                       #creating i as a blank interager.
                j =int(0)
                INPUT = ('')
                print('---------------------------------------------------------------------')             #making j an empty integer
                print('Im thinking of a number between 1 and 100')

                if j in range(0, 20):                                                                          #(make j an if. (self note))  #making j just go up to 20
                    
                 while i ==int():  #checking if i is clear!
                     try:
                        i=int(input('guess my number: '))
                             
                        if i==k:
                                print('You got my number!', k, ' You received', 20-j, 'points, well done')     #then print a congrates message;
                                j = int(0)
                                INPUT =input("Enter yes to play again, Or no to go to game menu.")
                            
                                if INPUT.lower() == "yes" or INPUT.lower() =="y":
                                  del k
                                  k = int()
                                  j = int(0)

                                elif INPUT.lower() == "no" or INPUT.lower() == "n":
                                    print('---------------------------------------------------------------------')
                                    print('you will be taken to game menu')
                                    time.sleep(2)
                                    continue
                                  

                                else:
                                    INPUT = input('Please enter yes or no only: ')

                                    if INPUT.lower() == "y" or INPUT.lower() == "yes":
                                      del k
                                      k = int()

                                    elif INPUT.lower() == "no" or INPUT.lower() == "n":
                                        print('---------------------------------------------------------------------')
                                        print('you will be taken to game menu')
                                        time.sleep(2)
                                        continue

                        elif j > int(19):
                            print('---------------------------------------------------------------------')
                            print('sorry you exeeded your max amount of turns.')
                            print('you will be taken to game menu')
                            time.sleep(2)
                            continue

                         
                        else:
                                if i > k:
                                  j+=1
                                  print('Go lower, you have used', j, 'turns')
                                  i=int()
                                  

                                else:
                                   j+=1
                                   print('Go higher, you have used', j, 'turns')
                                   i=int()

                     except ValueError:
                            print('---------------------------------------------------------------------')
                            print('OOPS... make shore its a number from 1 to 100!')
                            print('---------------------------------------------------------------------')

                                                                                                                                                                                
#------------------#below code is hard mode.----------------                           


        elif answer.lower() =="h" or answer.lower() =="hard":
            
                k = int()    #creates k as an empty integer

                while k == int():
                    k =random.randrange(1, 1000)     #creating k as a random number. so it will produce.
                    i =int()                         #creating i as a blank interager.
                    j =int(0)                        #making j an empty integer
                    print('Im thinking of a number between 1 and 1000')
                    print(k)

                    if j in range(0, 11):            #(make j an if. (self note))  #making j just go up to 5

                        
                        while i ==int():             #checking if i is clear!
                         try:
                            i=int(input('guess my number: '))   #then asking for user input.
                                 
                            if i==k:                 #checking if i is equal to k if correct...
                                    print('You got my number!', k, ' you received', 11-j, 'points, well done')     #then print a congrates message! then...
                                    answer =input("Enter yes to play again, Or no to quit.")
                                
                                    if answer.lower() == "yes" or answer.lower() =="y":
                                        del k
                                        k = int()
                                        j = int(0)

                                    elif answer.lower() == "no" or answer.lower() == "n":
                                        print('---------------------------------------------------------------------')
                                        print('you will be taken to home menu')
                                        time.sleep(2)
                                        continue

                                    else:
                                        answer = input('Please enter yes or no only: ')

                                        if answer.lower() == "yes" or answer.lower() == "y":
                                            del k
                                            k = int()

                                        elif answer.lower() == "no" or answer.lower() == "n":
                                            print('---------------------------------------------------------------------')
                                            print('you will be taken to game menu')
                                            time.sleep(2)
                                            continue

                            elif j > int(9):
                                print('---------------------------------------------------------------------')
                                print('sorry you exeeded your max amount of turns.')
                                print('you will be taken to game menu')
                                time.sleep(2)
                                continue

                             
                            else:
                                    if i > k:
                                        j+=1
                                        print('Go lower, you have used', j, 'turns')
                                        i=int()
                                      

                                    else:
                                        j+=1
                                        print('Go higher, you have used', j, 'turns')
                                        i=int()

                         except ValueError:
                            print('---------------------------------------------------------------------')
                            print('OOPS... make shore its a number from 1 to 1000!')
                            print('---------------------------------------------------------------------')

    elif answer.lower() =="i" or answer.lower() =="info":
       os.startfile('E:/python work/doc instructions/Game 1 user manul.docx')
       print('---------------------------------------------------------------------')
       print('you will be taken to game menu')
       print('---------------------------------------------------------------------')
       time.sleep(2)#hopefully get the program to open a web or something containing all instructions and pics.
       continue

    elif answer.lower() == "q" or answer.lower() =="quit": #i want this to send me to the main game menu;
         main_menu()

                 

                                                                           #end of game 1, number game.

    #GAME 2 MEDIEVIL EVENTS-----------------------------------------------------------GAME 2---------------------------------------------------GAME 2 MEDIEVIL EVENTS          

def game_two():                                                                           #add- ability to quit in any sittuation to home menu.                                                                                                 #add-armour to game to reduce attack
    while True:                                                                                 #add-

        print('---------------------------------------------------------------------')
        answer =input('''welcome to game 2, medieval events.
please know that this game is still in early release.
(Enter (p)lay to continue) or (i)nfo for info) or (q)uit to quit): ''')

        
        if answer.lower() =="p" or answer.lower() =="play":   

            import random
            import time
            import os

            health = int(100)        
            attack = int(25)     
            gold = int(0)
            event = int()
            level = int(0)
            green_spear = int(0)
            INPUT_TWO = ('')
            INPUT = ('')
            
            while event == int():

                if health < int(1):
                    print('you died')
                    time.sleep(2)
                    print('game over')
                    time.sleep(1)
                    main_meanu()         #START OF GAME LOOP
                    
                elif health > int(1):
                    print('HEALTH:',health)
                    print('GOLD:',gold)
                    print('ATTACK:',attack)
                    print('level:',level)
                    print('green spear/s:',green_spear)
                    print('press (q)uit at anytime')
                    event = random.randrange(1, 8) #ACCTUALLY (1, 7)
                    INPUT = ("")                   #EMPTY STRING

            #event 1-------------------------------------------------------------------------------------------------------------------------------event 1
                while event == int(1):
                     print('you have been brought into a fight against a low level goblin')
                     print('you will recieve 5 gold for defeting it.')
                     INPUT =input("do you want to attack it? y/n:")

                     if INPUT.lower() == "y":
                        print('')
                        print('You easly punched the globlan in the face and cut him open. You recived 5 gold.')
                        gold += 5
                        level += 1
                        print('') #gap in text
                        print('HEALTH:',health)
                        print('GOLD:',gold)
                        print('ATTACK:',attack)
                        print('')
                        event =int()
                        
                     elif INPUT.lower() =="n":
                        print('')
                        print('You ran away from the enemy safly')
                        print('')
                        event =int()

                     elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break
            #event 2-------------------------------------------------------------------------------------------------------------------------------------event 2
                while event == int(2):
                    print('You have stumbled accross a very wonderful blacksmith, He has offered you plus 5 attack for 20 gold.')
                    INPUT = input("Do you want to exept this offer? y/n: ")

                    if INPUT.lower() =="y":
                      if gold > int(19): #20 HIGHER
                          print('')
                          print('You are stoked as the blacksmith hands over your improved sword.')
                          attack += 5
                          gold -= 20
                          print('HEALTH:',health)
                          print('GOLD:',gold)
                          print('ATTACK:',attack)
                          print('')
                          event = int()

                      elif gold < int(20): #20 LOWER
                          print('')
                          print('You where shocked when you noticed you dont have enough money.')
                          print('')
                          event = int()

                    elif INPUT.lower() =="n":
                      print('')
                      print('You thank the blacksmith for the offer but dont exept.')
                      print('')
                      event =int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break
            #event 3-------------------------------------------------------------------------------------------------------------------------------------event 3
                while event == int(3):
                    print('You found yourself staring into the eyes of a hungry deamon.')
                    INPUT = input("Would you like to attack it? y/n: ")

                    if INPUT.lower() =="y":
                        
                        if attack > int(29): #30
                            print('')
                            print('you managed to stabe the deamon in the face and kill him with 1 blow.')
                            print('you recieved 30 gold and found a health potion of plus 10 HP!')
                            gold += 30
                            health += 10
                            level += 2
                            print('HEALTH:',health)
                            print('GOLD:',gold)
                            print('ATTACK:',attack)
                            print('level:',level)
                            print('')
                            event = int()

                        elif attack < int(29): #30
                            print('')
                            print('the deamon bent your swored and kicked you, you managed to get away with some minor scratches and broosing.')
                            health -= 10
                            attack -= 5
                            print('HEALTH:',health)
                            print('GOLD:',gold)
                            print('ATTACK:',attack)
                            print('level:',level)
                            print('')
                            print('as you walked back into town, a blacksmith saw that your sword was damaged and asked if you would like it repaired for 5 gold.')
                            INPUT_TWO = input("do you exept this offer? y/n: ")

                            if INPUT_TWO.lower() =="y":
                               if gold > int(4):
                                   print('')
                                   print('the blacksmith repaired your sword')
                                   attack += 5
                                   event = int()

                               elif gold < int(4):
                                    print('')
                                    print('sorry, said the blacksmith. you dont have enough gold.')
                                    event = int()

                            elif INPUT_TWO.lower() =="n":
                                 print('')
                                 print('you kindly rejected the blacksmiths offer')
                                 event = int()

                                
                    elif INPUT.lower() =="n":
                        print('')
                        print('you ran away from the deamon, and got home in one piece.')
                        print('')
                        event = int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break
            #event 4--------------------------------------------------------------------------------------------------------------------------event 4
                while event == int(4):
                    print('an advanced blacksmith has offered you a upgrade, for 50 gold you will get 30 more attack damage.')
                    INPUT = input("do you exept this offer? y/n: ")

                    if INPUT.lower() =="y":
                        if gold > int(49):
                           print('')
                           print('the blacksmith came back with a havely upgreaded sword')
                           attack += 30
                           gold -= 50
                           print('HEALTH:',health)
                           print('GOLD:',gold)
                           print('ATTACK:',attack)
                           print('')
                           
                           

                        elif gold < int(49):
                            print('')
                            print('sorry said the blacksmith you seem to be short on gold')
                            print('')
                            event = int()

                    elif INPUT.lower() =="n":
                        print('')
                        print('you kindly rejected the blacksmiths offer.')
                        event = int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break
            #levels check--------------------------------------------------------level 5 progress--------------------------------------------level check#
            #while event == int():
            #    if level > int(4):
            #        event = random.randrange(5, 6)
            #        
            #
            #    elif level < int(5):
            #        event = random.randrange(1, 5)
            #        INPUT = ('')
            #event 5--------------------------------------------------------------event 5/ lvl 5---------------------------------------------event 5#
                while event ==int(5):
                    if level > int(4):
                      print('')
                      print('you met a lovely girl, she has offered you 50 HP for 100 gold.')
                      INPUT = input("do you exept her offer? y/n")

                    if INPUT.lower() =="y":
                           if gold < int(99):
                               print('')
                               print('sorry you dont have enough money.')
                               print('HEALTH:',health)
                               print('GOLD:',gold)
                               print('ATTACK:',attack)
                               event = int()

                           elif gold > int(99):
                                print('')
                                print('you where given a potion of plus 50 HP!')
                                health += 50
                                gold -= 100
                                print('HEALTH:',health)
                                print('GOLD:',gold)
                                print('ATTACK:',attack)
                                event = int()

                    elif INPUT.lower() =="n":
                            print('')
                            print('you kindly rejected the girl.')
                            event = int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break

                    elif level < int(5):
                        print('level 5 event locked.')
                        event =int()

            #event 6--------------------------------------------------event 6 / lvl 5---------------------------------------------------------event 6#
                while event == int(6):                                                            #possible new item, dragon spear.
                    if level > int(4):                                                           #color coded dragons/ dragon spear.
                        print('')
                        print('You are attacked by a Green Dragon from the sky.')
                        print('you will recieve 150 gold for defeating it.')
                        INPUT = input('do you wish to attack the dragon. y/n: ')

                        if INPUT.lower() =="y":
                            if green_spear > int(0):  #spear 1 or higher
                                print('')
                                print('you defeated the dragon using 1x green spear and recived 150 gold.')
                                gold += 150
                                level += 3
                                green_spear -= 1
                                event = int()
                                
                            elif green_spear < int(1): #0
                                if attack > int(49):
                                    print('')
                                    print('you defeated the dragon and recived 150 gold.')
                                    gold += 150
                                    level += 3
                                    event = int()

                                elif attack < int(50):
                                    print('')
                                    print('you where knocked off your feet and scorched by the dragon, but managed to run away before being beheaded.')
                                    health -= 25
                                    event = int()

                        elif INPUT.lower() =="n":
                            print('')
                            print('you managed to take cover in a small shack.')
                            event = int()

                        elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                            break
                            
                    elif level < int(5):
                        print('level 5 event locked.')
                        event = int()

            #event 7------------------------------------------event 7 / any level--------------------------------------------------------------event 7#
                while event == int(7):
                    print('')
                    print('you have met an old laddy, she says she has a spear that will come in handy for later.')
                    print('though it will come at a hefty price. you can buy the spear for 65 gold.')
                    INPUT = input('do you exept the old laddys offer? y/n: ')

                    if INPUT.lower() =="y":
                        if gold > int(64):
                            print('')
                            print('the old laddy handed you the spear and walked away.')
                            green_spear += 1
                            event = int()

                        elif gold < int(65):
                            print('')
                            print('sorry said the old laddy, you seem to be low on gold, defeat a few more low lvl enemys and come back')
                            event = int()

                    elif INPUT.lower() =="n":
                        print('')
                        print('you kindly rejected the old laddy.')
                        print('')
                        event = int()

                    elif INPUT.lower() == "q" or INPUT.lower() == "quit":
                         break

#END OF EVENTS======================================================

        elif answer.lower() =="q" or answer.lower() =="quit":  #test
             main_menu()     #this is just a test because this feature dosnt currently work correctly.----------------------------------------------------error attention!
                        
        elif answer.lower() =="i" or answer.lower() =="info":
            try:
                import os
                os.startfile('E:/python work/doc instructions/GAME 2 user manul.docx')
            except (FileNotFoundError, IOError):
                print('---------------------------------------------------------------------')
                print('ERROR 3: file destination not found.')
                print('---------------------------------------------------------------------')
                print('you will now be sent back to the game menu.')
                import time
                time.sleep(3)
                continue
            else:
                 print('---------------------------------------------------------------------')
                 print('you will now be sent back to the game menu. thanks for reading the instructions')
                 import time
                 time.sleep(3)
                 continue

    #END OF MEDIEVAL EVENTS=================================================END OF MEDIEVAL EVENTS==================================================END OF MEDIEVAL EVENTS#

    #--------------------------game 3 trivia game---------------------------------------------------------------------------------------------------------------------------------------------------------------
def game_three():
    import time
    import random
    import os

    while True:
        print('---------------------------------------------------------------------')
        print('Hello ',name,' and welcome to the trivia game by me ETHAN HORSTMAN!')
        ans =input('type (i)nfo or play now? y/n: ')
        score = int(0)
        total_q = 4

                 
        if ans.lower() == "y" or ans.lower() == "yes":

            print('---------------------------------------------------------------------')
            ans = input('''whats the version thats this game was coded on? E.g v0.0.0
:''')
            if ans.lower() =="v3.7.4":
               score += 1
               print('correct')
            else:
                print('incorrect')

            ans = input('''whats is 1 + 2
:''')
            if ans =="3":
               score += 1
               print('correct')
            else:
                print('incorrect')

            ans = input('''whats bigger 999 or 9199
:''')
            if ans =="9199":
               score += 1
               print('correct')
            else:
                print('incorrect')

            ans = input('''whats the devalopers name?
:''')
            if ans.lower() =='ethan' or ans.lower()=='ejay':
               score += 1
               print('correct')
            else:
                print('incorrect')

            print(name,'your score was', score,' out of 4')
            mark = (score/total_q) * 100
            print("mark:",str(mark) + '%')

            if score > int(2):
              ans=input('''well done, you got atlest 3 questions right!
press (q)uit to go to game menu or (m)enu to go to main menu: ''')

              if ans.lower()=="q" or ans.lower() =="quit":
                 continue

              elif ans.lower() =="m" or ans.lower() =="menu":
                    main_menu()

            elif score == int(2):
                ans=input('''you where half way!, have a look around and come back again!
press (q)uit to go to game menu or (m)enu to go to main menu: ''')

                if ans.lower() =="q" or ans.lower() =="quit":
                    continue

                elif ans.lower() =="m" or ans.lower() =="menu":
                    main_menu()

            elif score < int(2):
                ans=input('''you got one to no answers right, have a look around and come back again!
press (q)uit to go to game menu or (m)enu to go to main menu: ''')

                if ans.lower() =="q" or ans.lower() =="quit":
                    continue

                elif ans.lower() =="m" or ans.lower() =="menu":
                    main_menu()



        elif ans.lower() =="n" or ans.lower() =="no":
            main_menu()

        elif ans.lower() =="i" or ans.lower() =="info":
            try:
                os.startfile('E:/python work/doc instructions/GAME 2 user manul.docx') #change this to the quiz game dox when ready.
            except (FileNotFoundError, IOError):
                print('---------------------------------------------------------------------')
                print('ERROR 3: file destination not found.')
                print('---------------------------------------------------------------------')
                print('you will now be sent back to the game menu.')
                import time
                time.sleep(3)
                continue
            else:
                print('---------------------------------------------------------------------')
                print('you will now be sent back to the game menu. thanks for reading the instructions')
                time.sleep(3)
                continue

#END OF QUIZ GAME======================================================END OF QUIZ GAME===============================================================END OF QUIZ GAME#
def new_name():
    global name
    name = input('enter a new name')
    main_menu()
#GAME 4 COMING SOON----------------------------------------GAME 4 COMING SOON-----------------------------------------------------------------------------GAME 4 COMING SOON

#END OF CODE---------------------------------------------------END OF CODE--------------------------------------------------------------------------------END OF CODE


name()
