READ ME.

Whole game management:
3 in 1 games by ETHAN HORSTMAN:
Game version(latest):	V1.3.0

If you think you don’t have the latest version it is v1.3.0, email- (ehors26@gmail.com)

If you find a bug you want to report also tell me and make the subject of the email bug and explain how the bug was cursed and the steps taken to achieve this bug. (PLEASE NOTE: ONLY BUGS IN THE LATEST VERSION WILL BE COUNTED AND FIXED) Also check if it is a known bug below.

The hole program only excepts the answers specific to it, e.g. Do you want to play? y/n if you accidental type U instead of y, the game will ask you again instead of just putting down an automatic no. which trust me its Werth it. 


Known bugs: there are no known bugs at this time!



LATEST UPDATE V1.3.0 PLEASE CONTACT (ehors26@gmail.com) FOR UPDATE OR DOWNLOAD IT ONLINE.
